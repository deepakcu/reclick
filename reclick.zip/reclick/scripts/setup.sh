#!/bin/sh

#Set ReClick workspace here
export RECLICK_ROOT=/root/workspace/reclick/
rtl=rtl

#Setup soft links between project source files and reclick RTL elements

if [ ! -d $rtl ]
then
	ln -s $RECLICK_ROOT/elements/rtl ./rtl
fi

if [ ! -d verilog ]
then 
	ln -s $RECLICK_ROOT/templates/verilog ./verilog
fi

if [ ! -d dataplane ]
then
	ln -s $RECLICK_ROOT/config/dataplane ./dataplane
fi

cd $NF2_DESIGN_DIR/verif
if [ ! -d test_router_short ]
then
	ln -s $RECLICK_ROOT/config/tests/test_router_short $NF2_DESIGN_DIR/verif/test_router_short
fi

echo "Done!"
