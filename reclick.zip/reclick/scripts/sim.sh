testname=$1
cp $NF2_DESIGN_DIR/verif/test_router_short/make_pkts_$testname.pl $NF2_DESIGN_DIR/verif/test_router_short/make_pkts.pl
cd $NF2_ROOT/work/verif/reclick/test_router_short
nf2_run_test.pl --major router --minor short  --vcs 
../my_sim -gui
