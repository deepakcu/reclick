#!/usr/local/bin/perl -w
# make_pkts.pl
#
#

use NF2::PacketGen;
use NF2::PacketLib;
use SimLib;
use RouterLib;

use reg_defines_reference_router;

$delay = 2000;
$batch = 0;
nf_set_environment( { PORT_MODE => 'PHYSICAL', MAX_PORTS => 4 } );

# use strict AFTER the $delay, $batch and %reg are declared
use strict;
use vars qw($delay $batch %reg);

my $ROUTER_PORT_1_MAC = '00:4e:46:32:43:00';
my $ROUTER_PORT_2_MAC = '00:4e:46:32:43:01';
my $ROUTER_PORT_3_MAC = '00:4e:46:32:43:02';
my $ROUTER_PORT_4_MAC = '00:4e:46:32:43:03';

my $ROUTER_PORT_1_IP = '0.0.0.0';
my $ROUTER_PORT_2_IP = '0.0.0.0';
my $ROUTER_PORT_3_IP = '10.2.3.2';
my $ROUTER_PORT_4_IP = '10.1.3.2';

my $next_hop_1_DA = '00:4e:46:32:43:02';
my $next_hop_2_DA = '00:4e:46:32:43:03';

# Prepare the DMA and enable interrupts
prepare_DMA('@3.9us');
enable_interrupts(0);

# Write the ip addresses and mac addresses, routing table, filter, ARP entries
$delay = '@4us';
set_router_MAC(1, $ROUTER_PORT_1_MAC);
$delay = 0;
set_router_MAC(2, $ROUTER_PORT_2_MAC);
set_router_MAC(3, $ROUTER_PORT_3_MAC);
set_router_MAC(4, $ROUTER_PORT_4_MAC);

add_dst_ip_filter_entry(0,$ROUTER_PORT_1_IP);
add_dst_ip_filter_entry(1,$ROUTER_PORT_2_IP);
add_dst_ip_filter_entry(2,$ROUTER_PORT_3_IP);
add_dst_ip_filter_entry(3,$ROUTER_PORT_4_IP);

add_LPM_table_entry(0,'10.1.4.2', '255.255.255.0', '10.1.4.1', 0x40);
add_LPM_table_entry(15, '10.2.3.2', '255.255.255.0', '10.2.3.1', 0x10);

# Add the ARP table entries
add_ARP_table_entry(0, '10.1.4.1', $next_hop_2_DA);
add_ARP_table_entry(1, '10.2.3.1', $next_hop_1_DA);

my $length = 100;
my $TTL = 30;
my $DA = 0;
my $SA = 0;
my $dst_ip = 0;
my $src_ip = 0;
my $pkt;

#
###############################
# Send two non-broadcast packets and 1 broadcast packet
# Expect the non-broadcast packets to be received

$delay = '@40us';
$length = 64;
$DA = $ROUTER_PORT_3_MAC;
$SA = '00:4e:46:32:43:02';
$dst_ip = '10.1.4.2';
$src_ip = '10.2.3.2';
$pkt = make_IP_pkt($length, $DA, $SA, $TTL, $dst_ip, $src_ip);
nf_packet_in(3, $length, $delay, $batch,  $pkt);

nf_expected_packet(4, $length, $pkt);

$delay = '@40us';
$length = 64;
$DA = $ROUTER_PORT_3_MAC;
$SA = '00:4e:46:32:43:02';
$dst_ip = '10.1.4.2';
$src_ip = '10.2.3.2';
$pkt = make_IP_pkt($length, $DA, $SA, $TTL, $dst_ip, $src_ip);
nf_packet_in(3, $length, $delay, $batch,  $pkt);

nf_expected_packet(4, $length, $pkt);

$delay = '@40us';
$length = 64;
$DA = 'ff:ff:ff:ff:ff:ff';
$SA = '00:4e:46:32:43:02';
$dst_ip = '10.1.4.2';
$src_ip = '10.2.3.2';
$pkt = make_IP_pkt($length, $DA, $SA, $TTL, $dst_ip, $src_ip);
nf_packet_in(3, $length, $delay, $batch,  $pkt);


# *********** Finishing Up - need this in all scripts ! ****************************
my $t = nf_write_sim_files();
print  "--- make_pkts.pl: Generated all configuration packets.\n";
printf "--- make_pkts.pl: Last packet enters system at approx %0d microseconds.\n",($t/1000);
if (nf_write_expected_files()) {
  die "Unable to write expected files\n";
}

nf_create_hardware_file('LITTLE_ENDIAN');
nf_write_hardware_file('LITTLE_ENDIAN');
