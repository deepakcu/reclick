package click;
import java.util.*;
import static click.clickContext.Flag.*;

//Shared these resources from ReClick (so that we don't need to reimplement)
//import reclick.Tuples.Cursor;

/**
 * This class drives code (Tuple) generation
 *
 * @version 1.0
 */
public class Generate extends Phase<Integer,Object> {

  /**
   * The obvious constructor
   *
   * @param context the compilation context
   */
  public Generate (clickContext context) {
    super(context);
  }

  /**
   * perform runs the phase
   *
   * @return number of Tuple generation errors
   */
  public Integer perform () {
    if (context.flag(Verbose))
      context.verbStream.println("Generating tuples ...");
    setStream(context.flag(TuplePrint), context.baseName, "tuple", "tuple", true);
    
    Tuples programHeadTuples = new Tuples(TupleTemplate.programHeader() ,TupleTemplate.nullTemplate());	
    Tuples wireTuples 		 = new Tuples(TupleTemplate.wireHeader()    ,TupleTemplate.nullTemplate());
    Tuples moduleTuples 	 = new Tuples(TupleTemplate.nullTemplate()  ,TupleTemplate.nullTemplate());
    Tuples programEndTuples  = new Tuples(TupleTemplate.nullTemplate()  ,TupleTemplate.programTrailer());
    
    
    ArrayList<Tuples> programTuples  = new ArrayList<Tuples>();
    ArrayList<Cursor> programCursors = new ArrayList<Cursor>();
     
    ArrayList<ClickGraphElement> graphElements = new ArrayList<ClickGraphElement>();
    
    TupleGenVisitor tupVis = new TupleGenVisitor(programHeadTuples,
    											 wireTuples, 
    											 moduleTuples,
    											 programEndTuples,
    											 graphElements); 
    	
    context.configuration.accept(tupVis);
    if (tupVis.numErrors > 0)
      context.errStream.printf("Number of tuple generation errors: %d%n", tupVis.numErrors);
    
    
    
    if (ps != null) {
      //Tuples.accept(new TuplePrintVisitor(ps));
      programHeadTuples.accept(new TuplePrintVisitor(ps));
      wireTuples.accept(new TuplePrintVisitor(ps));
      moduleTuples.accept(new TuplePrintVisitor(ps));
      programEndTuples.accept(new TuplePrintVisitor(ps));
      ps.close();
    }
    
    /*Add in the order we want the tuples to be printed in the Verilog output*/
    
    programTuples.add(programHeadTuples); programCursors.add(new Cursor(programHeadTuples));
    programTuples.add(wireTuples);		  programCursors.add(new Cursor(wireTuples));
    programTuples.add(moduleTuples);	  programCursors.add(new Cursor(moduleTuples));
    programTuples.add(programEndTuples);  programCursors.add(new Cursor(programEndTuples));
    
    Cursor programHeadTuplesCursor = new Cursor(programHeadTuples);
    click.printTuples(programTuples,programCursors, context.flag(BBPrint), context.flag(XBBPrint),context.rtlName, "");
    
    
    for(int i=0;i<moduleTuples.tuples.size();i++) {
    	System.out.println("Module is "+moduleTuples.tuples.get(i).tupString);
    }
    //click.printClickGraph(context.rtlName, graphElements);
    
    return tupVis.numErrors;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

