package click;
import reclick.StringMap;
/**
 * TokenId is used to represent an <b>identifier</b> token
 * found in a <i>Pascal</i> program.
 *
 * @version 1.0
 */
public final class TokenId implements Token {

  /**
   * the StringMap used to hold all identifiers (and keywords),
   * so that we can share the String (and the TokenId/TokenKey) when the name
   * is the same
   */
  private static final StringMap<Token> idMap = new StringMap<Token>(1031); // a largish prime

  /**
   * the string defining this identifier
   */
  public final String string;   
  
  /**
   * arbitrary info, settable by client of this class
   */
  public Object info = null;

  /**
   * return sym.ID as the token code
   *
   * @return sym.ID as the token code
   */
  public int code () {
    return sym.ID;
  }

  /**
   * Creates a new TokenId instance.
   * <b>NOTE: this assumes that s is new!</b>
   *
   * @param cs a CharSequence defining an identifier
   * @param hash the StringMap.getHash result for String s
   */
  private TokenId (CharSequence cs, int hash) {
    // note: this ASSUMES that cs is new!
    string = cs.toString();
    idMap.put(string, this, hash);  // insert into identifier table
  }

  /**
   * Retrieves a Token given just its defining string.
   * NOTE: Assumes already in lower case!
   *
   * @param cs defining CharSequence
   * @return  Token representing the identifier (may be a TokenKey)
   */
  public static Token get (CharSequence cs) {
    int hash = StringMap.getHash(cs);
    Token t = idMap.get(cs, hash);
    if (t != null)
      return t;
    return new TokenId(cs, hash);
  }

  /**
   * provides a "hook" for a visitor to do something before each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptBefore (TokenVisitor v) {
    v.visitEveryBefore(this);
  }

  /**
   * Supports visiting objects in the Token class hierarchy; calls
   * acceptBefore and acceptAfter hooks as well as a visit method particular
   * to this class.
   *
   * @param v the TokenVisitor to call, indicating this object is a TokenId
   */
  public void accept (TokenVisitor v) {
    this.acceptBefore(v);
    v.visitTokenId(this);
    this.acceptAfter(v);
  }

  /**
   * provides a "hook" for a visitor to do something after each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptAfter (TokenVisitor v) {
    v.visitEveryAfter(this);
  }

  /**
   * String representation of this TokenId.
   *
   * @return the String value used when we created the TokenId
   */
  public String toString () {
    return string;
  }

  /**
   * Pretty representation of this TokenId.
   *
   * @return the String value used when we created the TokenId,
   * with a prefix to distinguish a TokenId from other kinds of Token objects
   */
  public String toPrettyString () {
    return "$" + this;
  }

  /**
   * Causes TokenKey to enter all keywords into the shared id/keyword table.
   */
  static {
    TokenKey.EnterKeywords(idMap);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
