package click;

import reclick.SemanticException;
import java.util.*;
/**
 * This defines an AST (Abstract Syntax Tree) visitor for checking semantic
 * correctness. Different constructs have different checking protocols, to
 * wit:
 *
 * Decl node visiting:
 *   doProcBody is an INPUT, indicating whether this pass of Decl processing
 *   should dive into the bodies of nested procedures/functions
 *
 * @version 1.0
 */
public class ASTCheckVisitor extends ASTNullVisitor
{

  private boolean doProcBody;

  /**
   * INPUT to Expr visiting methods; indicates whether the context demands an
   * rvalue or an lvalue.
   *
   */
  public boolean rValue;

  /**
   * Indicates how many checking errors we found.
   */
  public int numErrors = 0;

  /**
   * The obvious constructor; it creates our three helper visitors.
   */
  public ASTCheckVisitor () { 
	  
  }

  /**
   * Checks a Program: processes predefined Decls, then Decls and Block of the
   * Program, in appropriate scopes.
   *
   * @param p the Program we are checking
   */
  public void visitConfiguration (Configuration c) {
    c.mySymtab = new SymbolTable((SymbolTable)null, c.decls, true);
    c.mySymtab.enterScope();
    c.decls.accept(this);
    c.stmts.accept(this);
    
    /*
    for(int i=0;i<c.mySymtab.decls.declsSize();i++) {
    	Decl d = c.mySymtab.decls.decls.get(i);
    	System.out.println("Element is "+((DeclElement)d).bind.id.string);
    	System.out.println("Ports are ");
    	for(int j=0;j<((DeclElement)d).ports.size();j++)
    		System.out.print(((DeclElement)d).ports.get(j).portName);
    }
    */
    
    c.mySymtab.exitScope();
    
    
    
  }

  // Methods for checking statements

  /**
   * Checks a Stmts: checks each Stmt in turn.
   *
   * @param ss the Stmts we are checking
   */
  public void visitStmts (Stmts ss) {
    for (Stmt s : ss.stmts) {
      try {
    	  if(s instanceof StmtConnection)
    		  s.accept(this);
      } catch (SemanticException e) {
        assert e.pos != -1;
        click.ShowError(e.pos, e.getMessage());
        ++numErrors;
      } catch (Exception e) {
        e.printStackTrace();
        ++numErrors;
      }
    }
  }
  
  public void visitStmtDeclaration(StmtDeclaration s) {
	  //Do nothing
  }
  
  public void visitStmtConnection(StmtConnection s) {
	  //Check all elements used in this statement have been declared
	  for(int i=0;i<s.elementList.size();i++) {
		  
		  //Get each element and assert if it has been declared before
		  Element e = s.elementList.get(i);
		  Decl d = SymbolTable.checkBindUse(e.name);
		  assert d instanceof DeclElement;
		  
		  //Get left port and see if port is already present in element declaration
		  //If not, add the declaration
		  if(e.leftPort!=null) {
			  if(!((DeclElement)d).hasPort(e.leftPort) ) {
				  //Identify the type for the element to which this port is connected to (and set it) 
				  e.leftPort.endElementType = ((DeclElement)(SymbolTable.checkBindUse(e.leftPort.endElement))).type;
				  System.out.println("End element type is "+e.leftPort.endElementType.id.string);
				  ((DeclElement)d).ports.add(e.leftPort);
			  	
			  	String elementName = ((DeclElement)d).type.id.string;
			  	//Assert that the element has this port
			  	if(!Library.hasPort(elementName, e.leftPort.portName,ElementPortType.Input))
			  		throw new SemanticException(s.pos, "Element does not have port named "+e.leftPort.portName);
			  }
		  }
		
		  //Get right port and see if port is already present in element declaration
		  //If not, add the declaration
		  if(e.rightPort!=null) {
			  if(!((DeclElement)d).hasPort(e.rightPort) ) {
				  //Identify the type for the element to which this port is connected to (and set it) 
				  e.rightPort.endElementType = ((DeclElement)(SymbolTable.checkBindUse(e.rightPort.endElement))).type;

				  ((DeclElement)d).ports.add(e.rightPort);
				  
				  String elementName = ((DeclElement)d).type.id.string;
				  //Assert that the element has this port
				  if(!Library.hasPort(elementName, e.rightPort.portName, ElementPortType.Output))
				   	throw new SemanticException(s.pos, "Element does not have port named "+e.rightPort.portName);
			  }
		  }
		  
		  /*Create artificial in port for the from device since user 
		   * cannot specify it in the configuration*/
		  if(((DeclElement)d).type.id.string.equals("FromDevice")) {
			  Port p = new Port("in0",0,0);
			  p.endElement = new Binding("netfpga",-1,-1);
			  p.endPort    = "in0";
			  p.portType = ElementPortType.Input;
			  ((DeclElement)d).ports.add(p);
		  }
		  /*Create artificial in port for the to device since user 
		   * cannot specify it in the configuration*/
		  if(((DeclElement)d).type.id.string.equals("ToDevice")) {
			  Port p = new Port("out0",0,0);
			  p.endElement = new Binding("netfpga",-1,-1);
			  p.endPort    = "out0";
			  p.portType = ElementPortType.Output;
			  ((DeclElement)d).ports.add(p);
		  }
		  
	  }
  }
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

