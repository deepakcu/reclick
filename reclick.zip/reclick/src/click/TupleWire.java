package click;
/**
 * TupleWire
 *
 * @version 1.0
 */

enum WireType {
	Data,
	Ctrl,
	Wr,
	Rdy,
	RegAckIn,
	RegReqIn,
	RegRdWrLIn,
	RegAddrIn,
	RegDataIn,
	RegSrcIn,
	RegReqOut,
	RegAckOut,
	RegRdWrLOut,
	RegAddrOut, 
	RegDataOut,
	RegSrcOut
}

public class TupleWire implements Comparable<TupleWire>{
  
	WireType wireType; //data/ctrl/wr,rdy
	String srcElement;
	String srcPort;
	String endElement;
	String endPort;
	String high;
	String low;
	
	public String wireType(WireType wt) {
		
		if (wt==WireType.Data)
			return "data";
		if (wt==WireType.Ctrl)
			return "ctrl";
		if (wt==WireType.Wr)
			return "wr";
		if (wt==WireType.Rdy)
			return "rdy";
		
		if (wt==WireType.RegAckIn)
			return "regack";
		if(wt==WireType.RegReqIn)
			return "regreq";
		if(wt==WireType.RegRdWrLIn)
			return "regrdwrl"; 
		if(wt==WireType.RegAddrIn)
			return "regaddr";
		if(wt==WireType.RegDataIn)
			return "regdata";
		if(wt==WireType.RegSrcIn)
			return "regsrc";
		
		if(wt==WireType.RegReqOut)
			return "regreq";
		if(wt==WireType.RegAckOut)
			return "regack";
		if(wt==WireType.RegRdWrLOut)
			return "regrdwrl";
		if(wt==WireType.RegAddrOut)
			return "regaddr";
		if(wt==WireType.RegDataOut)
			return "regdata";
		if(wt==WireType.RegSrcOut)
			return "regsrc";
			
		return "";
	}
	
	
	/**
	 * 
	 * Represents a wire to connect module port with top level (given the following parameters are supplied) 
	 *  
	 * @param wt - WireType (Data,Ctrl,Wr,Rdy)
	 * @param se - Source element
	 * @param sp - Source port
	 * @param ee - End element
	 * @param ep - End port
	 * @param hi - MSB (wire width)
	 * @param lo - LSB (wire width)
	 */
	TupleWire(WireType wt, String se, String sp, String ee, String ep, String hi, String lo) {
		srcElement 	= se;
		srcPort 	= sp;
		endElement 	= ee;
		endPort 	= ep;
		high 		= hi;
		low			= lo;
		wireType	= wt;
	}

	/**
	 * Returns a pretty name for the wire (used for the wire)
	 * @param w
	 * @return
	 */
	public String prettyName() {
		if(this!=null)
			return this.srcElement+"_"+wireType(this.wireType)+"_"+this.srcPort+"_"+this.endPort+"_"+wireType(this.wireType)+"_"+this.endElement;
		else
			return "";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((endElement == null) ? 0 : endElement.hashCode());
		result = prime * result + ((endPort == null) ? 0 : endPort.hashCode());
		result = prime * result
				+ ((srcElement == null) ? 0 : srcElement.hashCode());
		result = prime * result + ((srcPort == null) ? 0 : srcPort.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TupleWire other = (TupleWire) obj;
		if (endElement == null) {
			if (other.endElement != null)
				return false;
		} else if (!endElement.equals(other.endElement))
			return false;
		if (endPort == null) {
			if (other.endPort != null)
				return false;
		} else if (!endPort.equals(other.endPort))
			return false;
		if (srcElement == null) {
			if (other.srcElement != null)
				return false;
		} else if (!srcElement.equals(other.srcElement))
			return false;
		if (srcPort == null) {
			if (other.srcPort != null)
				return false;
		} else if (!srcPort.equals(other.srcPort))
			return false;
		return true;
	}
	
	@Override
	//To be implemented
	public int compareTo(TupleWire t) {
		if(t.srcPort.equals(this.srcPort))
			return 0;
		else
			return -1;
	}
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
