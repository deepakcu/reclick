package click;
import java.util.ArrayList;
/**
 * Representation of a Remove statement.
 *
 * <i>
 * The InsertAfter statement is used to insert a field after a particular
 * field of the packet.
 * </i>
 *
 * Example:
 * 
 * REMOVE binding:b FROM Packet:p
 *
 * @version 1.0
 */
public class StmtConnection extends Stmt {

  public final ArrayList<Element> elementList;	
	
  /**
   * Creates a new StmtInsertBefore instance given the Binding    * @param b     Binding (name) of the control variable
   * 
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public StmtConnection (ArrayList<Element> ee, int left, int right) {
    super(left, right);
    elementList = ee;
    //Here, scan each connection statement and add ports to the elements which were 
    //discovered in the declarations.
    
    //Just print the elements to see if we have it correct
    for(int i=0;i<ee.size();i++) {
    	Element e = ee.get(i);
    	System.out.println("Element is "+e.name.id.toString());
    	if(e.leftPort!=null) {
    		System.out.println("Left port is "+e.leftPort.portName);
    	}
    	if(e.rightPort!=null) {
    		System.out.println("Right port is "+e.rightPort.portName);
    	}
    }
  }

  /**
   * Handles AST visiting of StmtFor nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitStmtConnection(this);
    super.acceptAfter(v);
  }

  /**
   * If false, suppresses code generation
   */
  public boolean ok = false;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

