package click;
/**
 * This interface defines opcodes for tuples of Mini-Pascal's intermediate
 * language; it is essentially an enumeration type, so we omit documentation
 * on each constant (though the source code explains each operator further)
 *
 * @version 1.0
 */
public enum TupleCode {
  Code("");
  
  public final String tupleString;
  
  /**
   * The obvious constructor
   * @version 1.0
   */ 
  TupleCode(String tCode) {
	tupleString = tCode;
  }
}



// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

