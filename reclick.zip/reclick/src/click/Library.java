package click;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.*;

/**
 * The library class - Useful for quick checking of
 * library elements 
 * 
 */
enum ElementPortType 
{
	Input,
	Output
}


public class Library {
	
	public static ArrayList<ClickElement> elements = new ArrayList<ClickElement>();
	
	
	/**
	 * A utility method that will be useful to check if an element
	 * with a given name is available in the library
	 * @param elementName
	 * @return
	 */
	public static boolean hasElement(String elementName) {
		return elements.contains(new ClickElement(elementName));
	}
	
	public static boolean hasPort(String elementName, String port, ElementPortType type) {
		int index = elements.indexOf(new ClickElement(elementName));
		assert index!=-1;
		return elements.get(index).ports.contains(new ElementPort(type,port));
	}
	
	public static boolean verifyPortType(String elementName,String port, ElementPortType portType) {
		int index = elements.indexOf(new ClickElement(elementName));
		int portIndex = elements.get(index).ports.indexOf(port);
		assert portIndex != -1;
		if(elements.get(index).ports.get(portIndex).type==portType)
			return true;
		else
			return false;
	}
	
	/**
	 * parse each line and constructs the data structure
	 * @param line
	 */
	public static ClickElement parseLine(String line) {
		StringTokenizer st = new StringTokenizer(line);
		
		ClickElement m = new ClickElement();
		if(st.hasMoreTokens())
			m.name = st.nextToken();
		 System.out.println("Element name is "+m.name);
		
		//From now on, every even token must specify the type and 
		//every odd token must specify the name 
	     while (st.hasMoreTokens()) {
	    	 String type = null;
	    	 String name = null;
	    	 if(st.hasMoreTokens())
	    		 type = st.nextToken();
	    	 if(st.hasMoreTokens())
	    		 name = st.nextToken();
	    	 
	    	 if(type.equals("input")) {
	    		 m.ports.add(new ElementPort(ElementPortType.Input,name));
	    	 }
	    	 else if(type.equals("output")) {
	    		 m.ports.add(new ElementPort(ElementPortType.Output,name));
	    	 }
	     }
	     return m;
	}
	
	/**
	 * parses the Library file and stores elements in a handy data structure
	 */
	public static void parseLibrary(String fileName) {
		try
		{
			FileInputStream fstream = new FileInputStream(fileName);
			DataInputStream in = new DataInputStream(fstream);
			
            while (in.available() !=0)	{
            	elements.add(parseLine(in.readLine()));
            	
			}

        	in.close();
		} 
        catch (Exception e)	{
			System.err.println("File input error");
			e.printStackTrace();
			System.exit(-1);
		}	
	}
}


class ElementPort implements Comparable<ElementPort> {
	public ElementPortType type;
	public String portname;
	
	ElementPort(ElementPortType t, String name) {
		type   = t;
		portname = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((portname == null) ? 0 : portname.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ElementPort other = (ElementPort) obj;
		if (portname == null) {
			if (other.portname != null)
				return false;
		} else if (!portname.equals(other.portname))
			return false;
		if (type != other.type)
			return false;
		return true;
	}
	
	@Override
	public int compareTo(ElementPort e) {
		
		if(e.portname.equals(this.portname))
			return 0;
		else
			return -1;
	}
}

class ClickElement implements Comparable<ClickElement> {
	public String name;
	public ArrayList<ElementPort> ports;
	
	ClickElement() {
		ports = new ArrayList<ElementPort>();
	}
	
	/**
	 * @overload
	 * @param n
	 */
	ClickElement(String n) {
		name = n;
		ports = new ArrayList<ElementPort>();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClickElement other = (ClickElement) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public int compareTo(ClickElement e) {
		if(e.name.equals(this.name))
			return 0;
		else
			return -1;
	}
	
	
}
