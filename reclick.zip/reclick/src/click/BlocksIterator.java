package click;
import java.util.*;
//import reclick.Tuples.Cursor;

/**
 * This class supports iteration over the basic blocks (regular or extended)
 * in a Tuples list.
 *
 * @version 1.0
 */
public class BlocksIterator implements Iterator {

  /**
   * Cursor cursor defines the range over which this BlocksIterator will
   * produce blocks
   */
  private final Cursor cursor;

  /**
   * A visitor that we use to locate block boundaries
   */
  private final TupleBlocksVisitor visitor;

  /**
   * A scratch Cursor used to return a block to to the user of this Iterator
   */
  private final Cursor block;

  /**
   * Constructor that returns a BlocksIterator given the range over which it
   * is to find blocks, and whether normal basic blocks or extended basic
   * blocks are desired.
   *
   * @param c the Cursor defining the range of tuples for which the
   * BlocksIterator is to produce blocks
   * @param extended a boolean that when true indicates to produce extended,
   * as opposed to regular, basic blocks (an extended basic block ends with an
   * unconditional jump or before a label, but continues at conditional jumps,
   * which terminate regular basic blocks)
   */
  public BlocksIterator (Tuples t, Cursor c, boolean extended) {
    cursor  = (Cursor)c.clone();
    visitor = new TupleBlocksVisitor(extended);
    block   = new Cursor(t);  // just to create it
    for ( ; cursor.inRange(); cursor.advance()) {
      cursor.tuple().accept(visitor);
      if (visitor.inBlock) break;
    }
  }

  /**
   * A BlocksIterator has a next block if its scanning Cursor cursor is still
   * within the range over which we are generating blocks
   *
   * @return a boolean indicating whether there may be more blocks coming from
   * this iterator
   */
  public boolean hasNext () {
    boolean result = cursor.inRange();
    if (!result) {
      cursor.release();
      block.release();
    }
    return result;
  }

  /**
   * Produce the next block from this iterator, as a Cursor whose
   * limits define the block. The returned Cursor is set to scan in forward
   * order (but can be explicitly reset to scan downwards, of course).  It is
   * possible for it to return a cursor that has an empty range, so code
   * should be prepared for that.
   *
   * @return a Cursor defining the range of the next block of Tuple's
   * in the overall range of the iterator; said block may be empty
   */
  public Object next () {
    // skip tuples not considered part of a block
    while (true) {
      if (cursor.inRange()) {
        cursor.tuple().accept(visitor);
        if (visitor.inBlock) break;
        cursor.advance();
        continue;
      }
      // early end: no in-block tuples
      block.reset(0, -1, true);  // fake an empty block
      return block;
    }

    // start accumulating; skip block starters (labels)
    int first = cursor.index();
    while (visitor.startsBlock) {
      cursor.advance();
      if (cursor.inRange()) {
        cursor.tuple().accept(visitor);
        continue;
      }
      // early end: no non-starters
      block.reset(first, cursor.index()-1, true);
      return block;
    }

    // scan for end of block
    while (true) {
      if (visitor.endsBlock) {
        // include this ender tuple
        block.reset(first, cursor.index(), true);
        cursor.advance();  // so next block starts in the right place
        return block;
      }
      if (visitor.startsBlock || !visitor.inBlock) {
        // do NOT include this starter tuple or extra-block tuple
        block.reset(first, cursor.index()-1, true);
        return block;
      }
      cursor.advance();
      if (cursor.inRange()) {
        cursor.tuple().accept(visitor);
        continue;
      }
      // no more tuples
      block.reset(first, cursor.index()-1, true);
      return block;
    }
  }

  /**
   * This iterator does not support removing returned blocks
   */
  public void remove () {
    throw new UnsupportedOperationException();
  }

  /**
   * The accept method of the iterator calls the TupleVisitor's visitBlock
   * method on each block in turn, in the order that the iterator produces the
   * blocks
   *
   * @param tv the TupleVisitor to call on each block
   */
  public void accept (TupleVisitor tv) {
    while (hasNext()) {
      Cursor b = (Cursor)next();
      if (b.size() == 0) continue;
      tv.visitBlock(b);
    }
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

