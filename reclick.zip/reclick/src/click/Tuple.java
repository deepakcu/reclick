package click;
import static click.TupleCode.*;
import java.util.ArrayList;

/**
 * This class defines the tuples of Mini-Pascal's intermediate language. Most
 * fields are not final so that optimizations can mutate them. They should do
 * so what care, since this class does not (and cannot easily) check such
 * mutations the way it checks fields upon Tuple construction.
 *
 * In order to perform such checks, rather than exposing the Tuple constructor
 * we provide a static method for building each kind of Tuple, which can check
 * that its arguments are appropriate (and supply Empty fields for those not
 * used in that kind of Tuple).
 *
 * @version 1.0
 */
public class Tuple implements Comparable<Tuple>{

  /**
   * The string of the Tuple
   */
  public TupleCode code;
  
  /**
   * The string of the Tuple
   */
  public String tupString;
  
  
  /**
   * Any Tuple can have a String comment
   */
  public String comment = null;

  @Override
  public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((tupString == null) ? 0 : tupString.hashCode());
	return result;
  }


  @Override
  public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Tuple other = (Tuple) obj;
	if (tupString == null) {
		if (other.tupString != null)
			return false;
	} else if (!tupString.equals(other.tupString))
		return false;
	return true;
  }


  @Override
  public int compareTo(Tuple t) {
	System.out.println("Comparing..");
	  if(t.tupString.equals(this.tupString))
		return 0;
	else
		return -1;
  }

  
  /**
   * Creates a new Tuple from values for its most important fields; note that
   * it is private, as discussed in the class documentation.
   *
   * @param Tuple code
   */
  
  private Tuple (TupleCode code) {
    this.code = code;
  }
  
  /**
   * Creates a new Tuple from values for its most important fields; note that
   * it is private, as discussed in the class documentation.
   *
   * @param Tuple code
   */
  
  private Tuple (TupleCode code, String tstring) {
	  this.code = code;
	  this.tupString = tstring;
  }
  

  /**
   * This method is convenient for building a Tuple and adding a comment to it
   *
   * @param c the String comment to add (can even be null)
   * @return the Tuple to which we are adding the comment
   */
  
  public Tuple addComment (String c) {
    comment = c;
    return this;
  }
  
  /**
   * X format tuple builder: all fields Empty, only the operator matters
   *
   * @param op the TupleOp operator of the Tuple
   * @return the new Tuple
   */
  
  private static Tuple X (TupleCode code) {
      return new Tuple(code);
  }

  /**
   * ProgStart tuples have X format
   *
   * @return the new Tuple
   */
  public static Tuple makeProgStart (String name) {
      return new Tuple(Code, TupleTemplate.ProgStartTemplate(name));
  }    
  
  /**
   * ProgEnd tuples have X format
   *
   * @return the new Tuple
   */
  public static Tuple makeProgEnd () {
	    return new Tuple(Code, TupleTemplate.ProgEndTemplate());
  }
  
  public static Tuple makeModule(String elementName,String instanceName,ArrayList<ElementConnection> connections) {
	  //System.out.println("Module template is "+TupleTemplate.ModuleTemplate(elementName,instanceName,connections));
	  return new Tuple(Code, TupleTemplate.ModuleTemplate(elementName,instanceName,connections));
  }
  
  /**
   * makeWire 
   *
   * @return the new Tuple
   */
  
  public static Tuple makeWire (TupleWire wire) {
	    return new Tuple(Code, TupleTemplate.wireTemplate(wire.prettyName(),wire.high,wire.low));
  } 
  
  /**
   * makeWire 
   *
   * @return the new Tuple
   */
  /*
  public static Tuple makeWire (String fName, int high, int low) {
	    return new Tuple(GetStmt, TupleTemplate.wireTemplate(fName, high, low));
  } 
  */
  
  /**
   * Support TupleVisitor functionality, as if each TupleOp defined a separate
   * subclass of Tuple, which is not actually the case. Hence it simply does a
   * switch on TupleOp and calls the appropriate visit method. (This COULD be
   * done with instance-specific methods in TupleOp, but would be verbose and
   * painful to write.)
   *
   * @param v a TupleVisitor visiting this Tuple
   */
  public void accept (TupleVisitor v) {
    v.visitEveryBefore(this);
    switch (code) {
    	case Code     : v.visitCode(this); break;
    	default       : assert false; 	   break;
    }
    v.visitEveryAfter(this);
  }
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

