package click;
import java.util.ArrayList;

/**
 * The element class 
 * 
 */
public final class Link extends ASTNode {

 /**
  * The left end of this link
   */
 public final Port leftPort;
 
 /**
  * The element at the left end of the link
  */
 public Element leftElement;
 
 
 /**
  * The right end of this link
  */
 public final Port rightPort;
 
 /**
  * The element at the right end of the link
  */
 public Element rightElement;
 
 
   /**
   * Creates a new Program instance given the top-level Decls, Block, and
   * source (start/end) position
   *
   * @param dd     declarations for the program block.
   * @param blk    code block of the program.
   * @param left   starting position of program declaration.
   * @param right  ending position of program declaration.
   */
  public Link (Port p1, Port p2, int left, int right) {
    super(left, right);
    leftPort = p1;
    rightPort = p2;
    leftElement  = null;
    rightElement = null;
  }

  /**
   * Handles AST visiting for Program nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    if (v == null) return;  // allows more graceful handling of some error conditions
    super.acceptBefore(v);
    v.visitLink(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
