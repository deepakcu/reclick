package click;

import java.util.ArrayList;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * A class that defines Verilog Templates
 *
 * @version 1.0
 */
public class TupleTemplate  {
	
  	
  public static String templateStr;
  
  /**
   * The obvious constructor
   * @version 1.0
   */ 
  TupleTemplate() {
	  templateStr = "";
  }
  
  /**
   * A null template
   */ 
  public static String nullTemplate() {
	  templateStr = "";
	  return templateStr;		
  }
  
  /**
  * 
  * A nice template to start the module!
  *  
  * @param progName
  * @return
  */
  public static String ProgStartTemplate(String progName) {
	  templateStr = "";
	  return templateStr.concat("\nmodule dataplane\n")
					    .concat(getTemplate("params"))
					    .concat(getTemplate("ioports"));  
  }


  
  /**
  * A nice template to end the module!
  * @return
  */
  public static String ProgEndTemplate() {
	  return templateStr.concat(getTemplate("program_tail"));	  
  }
  
  
  public static String wireTemplate(String wireName, String high, String low) {
	  templateStr = "";
	  if(high.equals("0")&&low.equals("0"))
		  return templateStr.concat("wire "+wireName+";");
	  else
		  return templateStr.concat("wire ["+high+":"+low+"] "+wireName+";");
  }
  
  /**
 * 
 * Generate an RTL template for the element module. 
 * 
 * @param elementName
 * @param instanceName
 * @param connections
 * @return
 */
public static String ModuleTemplate(String elementName,String instanceName,ArrayList<ElementConnection> connections) {
	  templateStr = "";
	  assert connections.size()!=0;
	  
	  templateStr = templateStr.concat("\n"+elementName+" "+instanceName+"(\n");
	  int i=0;
	  
	  //Add clocks and resets
	  templateStr = templateStr.concat(".clk(clk),\n")
	  						   .concat(".reset(reset),\n");
	  
	  //Generate connections for element ports and top level wires
	  for(i=0;i<connections.size()-1;i++) {
		  templateStr = templateStr.concat("."+connections.get(i).port+"("+connections.get(i).wire+"),\n");
	  }
	  
	  //The last connection doesn't need a comma!!
	  templateStr = templateStr.concat("."+connections.get(i).port+"("+connections.get(i).wire+")");
	  
	  templateStr = templateStr.concat(");");
	  return templateStr;
  }

  /**
   * Program headers
   * 
   */ 
  public static String programHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("program_head"));
		
  }
  
  /**
   * A program trailer
   */ 
  public static String programTrailer() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("program_tail"));
  }
  
  /**
   * A I/O header
   */ 
  public static String ioHeader() {
	  templateStr = "\n/****Input and Output Ports****/\n";
	  return templateStr;		
  }
  
  /**
  /**
   * A wire header
   */ 
  public static String wireHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("wire_head"));		
  }
	  
  
  /**
   * A assign header
   */ 
  public static String assignHeader() {
	  templateStr = "\n/******Assign statements******/\n";
	  return templateStr;		
  }

  
  
 /**
 * This is a uesful method to extract template definitions from files
 * The templates are stored as files within /templates directory
 * The template string must match the file name  
 * 
 * @param tempateString
 * @return
 */
 public static String getTemplate(String templateString) {
	 File file = new File("templates/click/"+templateString+".temp");
	 FileInputStream fis = null;
	 BufferedInputStream bis = null;
	 DataInputStream dis = null;
	 String templateStr = "";
	 
	 try {
	      fis = new FileInputStream(file);

	      // Here BufferedInputStream is added for fast reading.
	      bis = new BufferedInputStream(fis);
	      dis = new DataInputStream(bis);

	      // dis.available() returns 0 if the file does not have more lines.
	      while (dis.available() != 0) {
	    	  templateStr = templateStr.concat(dis.readLine()+"\n");
	      }

	      // dispose all the resources after using them.
	      fis.close();
	      bis.close();
	      dis.close();
	      return templateStr;

	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	    return "";
 }
  
}



// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

