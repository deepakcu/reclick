package click;
import java.util.*;
import static click.clickContext.Flag.*;

/**
 * This class drives the semantic checking of the AST.
 *
 * @version 1.0
 */
public class Check extends Phase<Integer,Object> {

  /**
   * The obvious constructor
   *
   * @param context the compilation context
   */
  public Check (clickContext context) {
    super(context);
  }

  /**
   * perform runs the phase
   *
   * @return number of semantic errors found
   */
  public Integer perform () {
    if (context.flag(Verbose))
      context.verbStream.println("Checking ...");
    ASTCheckVisitor checkVis = new ASTCheckVisitor();
    context.configuration.accept(checkVis);
    if (checkVis.numErrors == 0) {
      setStream(context.flag(CheckPrint), context.baseName, "check", "checker", true);
      if (ps != null) {
        //context.configuration.accept(new ASTPrintVisitor(ps));
        ps.close();
      }
    }
    return checkVis.numErrors;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

