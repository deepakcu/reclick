package click;
import java.util.ArrayList;

/**
 * The element class 
 * 
 */
public final class Port extends ASTNode {

 /**
  * The left end of this link
   */
 public final String portName;
 
 /**
  * The type of this port (Input or Output) wrt. the element
  */
 ElementPortType portType;
 
 /**
  * The end element info (end elementname, end port) to which the port is attached to
  * This info is required for generating wires in Verilog
  * The info is set later  
  */
 public Binding endElement;
 
 /**
  * The port to which this element is connected to
  * This info is set later  
  */
 public String endPort;
 
 /**
  * The type of the end element
  * This info is set later  
  */
 public Binding endElementType;
 
   /**
   * Constructor for a port
   */
  public Port (Binding b, int left, int right) {
    super(left, right);
    portName = b.id.string;
    endElement = null;
    endPort = null;    
  }

  
  /**
 * An overloaded constructor to create artificial ports for FromDevice and ToDevice elements
 * @param pname
 * @param left
 * @param right
 */
public Port (String pname, int left, int right) {
	    super(left, right);
	    portName = pname;
	    endElement = null;
	    endPort = null;    
	  }
  
  /**
   * Handles AST visiting for Program nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    if (v == null) return;  // allows more graceful handling of some error conditions
    super.acceptBefore(v);
    v.visitPort(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
