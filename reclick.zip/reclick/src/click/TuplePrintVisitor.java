package click;

import java.text.*;
//import reclick.Tuples.Cursor;

/**
 * This class offers a visitor for printing Tuple's
 * 
 * @version 1.0
 */
public class TuplePrintVisitor extends TupleNullVisitor {

	/**
	 * The reclickStream to which we will print
	 */
	public final clickStream ps;

	/**
	 * The obvious constructor, given that we remember in the visitor the
	 * MPCStream to which we will print
	 * 
	 * @param ps
	 *            the MPCStream to which we will print
	 */
	public TuplePrintVisitor(clickStream ps) {
		this.ps = ps;
	}

	/**
	 * The default print routine, which prints the operator (implicitly prefixed
	 * by a TAB), the target prefixed by a space, src1 prefixed by " <= ", and
	 * src2 prefixed by ", "
	 * 
	 * @param t
	 *            the Tuple to print
	 */
	public void visitEvery(Tuple t) {
		//printField(" ", t.string);
		ps.print(t.tupString);
		ps.println();
	}

	/**
	 * If a Tuple has a Tuple comment, we print it on a second line after the
	 * Tuple itself
	 * 
	 * @param t
	 *            the Tuple we are printing
	 */
	public void visitEveryAfter(Tuple t) {
		/*
		if (t.comment != null)
			ps.printf("\t\t# %s%n", t.comment);
		*/
	}

	/**
	 * Prints the Tuple's in the Block, preceded by a separator with the size of
	 * the Block
	 * 
	 * @param c
	 *            the Cursor bounding the Tuple's of the Block
	 */
	public void visitBlock(Cursor c) {
		//ps.printf("-- %3d ----------------------------------%n", c.size());
		//System.out.println("block size is "+c.size());
		while (c.inRange()) {
			//System.out.println("Tuple id #"+c.index());
			c.tuple().accept(this);
			c.advance();
		}
		//ps.println("----------------------------------------");
	}

	/**
	 * There is nothing that we print before every field
	 * 
	 * @param f
	 *            the TupleField we are printing
	 */
	/*
	public void visitEveryBefore(TupleField f) {

	}
	*/
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
