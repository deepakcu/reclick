package click;
/**
 * This abstract class gives default (no work) implementations for AST visitor
 * classes. It is convenient for subclassing since you need to give
 * implementations only for those methods that do actual work.
 *
 * Note that visit methods for subclass objects (e.g., for DeclConst, a
 * subclass of Decl) defaultly call their parent class visit method, allowing
 * handling of common functionality. However, if you override visitDeclConst,
 * you will need to call visitDecl in the overriding method, if you want it
 * called.
 *
 * Note also that we coded all our accept methods in subclasses so that,
 * before their work, they call super.acceptBefore, and after teir work they
 * call super.acceptAfter. The acceptBefore/After methods for calss XXX call
 * visitXXXBefore/After, allowing work to be done for all nodes belonging to a
 * given part of the AST hierarchy, before or after their normal visit.
 *
 * @version 1.0
 */
public abstract class ASTNullVisitor implements ASTVisitor {

  // methods for work related to every node
  public void visitEveryBefore (ASTNode n) {}
  public void visitEveryAfter  (ASTNode n) {}
  
  // methods for work related to classes not subclassed
  public void visitBinding (Binding b) {}
  
  public void visitConfiguration (Configuration c) {}

  // methods related to Decl classes
  public void visitDeclBefore (Decl d) {}  // these are for all kinds
  public void visitDecl       (Decl d) {}  // this allow factoring of common stuff
  public void visitDeclAfter  (Decl d) {}
  public void visitDecls (Decls dd) {}
  public void visitDeclElement(DeclElement d) { visitDecl(d); }
 
  public void visitLink(Link l) { }
  public void visitElement(Element e) { }
  public void visitPort(Port p) { }

  public void visitStmtConnection  (Stmt s) {}  
  public void visitStmtDeclaration (Stmt s) {}  
  public void visitStmt       (Stmt s) {}  // this allows factoring of common stuff
  public void visitStmtAfter  (Stmt s) {}
  public void visitStmtBefore  (Stmt s) {}
  public void visitStmts (Stmts ss) {}

  // methods for Type classes

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
