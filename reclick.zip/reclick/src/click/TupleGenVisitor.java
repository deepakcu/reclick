package click;
import java.util.*;
import reclick.SymbolTable.VarDesc;
import static reclick.TokenKey.*;
import static reclick.TokenOp.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for generating Tuple
 * code.
 *
 * @version 1.0
 */
public class TupleGenVisitor extends ASTNullVisitor {

  //private RegNeedsVisitor rnv = new RegNeedsVisitor();
	private Tuples programHeadTuples;	
	private Tuples wireTuples;
	private Tuples moduleTuples;
	private Tuples programEndTuples;
	private ArrayList<ClickGraphElement> graphElements;
	

  /**
   * Counts the number of errors encountered; can be used to suppress later
   * phases, etc.
   */
  public int numErrors = 0;

  /**
   * The obvious constructor
 * @param wireTuples 
 * @param registerTuples 
   */
  public TupleGenVisitor (Tuples programHeadTuples,	
		  				  Tuples wireTuples,
		  				  Tuples moduleTuples,
		  				  Tuples programEndTuples,
		  				  ArrayList<ClickGraphElement> graphElements)   {
	  
	  this.programHeadTuples = programHeadTuples;
	  this.moduleTuples	     = moduleTuples;
	  this.wireTuples 		 = wireTuples;
	  this.programEndTuples  = programEndTuples;
	  this.graphElements     = graphElements;
	  //tuples = t;
  }

  /**
   * Generates code for the Program, following these steps:
   * (1) Program prolog: ProgStart, FrmSize, Local tuples (for predefined
   * scope (which probably results in no tuples) and the main routine scope);
   * (2) Code for the main routine's statements and a MainEnd tuple;
   * (3) Code for the main routine's declarations (i.e., its nested procedures
   * and functions);
   * (4) Final things, namely Str constants and the ProgEnd tuple.
   *
   * @param p the Program we are visiting
   */
  public void visitConfiguration (Configuration c) {
	    c.mySymtab.enterScope();
	    //Tuples.add(Tuple.makeProgStart(c.name.toString()));
	    programHeadTuples.add(Tuple.makeProgStart("virtual_dataplane"));
	    c.decls.accept(this);
	    c.mySymtab.exitScope();
  }
  
  public void visitDecls(Decls dd) {
	  
	  ClickGraphElement c=null;
	  
	  //For each element in the declaration
	  for(int i=0;i<dd.declsSize();i++) {
		  Decl d = dd.decls.get(i);
		  assert d instanceof DeclElement;
		  
		  
		  DeclElement element = ((DeclElement)d);  
		  String elementName  = element.type.id.string; //Get name for this element 
		  String instanceName = element.bind.id.string; //Get instance name of this element
		  
		  ArrayList<TupleWire> wires = new ArrayList<TupleWire>();
		  ArrayList<ElementConnection> connections = new ArrayList<ElementConnection>();
		  
		  //Create a Click graph node for this element (for optimization)
		  if( !((element.type.id.string.equals("FromDevice") || element.type.id.string.equals("ToDevice")) ))  {
				  c = new ClickGraphElement(elementName);
		  }
		  
		  
		  //For each port that the element has, make wires that connect inner ports to top level wires
		  for(int j=0;j<((DeclElement)d).ports.size();j++) {
			  Port port = element.ports.get(j);
			  String elementPortName = port.portName;
			  //Find the element and port to which this port is connected to
			  String endElementName  = port.endElement.id.string; //element
			  String endPortName	 = port.endPort;			  //port
			  
			  //Add neighbor information (Only for Click graph generation)
			  if( !((element.type.id.string.equals("FromDevice") || element.type.id.string.equals("ToDevice")) ))  {
				  System.out.println("Element is "+element.type.id.string+" and Neighbor is "+port.endElementType.id.string);
				  if(port.endElementType!=null&&port.portType==ElementPortType.Output) {
					  if( !((port.endElementType.id.string.equals("FromDevice") || port.endElementType.id.string.equals("ToDevice")) ))  {
						c.neighbors.add(port.endElementType.id.string);
						System.out.println("Added ");
					  }
				  }
			  } 
			  
			  //Case: Output Ports
			  //If the element is a FromDevice, we need to connect inputs to netfpga hooks
			  //Similarly, if the element is a ToDevice, we need to connect outputs to netfpga hooks
			  ArrayList<TupleWire> portWires = new ArrayList<TupleWire>(); 
			  ArrayList<String>    elementPorts = new ArrayList<String>(); 
			  if(port.portType==ElementPortType.Output) {
				  
				  
				  /*Xilinx ISE requires that input ports do not be redeclared as wires - So fixing generation of additional wires*/
				  portWires.add(new TupleWire(WireType.Data,instanceName,elementPortName,endElementName,endPortName,"DATA_WIDTH-1",Integer.toString(0)));
				  portWires.add(new TupleWire(WireType.Ctrl,instanceName,elementPortName,endElementName,endPortName,"CTRL_WIDTH-1",Integer.toString(0)));
				  portWires.add(new TupleWire(WireType.Wr,instanceName,elementPortName,endElementName,endPortName,Integer.toString(0),Integer.toString(0)));
				  portWires.add(new TupleWire(WireType.Rdy,instanceName,elementPortName,endElementName,endPortName,Integer.toString(0),Integer.toString(0)));
				  
				  
				  //Only add ports for the primary output ports //TBFixed later
				  if(port.portName.contains("out0")) {
					/*Register requests for this port*/
					portWires.add(new TupleWire(WireType.RegReqIn, instanceName, elementPortName, endElementName, endPortName, Integer.toString(0), Integer.toString(0)));
				  	portWires.add(new TupleWire(WireType.RegAckIn, instanceName, elementPortName, endElementName, endPortName, Integer.toString(0), Integer.toString(0)));
				  	portWires.add(new TupleWire(WireType.RegRdWrLIn, instanceName, elementPortName, endElementName, endPortName, Integer.toString(0), Integer.toString(0)));
				  	portWires.add(new TupleWire(WireType.RegAddrIn, instanceName, elementPortName, endElementName, endPortName, "`UDP_REG_ADDR_WIDTH-1", Integer.toString(0)));
				  	portWires.add(new TupleWire(WireType.RegDataIn, instanceName, elementPortName, endElementName, endPortName, "`CPCI_NF2_DATA_WIDTH-1", Integer.toString(0)));
				  	portWires.add(new TupleWire(WireType.RegSrcIn, instanceName, elementPortName, endElementName, endPortName, "UDP_REG_SRC_WIDTH-1", Integer.toString(0)));
				  }
				  
				  elementPorts.add("out_data_"+elementPortName);
				  elementPorts.add("out_ctrl_"+elementPortName);
				  elementPorts.add("out_wr_"+elementPortName);
				  elementPorts.add("out_rdy_"+elementPortName);
				  
				  /*Register requests for this port*/
				  //Only add ports for the primary output ports //TBFixed later
				  if(port.portName.contains("out0")) {
					  elementPorts.add("reg_req_out");
					  elementPorts.add("reg_ack_out");
					  elementPorts.add("reg_rd_wr_L_out");
					  elementPorts.add("reg_addr_out");
					  elementPorts.add("reg_data_out");
					  elementPorts.add("reg_src_out");
				  }
				  
			  }

			  //Case: Input Ports
			  //Note the swap in the port names here to avoid duplicate wire names that reference the same wire
			  //Ex: x_out_in_y and y_in_out_x reference the same wire
			  if(port.portType==ElementPortType.Input) {
				  
				  /*Xilinx ISE requires that input ports do not be redeclared as wires - So fixing generation of additional wires*/
				  //if(!instanceName.contains("netfpga")&&!endElementName.contains("netfpga")) {
					  portWires.add(new TupleWire(WireType.Data, endElementName,endPortName,instanceName,elementPortName,"DATA_WIDTH-1",Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.Ctrl, endElementName,endPortName,instanceName,elementPortName,"CTRL_WIDTH-1",Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.Wr, endElementName,endPortName,instanceName,elementPortName,Integer.toString(0),Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.Rdy, endElementName,endPortName,instanceName,elementPortName,Integer.toString(0),Integer.toString(0)));
				  //}
				  
				  /*Register requests for this port*/
				  //Only add ports for the primary output ports //TBFixed later
				  if(endPortName.contains("out0")||endElementName.contains("netfpga")) {
					  portWires.add(new TupleWire(WireType.RegReqOut, endElementName, endPortName, instanceName, elementPortName, Integer.toString(0), Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.RegAckOut, endElementName, endPortName, instanceName, elementPortName, Integer.toString(0), Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.RegRdWrLOut, endElementName, endPortName, instanceName, elementPortName, Integer.toString(0), Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.RegAddrOut, endElementName, endPortName, instanceName, elementPortName, "`UDP_REG_ADDR_WIDTH-1", Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.RegDataOut, endElementName, endPortName, instanceName, elementPortName, "`CPCI_NF2_DATA_WIDTH-1", Integer.toString(0)));
					  portWires.add(new TupleWire(WireType.RegSrcOut, endElementName, endPortName, instanceName, elementPortName, "UDP_REG_SRC_WIDTH-1", Integer.toString(0)));
				  }
				  
				  System.out.println("DEEPAK: Element name is "+instanceName+"Port name is "+elementPortName);
				  elementPorts.add("in_data_"+elementPortName);
				  elementPorts.add("in_ctrl_"+elementPortName);
				  elementPorts.add("in_wr_"+elementPortName);
				  elementPorts.add("in_rdy_"+elementPortName);
				  
				  /*Register requests for this port*/ //TBFixed later
				  if(endPortName.contains("out0")||endElementName.contains("netfpga")) {
					  elementPorts.add("reg_req_in");
					  elementPorts.add("reg_ack_in");
					  elementPorts.add("reg_rd_wr_L_in");
					  elementPorts.add("reg_addr_in");
					  elementPorts.add("reg_data_in");
					  elementPorts.add("reg_src_in");
				  }
				  
			  }
			 
			  //Add wires, making sure that there are no duplicate wire names
			  for(int k=0;k<portWires.size();k++) {
				TupleWire wire = portWires.get(k);
				
				if(!wire.endElement.contains("netfpga")&&
				   !wire.srcElement.contains("netfpga")&&
			   	   !wireTuples.tuples.contains(Tuple.makeWire(wire))) {
						   wireTuples.add(Tuple.makeWire(wire)); //data width
				}
					
	  		    //Make a connection between the element port and the wire
	  		    //A connection is basically the tuple (port,wire)
	  		    //For now, we just create element connections. We then generate tuples for each connection later
				ElementConnection e = new ElementConnection(elementPorts.get(k),portWires.get(k).prettyName());
				
				//Add connections
				connections.add(e);
			  }
		  }
		  
		  if( !((element.type.id.string.equals("FromDevice") || element.type.id.string.equals("ToDevice")) ))  {
			  graphElements.add(c);
			  //System.out.println("Wrote "+c.neighbors.size()+"elements ");
		  }
		  
		  //Generate tuples for each connection
		  System.out.println("Now making connections for "+elementName+" connections is "+connections.size());
		  moduleTuples.add(Tuple.makeModule(elementName,instanceName,connections));
	  }
  }
  
  
  
  
  public void visitStmtDeclaration (StmtDeclaration s) {
	  //TBD
  }
  
  public void visitStmtConnection  (StmtConnection s) {
	  //TBD
  }

}

/**
 * Describes a port of an element and the wire to which it must be connected to 
 * @author Deepak
 *
 */
class ElementConnection
{
	String port;
	String wire;
	
	ElementConnection(String p, String w) {
		port = p;
		wire = w;
	}
}


// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
