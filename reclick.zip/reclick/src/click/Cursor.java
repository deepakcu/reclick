package click;

import java.util.ArrayList;
import java.util.HashSet;

//import reclick.Tuples.Cursor;

public class Cursor {


    /**
     * Index of the first Tuple in the range of the Cursor; 0 is first in the
     * whole sequence, etc. By first, we mean the one with smallest index.
     */
    private int lo;

    /**
     * Index of the last Tuple in the range of the Cursor. By last we mean the
     * one with the largest index.
     */
    private int hi;

    /**
     * The index of the current Tuple, i.e., where the Cursor is positioned
     */
    private int idx;

    /**
     * Whether the Cursor scans up (the default) or down
     */
    private boolean up = true;

    
    /**
     * A private copy of tuples
     */
    private static ArrayList<Tuple> tuples;

    
    /**
     * We remember all active Cursor objects, so that we can fix them up when
     * Tuples are added/deleted in the middle of the sequence
     */
    private static HashSet<Cursor> Cursors = new HashSet<Cursor>(3, 0.5f);

    /**
     * The updates all active Cursor objects given that, at index idx we
     * inserted/removed delta Tuple's (positive delate for insertion, negative
     * for deletion)
     *
     * @param idx the index at which we inserted/deleted Tuple's
     * @param delta the number of Tuple's inserted (negative means deleted)
     */
    private static void updateCursors (int idx, int delta) {
      for (Cursor c : Cursors) {
        c.update(idx, delta);
      }
    }
    
    /**
     * The default constructor ranges over the whole sequence
     */
    public Cursor (Tuples t) {
      this(0, t.tuples.size()-1);
      tuples = t.tuples;
      
    }

    /**
     * Constructs a Cursor that goes upward over the given lo/hi range
     *
     * @param lo index of the first Tuple of the range
     * @param hi index of the last Tuple of the range
     */
    public Cursor (int lo, int hi) {
      this(lo, hi, true);
    }

    /**
     * Constructs a Cursor that goes in the desired direction over the given
     * range
     *
     * @param lo the smallest index in the range
     * @param hi the largest index in the range
     * @param up the direction (true = upwards, false = downwards)
     */
    public Cursor (int lo, int hi, boolean up) {
      reset(lo, hi, up);
    }

    /**
     * Resets a Cursor in terms of its range and direction; given the range
     * and direction, it sets the index to the first Tuple to scan in that
     * direction
     *
     * @param lo smallest index of the range
     * @param hi largest index of the range
     * @param up the direction (upwards = true, downwards = false)
     */
    public void reset (int lo, int hi, boolean up) {
      
      //assert 0 <= lo && lo <= tuples.size();
      //assert (0 <= hi && hi <= tuples.size()) || (hi == lo-1);
      //assert (lo-1) <= hi;
      this.lo = lo;
      this.hi = hi;
      this.up = up;
      this.idx = (up ? lo : hi);
      Cursors.add(this);
    }

    /**
     * Constructs a new Cursor with the same range, direction, and current
     * index as the one being cloned
     *
     * @return a copy of this Cursor object
     */
    public Object clone () {
      Cursor result = new Cursor(lo, hi, up);
      result.idx = idx;
      Cursors.add(result);
      return result;
    }

    /**
     * Checks whether the index is still in the range; it is normal to
     * terminate iteration when inRange returns false
     *
     * @return whether the index of the Cursor is in its range
     */
    public boolean inRange () {
      return (lo <= idx && idx <= hi);
    }

    /**
     * Advance the Cursor index by one IN ITS CURRENT DIRECTION
     */
    public void advance () {
      advance(1);
    }

    /**
     * Advance the Cursor index by the indicated amount IN ITS CURRENT
     * DIRECTION
     *
     * @param amount the amount by which to increment the index (in its
     * current direction)
     */
    public void advance (int amount) {
      if (up) {
        idx += amount;
      }
      else {
        idx -= amount;
      }
    }

    /**
     * Called to indicate that the Cursor is no longer active and need not
     * track edits any longer
     */
    public void release () {
      // indicate that one is done with a Cursor:
      // - it will no longer track insertions and deletions
      // - one must call done() for the Cursor ever to be reclaimed
      Cursors.remove(this);
    }

    /**
     * Returns the current index
     *
     * @return the current index of the Cursor
     */
    public int index () {
      return idx;
    }

    /**
     * Returns the smallest index of the range
     *
     * @return the smallest index of the Cursor's range
     */
    public int minValue () {
      return lo;
    }

    /**
     * Returns the largest index of the range
     *
     * @return the largest index of the Cursor's range
     */
    public int maxValue () {
      return hi;
    }

    /**
     * Returns the number of Tuples in the range
     *
     * @return the number of Tuples in the range of the Cursor
     */
    public int size () {
      return hi - lo + 1;
    }

    /**
     * Helper routine for adjusting an index after an edit
     *
     * @param old the previous index value
     * @param idx the location of the edit
     * @param delta the number of Tuple's added (negative for deletions)
     * @param drop the amount by which to reduce the result if old lies in a
     * deleted region
     * @return the adjusted index
     */
    private int adjust (int old, int idx, int delta, int drop) {
      if (old < idx) return old;
      int n = old + delta;
      if (n >= idx) return n;
      return idx - drop;
    }

    /**
     * Adjusts the lo, hi, and idx field of this Cursor after an edit
     *
     * @param index the location of the edit
     * @param delta the number of Tuple's added (negative for deleted)
     */
    public void update (int index, int delta) {
      // indicates that delta tuples were added at (before) idx
      // a negative delta indicates deletion
      lo  = adjust(lo , index, delta, 0);
      hi  = adjust(hi , index, delta, 1);
      idx = adjust(idx, index, delta, 1);
    }

    /**
     * Returns the Tuple at the current index
     *
     * @return the Tuple at the current index; guaranteed ok only if inRange
     * is true
     */
    public Tuple tuple () {
      return (Tuple)tuples.get(idx);
    }

    /**
     * Deletes the Tuple at the current position and updates all registered
     * Cursor's; leaves the Cursor on the FOLLOWING Tuple
     */
    public void deleteTuple () {
      tuples.remove(idx);
      idx++;
      updateCursors(idx-1, -1);
    }

    /**
     * Inserts a Tuple BEFORE the current index, leaving the Cursor on the
     * current Tuple (at its new index); updates all registered Cursor's
     *
     * @param t the Tuple to insert
     */
    public void insertTuple (Tuple t) {
      tuples.add(idx, t);
      updateCursors(idx, 1);
    }

    /**
     * Inserts a Tuple AFTER the current index, leaving the Cursor on the
     * current Tuple; updates all registered Cursor's
     *
     * @param t the Tuple to insert
     */
    public void insertTupleAfter (Tuple t) {
      tuples.add(idx+1, t);
      updateCursors(idx+1, 1);
    }

    /**
     * Replaces the Tuple at the current index, leaving the Cursor on the new
     * Tuple
     *
     * @param t the Tuple to replace the current one
     */
    public void replaceTuple (Tuple t) {
      tuples.set(idx, t);
      // no need to update cursors in this case
    }

  
}
