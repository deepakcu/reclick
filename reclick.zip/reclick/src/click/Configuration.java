package click;
import java.util.ArrayList;
/**
 * The class Program represents a <i>Pascal</i> program.
 *
 * Every <i>Pascal</i> program consists of a list of declarations and a block.
 * The declarations include all those objects local to the program block and
 * the block includes those statements intended to execute upon those objects.
 * This information is maintained by member variables of type
 * Decls and Block.
 *
 * @version 1.0
 */
public final class Configuration extends ASTNode {

  /**
   * A list of statements in the Click program
   * 
   */
  public final Stmts stmts; //Deepak made null
  
  /**
   * A list of statements in the Click program
   * 
   */
  public final Decls decls; //Deepak made null

  /**
   * mySymtab points to the SymbolTable for the Decl nodes in decls
   */
  public SymbolTable mySymtab;

  /**
   * Creates a new Configuration
   *
   * @param dd     declarations for the program block.
   * @param blk    code block of the program.
   * @param left   starting position of program declaration.
   * @param right  ending position of program declaration.
   */
  public Configuration (Stmts ss, Decls dd, int left, int right) {
    super(left, right);
    stmts = ss;
    decls = dd;
  }

  /**
   * Handles AST visiting for Program nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    if (v == null) return;  // allows more graceful handling of some error conditions
    super.acceptBefore(v);
    v.visitConfiguration(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
