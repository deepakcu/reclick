package click;
import java.util.ArrayList;

/**
 * The element class 
 * 
 */
/**
 * @author Deepak
 *
 */
public final class Element extends ASTNode {

 /**
  * A string for name of the element
   */
 public final Binding name;
 
 
 /**
  * The left port of the element in the connection
  * Note that elements can have multiple ports. They are
  * processed during tuple generation
  * 
   */
 public Port leftPort;
 
 /**
  * The right port of the element in the connection
  * Note that elements can have multiple ports. They are
  * processed during tuple generation
  * 
  */
 public Port rightPort;
 
 /**
  * The left link 
  * 
   */
 public Link leftLink;
 
 /**
  * The right port of the element in the connection
  * Note that elements can have multiple ports. They are
  * processed during tuple generation
  * 
  */
 public Port rightLink;
 
   /**
   * Creates a new Program instance given the top-level Decls, Block, and
   * source (start/end) position
   *
   * @param dd     declarations for the program block.
   * @param blk    code block of the program.
   * @param left   starting position of program declaration.
   * @param right  ending position of program declaration.
   */
  public Element (Binding n, int left, int right) {
    super(left, right);
    name = n;
    leftPort = null;
    rightPort = null;
  }

  /**
   * Handles AST visiting for Program nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    if (v == null) return;  // allows more graceful handling of some error conditions
    super.acceptBefore(v);
    v.visitElement(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
