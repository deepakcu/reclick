package click;
import java.util.ArrayList;

/**
 * Representation for a field declaration within a record declaration.
 *
 * @version 1.0
 */
public class DeclElement extends Decl {

  /**
   * Type of the field declaration
   */
  public Binding type;
  // Note: cannot be final because we allocate DeclField objects and set their
  // type later

  public ArrayList<Port> ports;
	
  /**
   * indicates the offset of this field within a record
   */
  //int offset = -1;  // -1 means "not yet assigned"

  /**
   * Creates a new DeclField instance, given its Binding (name)
   *
   * @param b the binding to this field declaration
   */
  public DeclElement (Binding b) {
    super(b, b.pos, -1);
    ports = new ArrayList<Port>();
  }

  /**
   * A naive search utility method to see if the port already exists in the
   * element declaration
   * 
   * @param p the port that is being checked for existence
   */
  public boolean hasPort (Port p) {
     for(int i=0;i<ports.size();i++) {
    	 if(ports.get(i).portName.equals(p.portName))
    		 return true;
     }
     return false;
  }
  
  /**
   * Handles AST visiting for DeclField nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclElement(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

