package click;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.regex.*;

/**
 * The library class - Builds a library of elements 
 * from /elements directory and writes them to elements.lib 
 * This library can be used by Click programs
 * 
 */
public class GenLibrary {
	
	public static ArrayList<Module> modules;
	
	/**
	 * getFilesInDirectory 
	 * scans a directory and lists all internal files
	 * @param dirName
	 * @return
	 */
	public static String[] getFilesInDirectory(String dirName) {
		String[] children;
		File dir = new File(dirName);

		children = dir.list();
		if (children == null) {
			System.err.println("Directory does not exist or not a valid directory");
			System.exit(-1);
		    // Either dir does not exist or is not a directory
		} else {
		    for (int i=0; i<children.length; i++) {
		        // Get filename of file or directory
		        String filename = children[i];
		    }
		}
		return children;
	}
	
	
	
	
	/**
	 * parse each line and match patterns
	 * @param line
	 */
	public static void parseLine(Module m, String line) {
		Pattern pat;
		Matcher mat;
		pat = Pattern.compile("module (\\w*)");
		mat = pat.matcher(line);
		if(mat.find()) {
			m.name = mat.group(1);
			
		}
		pat = Pattern.compile("in_data_(\\w*)");
		mat = pat.matcher(line);
		if(mat.find()&&line.contains("input") && line.contains("[") && line.contains("]")) {
			//System.out.println(" Port name is "+mat.group(1));
			m.ports.add(new ModulePort("input",mat.group(1)));
			//System.out.println("Line is"+line);
		}	
		
		pat = Pattern.compile("out_data_(\\w*)");
		mat = pat.matcher(line);
		if(mat.find()&&line.contains("output")  && line.contains("[") && line.contains("]")) {
			//System.out.println(" Port name is "+mat.group(1));
			m.ports.add(new ModulePort("output",mat.group(1)));
			//System.out.println("Line is"+line);
		}
	}
	
	/**
	 * 
	 */
	public static void writeLibrary(String libFile) {
		try
		{
			FileOutputStream fstream = new FileOutputStream(libFile);
			DataOutputStream out = new DataOutputStream(fstream);
            for(int i=0;i<modules.size();i++) {
            	Module m = modules.get(i);
            	out.writeBytes(m.name+" ");
            	for(int j=0;j<m.ports.size();j++) {
            		out.writeBytes(m.ports.get(j).iotype+" "+m.ports.get(j).portname+" ");
            	}
            	
            	if(i+1==modules.size())
            		out.writeBytes("");
            	else
            		out.writeBytes("\n");
            	
            }
			out.close();
		} 
        catch (Exception e)	{
        	System.err.println("Error in writing the file");
        }
	}
	
	
	/**
	 * parses a filename and adds i/o ports and parameters to library
	 * @param fileName
	 */
	public static void parseFile(Module m,String fileName) {
		try
		{
			FileInputStream fstream = new FileInputStream(fileName);
			DataInputStream in = new DataInputStream(fstream);
			
            while (in.available() !=0)	{
                // Print file line to screen
				//System.out.println (in.readLine());
				parseLine(m,in.readLine());
			}

			in.close();
			System.out.print("Module name is "+m.name);
		} 
        catch (Exception e)	{
			System.err.println("File input error");
			e.printStackTrace();
			System.exit(-1);
		}	
	}
	
	
	/**
	 * The main method for building library of components
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] children;
		String elementsDir = args[0];
		String libraryFile = "click.lib";
		children = getFilesInDirectory(elementsDir);
		try {
			assert children.length!=0;
		}catch(Exception e) { 
			System.err.println("Element library is empty");
			System.exit(-1);
		}

		modules = new ArrayList<Module>();
		
		for(int i=0;i<children.length;i++) {
			if(children[i].contains(".v")) { //Parse verilog RTL inputs
				System.out.println("Parsing file "+children[i]);
				Module m = new Module();
				parseFile(m,elementsDir+File.separatorChar+children[i]); 
				modules.add(m);
			}
		}
		
		writeLibrary(libraryFile);
		System.out.println("Library file built in "+libraryFile);
	}
	
}


class ModulePort {
	public String iotype;
	public String portname;
	
	ModulePort(String type, String name) {
		iotype   = type;
		portname = name;
	}
}

class Module {
	public String name;
	public ArrayList<ModulePort> ports;
	
	Module() {
		ports = new ArrayList<ModulePort>();
	}
}
