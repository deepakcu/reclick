package click;
/**
 * This interface defines things common to all AST (Abstract Syntax Tree)
 * visitor classes.
 *
 * We omit javadoc on individual methods, since their interface is obvious.
 * @see ASTNullVisitor for additional explanation
 * @version 1.0
 */
public interface ASTVisitor {

  // methods for work related to every node
  public void visitEveryBefore (ASTNode n);
  public void visitEveryAfter  (ASTNode n);
  
  public void visitStmts (Stmts ss);
  public void visitConfiguration (Configuration c);
  public void visitBinding (Binding b);
  public void visitElement (Element e);
  public void visitLink (Link l);
  public void visitPort (Port p);
  
  // methods related to Decl classes
  public void visitDeclBefore (Decl d);  // these are for all kinds
  public void visitDeclAfter (Decl d);  // these are for all kinds
  public void visitDecl       (Decl d);
  public void visitDeclElement(DeclElement d);
  public void visitDecls      (Decls d);
  // methods for Expr classes
  
  // methods for Stmt classes
  public void visitStmtBefore (Stmt s);  // these are for all kinds
  public void visitStmt       (Stmt s);
  public void visitStmtAfter  (Stmt s);

  public void visitStmtDeclaration (StmtDeclaration s);
  public void visitStmtConnection  (StmtConnection s);
  
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
