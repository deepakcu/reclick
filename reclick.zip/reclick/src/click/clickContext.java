package click;
import java.util.*;

/**
 * This class maintains flags and similar context for the Mini-Pascal compiler
 *
 * @version 1.0
 */
public class clickContext {

  /**
   * Base name for forming filenames
   */
  public String baseName;
  
  /**
   * Directory to store generated RTL files
   */
  public String rtlDirectory;
  
  /**
   * Name of generated RTL file
   */
  public String rtlName;
  

  /**
   * Stream for verbose output
   */
  public clickStream verbStream;

  /**
   * Stream for error output
   */
  public clickStream errStream;

  /**
   * Input file name
   */
  public String inFileName;

  /**
   * The scanner instance for this compilation
   */
  //public clickScanner scanner; //Deepak: Modified to use JFlex as the scanner i/f
  public Lexer scanner;
  /**
   * The parser instance for this compilation
   */
  public Parser parser;

  /**
   * The Component built by the parser
   */
  public Configuration configuration;
  
  //Deepak: Just for testing
  public Binding binding;

  /**
   * The obvious constructor that initializes the two output streams
   *
   * @param verbStream stream for verbose output
   * @param errStream stream for error output
   */
  public clickContext (clickStream verbStream, clickStream errStream) {
    this.verbStream = verbStream;
    this.errStream  = errStream;
  }

  /**
   * Maps flag letters to flags; also helps insure no duplicate letters
   */
  public static final HashMap<Character,Flag> letterToFlag = new HashMap<Character,Flag>(25);

  /**
   * Flags for this context object
   */
  public final EnumSet<Flag> flags = EnumSet.copyOf(DefaultFlags);

  /**
   * Accessor method to see if a particular flag is set
   *
   * @param flag the Flag to test
   * @return a boolean, true iff that flag is set
   */
  public boolean flag (Flag flag) {
    return flags.contains(flag);
  }

  /**
   * Default flags
   */
  public static final EnumSet<Flag> DefaultFlags = EnumSet.of(
    Flag.Generate, Flag.ClickGraph//, Flag.LowerPrint, Flag.BBPrint, /*Flag.XBBPrint,*/
    //Flag.VNPrint , Flag.RAPrint   , Flag.DJPrint, Flag.DoRegAlloc,
    //Flag.ParsePrint//, Flag.Debug //Deepak enable flag to print
    );

  /**
   * Enumeration for the command flags
   */
  public static enum Flag {
    Verbose   ('v', "verbose output",
               "to request verbose output"),
    TokenPrint('t', "token output",
               "to control output of tokens to a .token file"),
    ParsePrint('p', "parse tree output",
               "to control printing of AST to a .parse file"),
    CheckPrint('c', "checked tree output",
               "to control printing of AST after checking to a .check file"),
    AllocPrint('a', "allocated tree output",
               "to control printing of AST after allocation to a .alloc file"),
    TuplePrint('u', "tuple output",
               "to control printing of initial tuples to a .tuple file"),
    LowerPrint('l', "lowered tuple output",
               "to control printing of tuple after lowering to a .lower file"),
    Generate  ('g', "code output",
               "to control generation of assembly code"),
    ClickGraph ('h', "click graph",
    			"to control click graph generation for optimization"),           
    BBPrint   ('b', "basic block output",
               "to control printing of .tuple basic blocks to a .bb file"),
    XBBPrint  ('x', "extended basic block output",
               "to control printing of .tuple extended basic blocks to a .xbb file"),
    VNPrint   ('n', "value numbering info",
               "to control printing of value numering info to .vn* files"),
    RAPrint   ('r', "register allocation info",
               "to control printing of register allocation info to .ra* files"),
    DJPrint   ('j', "jump/dead opt info",
               "to control printing of dead code/jump optimization info to .jmp* files"),
    DoRegAlloc('R', "run register allocation",
               "to control whether register allocation is performed"),
    Debug('d', "debugging output",
          "for debugging output") {
      void toggle (EnumSet<Flag> flags) { flags.add(this); }
    },
    
    ParserDebug('P', "parser debugging output",
                "for parser debugging output") {
      void toggle (EnumSet<Flag> flags) { flags.add(this); }
    };

    /**
     * Flag letter on the command line that sets/toggles this flag
     */
    public final Character letter;

    /**
     * Short description of flag for verbose output
     */
    public final String desc;

    /**
     * Command line help string for the flag
     */
    public final String help;

    /**
     * Constructor that sets the flag's command line letter
     *
     * @param letter the Character on the command line that will set/toggle
     * this flag
     * @param desc a String describing the flag for verbose output
     * @param help a help String describing the flag
     */
    Flag (Character letter, String desc, String help) {
      this.letter = letter;
      this.desc   = desc;
      this.help   = help;
      assert !letterToFlag.containsKey(letter);
      letterToFlag.put(letter, this);
    }

    void toggle (EnumSet<Flag> flags) {
      if (flags.contains(this))
        flags.remove(this);
      else
        flags.add(this);
    }

  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

