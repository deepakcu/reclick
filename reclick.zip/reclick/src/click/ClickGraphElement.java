package click;
import java.util.ArrayList;

/**
 * Represents an element of the click graph (node)
 * @author Deepak
 *
 */
public class ClickGraphElement {

	String elementName;
	ArrayList<String> neighbors;
	
	public ClickGraphElement(String elementName) {
		super();
		this.elementName = elementName;
		this.neighbors = new ArrayList<String>();
	}
	
	
	
}
