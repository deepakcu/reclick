package reclick;

public class TupletSchedule {
	
	String condition;
	int portNumber;
	
	TupletSchedule(String condition, int portNumber) {
		this.condition  = condition;
		this.portNumber = portNumber;
	}
}
