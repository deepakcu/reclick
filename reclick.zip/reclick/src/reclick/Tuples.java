package reclick;
import java.util.*;

/**
 * This class defines the Tuple sequence built and edited in the Mini-Pascal
 * compiler. It offers a nested Cursor type for scanning and editing the
 * sequence.
 *
 * @version 1.0
 */
public class Tuples  {

  /**
   * We represented the Tuple sequence with a private ArrayList
   *
   */
  public ArrayList<Tuple> tuples;// = new ArrayList<Tuple>();

  /**
   * A header that must prefix the tuple list
   *
   */
  String tupleHeader;
  
  /**
   * A trailer that must suffixes the tuple list
   *
   */
  String tupleTrailer;
  
  
  
  /**
   * The trivial constructor, private so that we control access to it
   * Deepak changed to public
   *
   */
  public Tuples (String th,String tt) {
	  tuples = new ArrayList<Tuple>();
	  tupleHeader  = th;
	  tupleTrailer = tt;
  }

  
  /**
 * A utility method to get total number of tuples in this class
 * @return total number of tuples belonging to this category
 */
public int totalTuples() {
	  return this.tuples.size();
  }
  
  /**
   * The natural accept method, this creates a Cursor that ranges over the
   * entire sequence and calls the visitor on each Tuple in turn
   *
   * @param tv the TupleVisitor to visit each Tuple
   */
  public void accept (TupleVisitor tv) {
    for (Cursor c = new Cursor(this); c.inRange(); c.advance()) {
      c.tuple().accept(tv);
    }
  }

  /**
   * Adds a Tuple to the end of the Tuples sequence under construction
   *
   * @param t the Tuple to add
   */
  public void add (Tuple t) {
    // When the class is implemented, this method will add a tuple to the
    // growing list of tuples. For now, we'll just use a simple ArrayList, but
    // later this may need to be more sophisticated.
    tuples.add(t);
    System.out.println("Added tuple"+t.tupString);
  }

  /**
   * Provides the obvious iterator, which returns each Tuple in order from
   * first to last
   *
   * @return an Iterator that returns each Tuple from first to last
   */
  public Iterator iterator () {
    return tuples.iterator();
  }


  /**
   * A Tuples.Cursor gives a way of walking over a contiguous subset of the
   * tuples, and is intended to work correctly in the presence of insertion
   * and deletion of tuples.
   */
  //public static class Cursor {}
  
  
  

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

