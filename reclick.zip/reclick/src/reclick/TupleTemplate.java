package reclick;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

/**
 * A class that defines Verilog Templates
 *
 * @version 1.0
 */
public class TupleTemplate  {
	
  	
  public static String templateStr;
  
  /**
   * The obvious constructor
   * @version 1.0
   */ 
  TupleTemplate() {
	  templateStr = "";
  }
  
  public static String ProgStartTemplate(String progName) {
	  templateStr = "";
	  return templateStr.concat("\nmodule "+progName+"\n")
					    .concat(getTemplate("params"))
					    .concat(getTemplate("ioports"));  
  }
  
  public static String ProgEndTemplate() {
	  return templateStr.concat(getTemplate("program_tail"));	  
  }
  
  public static String inputPortTemplate(String portName) {
	  templateStr = "";
	  return templateStr.concat("\ninput [DATA_WIDTH-1:0] in_data_"+portName+",")
	  			 		.concat("\ninput [CTRL_WIDTH-1:0] in_ctrl_"+portName+",")
	  			 		.concat("\ninput  in_wr_"+portName+",")
	  			 		.concat("\noutput in_rdy_"+portName+",");
	  
  }
  
  public static String outputPortTemplate(String portName) {
	  templateStr = "";
	  return templateStr.concat("\noutput [DATA_WIDTH-1:0] out_data_"+portName+",")
	  			 		.concat("\noutput [CTRL_WIDTH-1:0] out_ctrl_"+portName+",")
	  			 		.concat("\noutput out_wr_"+portName+",")
	  			 		.concat("\ninput  out_rdy_"+portName+",");
  }
  
  public static String wireTemplate(String wireName, String high, String low) {
	  templateStr = "";
	  if(high.equals("0")&&low.equals("0"))
		  return templateStr.concat("wire "+wireName+";");
	  else
		  return templateStr.concat("wire ["+high+":"+low+"] "+wireName+";");
  }
  
  public static String regTemplate(String wireName, String high, String low) {
	  templateStr = "";
	  if(high.equals("0")&&low.equals("0"))
		  return templateStr.concat("reg "+wireName+";");
	  else
		  return templateStr.concat("reg ["+high+":"+low+"] "+wireName+";");
  }
  
  /**
 * Makes a tuple for conditional set statements 
 * @param caseTuplets
 * @return
 */
public static String setTemplate(ArrayList<TupletSet> caseTuplets) {
	  templateStr = "";
	  
	  //Accumulate tuplets and generate a pretty tuple
	  TupletSet tuplet = null;
	  assert caseTuplets.size()>0;
	  //The target set field must match across all the if-else statements
	  
	  for(int i=0;i<caseTuplets.size();i++) {
		  
		  tuplet = caseTuplets.get(i);
		  
		  //Need to add word info for the first tuplet
		  if(i==0) {
			  if(tuplet.condition==null) 
				  templateStr = templateStr.concat("\n\t\t"+tuplet.word+": begin "+"execute_data["+tuplet.high+":"+tuplet.low+"] <= "+tuplet.exprString);
			  else 
				  templateStr = templateStr.concat("\n\t\t"+tuplet.word+": begin "+"execute_word["+tuplet.high+":"+tuplet.low+"] <= ("+tuplet.condition+")?"+tuplet.exprString);
		  }
		  //For words!= first word
		  else {
			  if(tuplet.condition==null)
				  templateStr = templateStr.concat("\n\t\t : "+tuplet.exprString);
			  else
				  templateStr = templateStr.concat("\n\t\t : ("+tuplet.condition+")?"+tuplet.exprString); 
		  }
	  }
	  templateStr = templateStr.concat(";");
	  
	  if(tuplet.condition==null) {
		  if(tuplet.max!=tuplet.high)
			  templateStr = templateStr.concat("\n\t\t\t execute_data["+tuplet.max+":"+(tuplet.high+1)+"] <= shift_shift_data["+tuplet.max+":"+(tuplet.high+1)+"];");
		  if(tuplet.low!=tuplet.min)
			  templateStr = templateStr.concat("\n\t\t\t execute_data["+(tuplet.low-1)+":"+tuplet.min+"] <= shift_shift_data["+(tuplet.low-1)+":"+tuplet.min+"];");
	  }
	  
	  else {
		  if(tuplet.max!=tuplet.high)
			  templateStr = templateStr.concat("\n\t\t\t execute_data["+tuplet.max+":"+(tuplet.high+1)+"] <= ("+tuplet.condition+")?shift_shift_data["+tuplet.max+":"+(tuplet.high+1)+"];");
		  if(tuplet.min!=tuplet.low)
			  templateStr = templateStr.concat("\n\t\t\t execute_data["+(tuplet.low-1)+":"+tuplet.min+"] <= ("+tuplet.condition+")?shift_shift_data["+(tuplet.low-1)+":"+tuplet.min+"];");
	  }
	  
	  templateStr = templateStr.concat("\n\t\t\t execute_ctrl <= shift_shift_ctrl; ");
	  templateStr = templateStr.concat("\n\t\t\t execute_wr   <= shift_shift_wr; ");
	  templateStr = templateStr.concat("\n\t\t end");
	  
	  return templateStr;
  }
  
  /**
 * Makes a tuple for schedule generation (muxing packets to output ports)
 * @param scheduleTuplets
 * @return
 */
public static String scheduleTemplate(ArrayList<TupletSchedule> scheduleTuplets) {
	  templateStr = "";
	  
	  //Accumulate tuplets and generate a pretty tuple
	  for(int i=0;i<scheduleTuplets.size();i++) {
		  
		  TupletSchedule tuplet = scheduleTuplets.get(i);
		  
		  if(i==0) {
			  assert tuplet.condition!=null;
			  templateStr = templateStr.concat("\n\t\t assign channel_select = ("+tuplet.condition+")?"+tuplet.portNumber);
		  }
		  else {
			  if(tuplet.condition==null)
				  templateStr = templateStr.concat("\n\t\t : "+tuplet.portNumber);
			  else
				  templateStr = templateStr.concat("\n\t\t : ("+tuplet.condition+")?"+tuplet.portNumber);
		  }
	  }
	  templateStr = templateStr.concat(";\n");
	  templateStr = templateStr.concat(getTemplate("schedule"));
	  return templateStr;
  }
  
  
  /**
 * Makes a conditional assignment template for assignments to ordinary variables
 * @param ordinaryVarTuplets
 * @return
 */
public static String ordinaryVarTemplate(ArrayList<TupletOrdinaryVar> ordinaryVarTuplets) {
	  templateStr = "";
	  
	  //Accumulate tuplets and generate a pretty tuple
	  for(int i=0;i<ordinaryVarTuplets.size();i++) {
		  
		  TupletOrdinaryVar tuplet = ordinaryVarTuplets.get(i);
		  
		  if(i==0) {
			  assert tuplet.condition!=null;
			  templateStr = templateStr.concat("\n\t\t assign "+tuplet.variable+" = ("+tuplet.condition+")?"+tuplet.exprString);
		  }
		  else {
			  if(tuplet.condition==null)
				  templateStr = templateStr.concat("\n\t\t : "+tuplet.exprString);
			  else
				  templateStr = templateStr.concat("\n\t\t : ("+tuplet.condition+")?"+tuplet.exprString);
		  }
	  }
	  templateStr = templateStr.concat(";");
	  return templateStr;
  }
  
  public static String getTemplate(int word, String fName, int high, int low) {
	  templateStr = "";
	  return templateStr.concat("\n\t\t"+word+": begin "+fName+" <= shift_input_data["+high+":"+low+"]; end");
  }
  
  /*An overloaded version of the get template for default case generation*/
  public static String getTemplate(String word, ArrayList<String> decodeVariables) {
	  templateStr = "";	  
	  templateStr = templateStr.concat("\n\t\t"+word+": begin ");
	  templateStr = templateStr.concat("if(reset) begin");
	  for(int i=0;i<decodeVariables.size();i++) {
		  templateStr = templateStr.concat("\n\t\t\t"+decodeVariables.get(i)+" <= 0;");
	  }
	  templateStr = templateStr.concat("\n\t\tend");
	  templateStr = templateStr.concat("\n\t\tend");
	  return templateStr;
  }
  
  public static String wireAssignTemplate(String condition, String assigner, String assignee) {
	  templateStr = "";
	  if(condition!=null) {
		  return templateStr.concat("\nassign "+assignee+" = ("+condition+")?"+assigner+":"+assignee+";");
	  }
	  else {
		  return templateStr.concat("\nassign "+assignee+" = "+assigner+";");
	  }
  }
  
  public static String registerAssignTemplate(int word, String condition, String assigner, String assignee) {
	  templateStr = "";
	  if(condition!=null) {
		  return templateStr.concat("\n"+word+":"+assignee+" <= ("+condition+")?"+assigner+":"+assignee+";");
	  }
	  else {
		  return templateStr.concat("\n"+word+":"+assignee+" <= "+assigner+";");
	  }
  }
  
  public static String insertTemplate(String instanceName, int newBytes,int insertData,int position, int insertWord) {
	  templateStr = "";
	  return templateStr.concat("insert "+instanceName+"\n")
	  			 .concat(".NEWBYTES(newBytes),\n")
	  			 .concat(".INSERTDATA(insertData),\n")
	  			 .concat(".POSITION(position),\n")
	  			 .concat(".INSERTWORD(insertWord),\n")
	  			 .concat("(.clk	(clk),\n")
	  			 .concat(".reset(reset),\n");
  }
  
  public static String removeTemplate(String instanceName, int bits, int pos, int word) {
	  templateStr = "";
	  return templateStr.concat("remove "+instanceName+"\n")
	  			 .concat(".DELETE_START_POS(pos),\n")
	  			 .concat(".DELETE_WORD(word),\n")
	  			 .concat(".DELETE_BITS(bits),\n") 
	  			 .concat("(.clk	(clk),\n")
	  			 .concat(".reset(reset),\n");
  }
  
  public static String shiftTemplate(DeclInput input, ArrayList<DeclOutput> outputs, int clockCycles) {
	  templateStr = "";
	  String inputPortName = input.bind.id.string;
	  templateStr = templateStr.concat("shift_ram_v9_"+clockCycles+" shift(\n")
	  						   .concat(".d({shift_input_data,shift_input_ctrl,shift_input_wr}),\n")
	  						   .concat(".q({shift_data,shift_ctrl,shift_wr}),\n");
	  
	  templateStr = templateStr.concat(".clk(clk),\n");
	  if(outputs.size()==1) {
		  String portName = outputs.get(0).bind.id.string;
		  templateStr = templateStr.concat(".ce(out_rdy_"+portName+"));\n");
	  }
	  else {
		 templateStr = templateStr.concat(".ce(in_rdy_schedule));"); 
	  }
	  return templateStr;
  }
  
  public static String inputPorts(String in_data_wire, 
		  										String in_ctrl_wire,
		  										String in_wr_wire,
		  										String in_rdy_wire) {
	  templateStr = "";
	  return templateStr.concat(".in_data_in("+in_data_wire+"),\n")
		 	 .concat(".in_ctrl_in("+in_ctrl_wire+"),\n")
			 .concat(".in_wr_in("+in_wr_wire+"),\n")
			 .concat(".in_rdy_in("+in_rdy_wire+"),\n");
  }
  
  public static String outputPorts(String out_data_wire, 
								   String out_ctrl_wire,
								   String out_wr_wire,
								   String out_rdy_wire) {
	  templateStr = "";
	  return templateStr.concat(".out_data_out("+out_data_wire+"),\n")
	  					.concat(".out_ctrl_out("+out_ctrl_wire+",\n")
	  					.concat(".out_wr_out("+out_wr_wire+"),\n")
	  					.concat(".out_rdy_out("+out_rdy_wire+"));\n");
  }

  /****************HEADERS AND TRAILERS********************/
  
  /**
   * A null template
   */ 
  public static String nullTemplate() {
	  templateStr = "";
	  return templateStr;		
  }
  
  /**
   * Program headers
   * 
   */ 
  public static String programHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("program_head"));
		
  }
  
  /**
   * A program trailer
   */ 
  public static String programTrailer() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("program_tail"));
  }
  
  /**
   * An I/O header
   */ 
  public static String ioHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("io_head"));
  }
  
  /**
   * An I/O trailer
   */ 
  public static String ioTrailer() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("io_tail"));
  }
  
  /**
   * A decode header
   */ 
  public static String decodeHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("decode_head"));
  }
  
  /**
   * A decode trailer
   */ 
  public static String decodeTrailer() {
	  templateStr =  "";
	  return templateStr.concat(getTemplate("decode_tail"));
  }
  
  /**
   * A execute header
   */ 
  public static String executeHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("execute_head"));
  }
  
  /**
   * A execute trailer
   */ 
  public static String executeTrailer() {
	  templateStr =  "";
	  return templateStr.concat(getTemplate("execute_tail"));
  }
  
  /**
   * A wire header
   */ 
  public static String wireHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("wire_head"));		
  }
  
  /**
   * A register header
   */ 
  public static String registerHeader() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("reg_head"));		
  }
  
  /**
   * A register trailer
   */ 
  public static String registerTrailer() {
	  templateStr = "";
	  return templateStr.concat(getTemplate("reg_tail"));		
  }
  
  /**
   * A assign header
   */ 
  public static String assignHeader() {
	  templateStr = "\n/******Assign statements******/\n";
	  return templateStr;		
  }
  
  /**
   * A insert header
   */ 
  public static String insertHeader() {
	  templateStr = "\n/******Insert modules******/\n";
	  return templateStr;		
  }

  /**
   * A insert trailer
   */ 
  public static String insertTrailer() {
	  templateStr = "\n/******End insert modules******/\n";
	  return templateStr;		
  }

  /**
   * A insert header
   */ 
  public static String removeHeader() {
	  templateStr = "\n/******Remove modules******/\n";
	  return templateStr;		
  }

  /**
   * A insert trailer
   */ 
  public static String removeTrailer() {
	  templateStr = "\n/******End remove modules******/\n";
	  return templateStr;		
  }
  
  /**
   * This is a uesful method to extract template definitions from files
   * The templates are stored as files within /templates directory
   * The template string must match the file name  
   * 
   * @param tempateString
   * @return
   */
   public static String getTemplate(String templateString) {
  	 File file = new File("templates/reclick/"+templateString+".temp");
  	 FileInputStream fis = null;
  	 BufferedInputStream bis = null;
  	 DataInputStream dis = null;
  	 String templateStr = "";
  	 
  	 try {
  	      fis = new FileInputStream(file);

  	      // Here BufferedInputStream is added for fast reading.
  	      bis = new BufferedInputStream(fis);
  	      dis = new DataInputStream(bis);

  	      // dis.available() returns 0 if the file does not have more lines.
  	      while (dis.available() != 0) {
  	    	  templateStr = templateStr.concat(dis.readLine()+"\n");
  	      }

  	      // dispose all the resources after using them.
  	      fis.close();
  	      bis.close();
  	      dis.close();
  	      return templateStr;

  	    } catch (FileNotFoundException e) {
  	      e.printStackTrace();
  	    } catch (IOException e) {
  	      e.printStackTrace();
  	    }
  	    return "";
   }

}



// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

