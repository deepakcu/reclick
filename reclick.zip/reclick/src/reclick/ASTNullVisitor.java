package reclick;
/**
 * This abstract class gives default (no work) implementations for AST visitor
 * classes. It is convenient for subclassing since you need to give
 * implementations only for those methods that do actual work.
 *
 * Note that visit methods for subclass objects (e.g., for DeclConst, a
 * subclass of Decl) defaultly call their parent class visit method, allowing
 * handling of common functionality. However, if you override visitDeclConst,
 * you will need to call visitDecl in the overriding method, if you want it
 * called.
 *
 * Note also that we coded all our accept methods in subclasses so that,
 * before their work, they call super.acceptBefore, and after teir work they
 * call super.acceptAfter. The acceptBefore/After methods for calss XXX call
 * visitXXXBefore/After, allowing work to be done for all nodes belonging to a
 * given part of the AST hierarchy, before or after their normal visit.
 *
 * @version 1.0
 */
public abstract class ASTNullVisitor implements ASTVisitor {

  // methods for work related to every node
  public void visitEveryBefore (ASTNode n) {}
  public void visitEveryAfter  (ASTNode n) {}
  
  // methods for work related to classes not subclassed
  public void visitBinding (Binding b) {}

  public void visitBlock (Block b) {}

  //public void visitCaseElement (CaseElement c) {}

  //public void visitCaseLabelList (CaseLabelList l) {}

  public void visitDecls (Decls dd) {}

  public void visitExprs (Exprs ee) {}

  public void visitComponent (Component c) {}

  public void visitStmts (Stmts ss) {}


  // methods related to Decl classes
  public void visitDeclBefore (Decl d) {}  // these are for all kinds
  public void visitDecl       (Decl d) {}  // this allow factoring of common stuff
  public void visitDeclAfter  (Decl d) {}
  public void visitDeclConst (DeclConst d) { visitDecl(d); }
  public void visitDeclField (DeclField d) { visitDecl(d); }
  public void visitDeclPosition (DeclPosition d) { visitDecl(d); }
  //public void visitDeclFormal (DeclFormal d) { visitDecl(d); }
  //public void visitDeclProcFunc (DeclProcFunc d) { visitDecl(d); }
  public void visitDeclComponent (DeclComponent d) { visitDecl(d); }
  //public void visitDeclSpecial (DeclSpecial d) { visitDecl(d); }
  public void visitDeclType (DeclType d) { visitDecl(d); }
  public void visitDeclVar (DeclVar d) { visitDecl(d); }
  public void visitDeclPacket (DeclPacket d) { visitDecl(d); }
  public void visitDeclInput(DeclInput d) { visitDecl(d); }
  public void visitDeclOutput(DeclOutput d) { visitDecl(d); }

  
  // methods for Expr classes
  public void visitExprBefore (Expr e) {}  // these are for all kinds
  public void visitExpr       (Expr e) {}  // this allows factoring of common stuff
  public void visitExprAfter  (Expr e) {}
  public void visitExprBinary (ExprBinary e) { visitExpr(e); }
  public void visitExprBinding (ExprBinding e) { visitExpr(e); }
  //public void visitExprCall (ExprCall e) { visitExpr(e); }
  public void visitExprError (ExprError e) { visitExpr(e); }
  public void visitExprId (ExprId e) { visitExpr(e); }
  public void visitExprInt (ExprInt e) { visitExpr(e); }
  //public void visitExprNil (ExprNil e) { visitExpr(e); }
  public void visitExprString (ExprString e) { visitExpr(e); }
  public void visitExprUnary (ExprUnary e) { visitExpr(e); }

  // methods for Stmt classes
  public void visitStmtBefore (Stmt s) {}  // these are for all kinds
  public void visitStmt       (Stmt s) {}  // this allows factoring of common stuff
  public void visitStmtAfter  (Stmt s) {}
  public void visitStmtAssign (StmtAssign s) { visitStmt(s); }
  //public void visitStmtCall (StmtCall s) { visitStmt(s); }
  //public void visitStmtCase (StmtCase s) { visitStmt(s); }
  public void visitStmtCompound (StmtCompound s) { visitStmt(s); }
  public void visitStmtEmpty (StmtEmpty s) { visitStmt(s); }
  public void visitStmtFor (StmtFor s) { visitStmt(s); }
  public void visitStmtIf (StmtIf s) { visitStmt(s); }
  //public void visitStmtRepeat (StmtRepeat s) { visitStmt(s); }
  //public void visitStmtWhile (StmtWhile s) { visitStmt(s); }
  public void visitStmtConcat(StmtConcat s) { visitStmt(s); }
  public void visitStmtLookup(StmtLookup s) { visitStmt(s); }
  

  // methods for Type classes
  public void visitTypeBefore (Type t) {}  // these are for all kinds
  public void visitType       (Type t) {}  // this allows factoring of common stuff
  public void visitTypeAfter  (Type t) {}
  //public void visitTypeArray (TypeArray t) { visitType(t); }
  public void visitTypeError (TypeError t) { visitType(t); }
  public void visitTypeId (TypeId t) { visitType(t); }
  //public void visitTypePointer (TypePointer t) { visitType(t); }
  public void visitTypePrimBefore (TypePrim t) {}  // for all Prim types
  public void visitTypePrim       (TypePrim t) { visitType(t); }  // this allows factoring of common stuff
  public void visitTypePrimAfter  (TypePrim t) {}
  public void visitTypePrimBool (TypePrimBool t) { visitTypePrim(t); }
  public void visitTypePrimInt (TypePrimInt t) { visitTypePrim(t); }
  //public void visitTypePrimNil (TypePrimNil t) { visitTypePrim(t); }
  public void visitTypePrimString (TypePrimString t) { visitTypePrim(t); }
  public void visitTypePrimPacket (TypePrimPacket p) { visitTypePrim(p); }
  public void visitTypePrimField (TypePrimField f) { visitTypePrim(f); }
  public void visitTypePrimOutput(TypePrimOutput t) { visitTypePrim(t); }
  public void visitTypePrimInput(TypePrimInput t) { visitTypePrim(t); }
  public void visitTypePrimPosition(TypePrimPosition p) { visitTypePrim(p); }
  
  //public void visitTypeRecord (TypeRecord t) { visitType(t); }
  //public void visitTypeRange (TypeRange t) { visitType(t); }
  public void visitExprPacket(Packet p) { visitPacket(p); }
  
  

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
