package reclick;
/**
 * Abstract Representation of a type in the <i>Pascal</i> language as defined
 * by the <i>Pascal User Manual and Report</i>.
 *
 * @version 1.0
 */
public abstract class Type extends ASTNode {

  /**
   * special error Type
   */
  public static final TypeError theErrorType = TypeError.theErrorType;

  /**
   * built-in primitive Pascal integer type
   */
  public static final TypePrim theIntType = TypePrimInt.theIntType;

  /**
   * built-in primitive Pascal string type (for sring constants)
   */
  public static final TypePrim theStringType = TypePrimString.theStringType;

  /**
   * built-in primitive Mini-Pascal boolean type
   */
  public static final TypePrim theBoolType = TypePrimBool.theBoolType;

  /**
   * built-in primitive type for Pascal NIL (matches all pointer types)
   */
  //public static final TypePrim theNilType = TypePrimNil.theNilType;

  /**
   * built-in primitive Mini-Pascal packet type
   */
  public static final TypePrim thePacketType = TypePrimPacket.thePacketType;

  /**
   * built-in primitive Mini-Pascal field type
   */
  public static final TypePrim theFieldType = TypePrimField.theFieldType;

  /**
   * built-in primitive Mini-Pascal field type
   */
  public static final TypePrim thePositionType = TypePrimField.thePositionType;

  
  /**
   * built-in primitive Mini-Pascal field type
   */
  public static final TypePrim theInputType = TypePrimInput.theInputType;

  /**
   * built-in primitive Mini-Pascal field type
   */
  public static final TypePrim theOutputType = TypePrimOutput.theOutputType;

  
  /**
   * indicates whether this Type has been checked.
   * false = not checked, true = checked
   */
  public boolean checked = false;

  /**
   * the size (at run time) of variables this Type, in bytes
   */
  public int size = 0;

  /**
   * Creates a new Type instance.
   *
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  protected Type (int left, int right) {
    super(left, right);
  }

  /**
   * Handles AST visiting work to occur before visiting each Type node
   *
   * @param v an ASTVisitor
   */
  public void acceptBefore (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitTypeBefore(this);
  }

  /**
   * Handles AST visiting work to occur after visiting each Type node
   *
   * @param v an ASTVisitor
   */
  public void acceptAfter (ASTVisitor v) {
    v.visitTypeAfter(this);
    super.acceptAfter(v);
  }

  /**********************************/
  /**** Type Examination Methods ****/
  /**********************************/

  /**
   * Indicates whether the Type is the one for the Mini-Pascal boolean type.
   *
   * @return whether this is theBoolType
   */
  public boolean isBoolType () {
    return false;  // override in TypePrimBool
  }

  /**
   * Indicates whether the Type is the error type, which represents parsing
   * and checking errors.
   *
   * @return whether this is theErrorType
   */
  public boolean isErrorType () {
    return false;  // override in TypeError
  }

  /**
   * does this Type represent a Pascal pointer type?
   *
   * @return whether this is a pointer type or theNilType
   */
  public boolean isPointerType () {
    return false;  // override in TypePointer and TypePrimNil
  }

  /**
   * we use a special Type to represent the type of Pascal NIL, which matches
   * every Pascal pointer type; this test indicates whether the Type is that
   * special type for NIL
   *
   * @return whether this is theNilType
   */
  public boolean isNilType () {
    return false;  // override in TypePrimNil
  }

  /**
   * is this the Type for the Pascal integer type?
   *
   * @return whether this is theIntType
   */
  public boolean isIntegerType () {
    return false;  // override in TypePrimInt
  }

  /**
   * is this the Type one for Pascal string constants?
   *
   * @return whether this is theStringType
   */
  public boolean isStringType () {
    return false;  // override in TypePrimString
  }

  /**
   * get the base Type for this Type, i.e., the Type for elements in a range;
   * for most Type's, the base Type is just the Type itself
   *
   * @return the base Type for this Type
   */
  public Type getBaseType () {
    return this;  // override in TypeRange
  }

  /**
   * Get the lowest value of a range-like (ordinal) type. It is important that
   * this return <i>something</i> for every type assignable with WAsn (i.e.,
   * of size 4), which includes pointer types, etc.
   *
   * @return smallest value for this Type
   */
  public int minValue () {
    // override in TypeRange, TypePrimBool, TypePrimInt
    return 0;
  }

  /**
   * get the highest value of a range-like type
   *
   * @return largest value for this Type
   */
  public int maxValue () {
    // override in TypeRange, TypePrimBool, TypePrimInt, TypePointer
    return -1;
  }

  /**
   * get the number of elements in a range-like type
   *
   * @return the number of values of this (ordinal) Type
   */
  public int getNumber () {
    // Note: will cause assertion failure on inappropriate Type's
    return maxValue() - minValue() + 1;
  }

  /**
   * is the type an integer based type?
   *
   * @return whether this Type is integer based (ordinal, but not theBoolType)
   */
  public boolean isIntBasedType () {
    return false;  // override in TypePrimInt and TypeRange
  }

  /**
   * is the type an ordinal type?
   *
   * @return whether this Type represents a Pascal ordinal type
   */
  public boolean isOrdinalType () {
    return false;  // override in TypePrimInt, TypePrimBool, and TypeRange
  }

  /**********************************/
  /**** Type Comparing Methods   ****/
  /**********************************/

  /**
   * Checks if types are compatible types
   *
   * @param t a type
   * @return true if this and t are compatible, false otherwise
   */
  public boolean isCompatibleWith (Type t) {
    assert t != null;
    return this == t;  // override in TypeRange, TypePointer, TypePrimNil, TypePrimInt, TypePrimBool
  }

  /**
   * Checks to see if type t2 can be assigned to type t1
   *
   * @param t a type
   * @return true if a t can be assigned to a this, false otherwise
   */
  public boolean isAssignableFrom (Type t) {
    /* NOTE: this is the one being assigned to, t the one being assigned; */
    /* assignment compatibility and ordinary compatibility are the same */
    /* in Pascal */    
    return this.isCompatibleWith(t);
  }

  /**
   * indicates whether the given MPCObject represents a constant value that is
   * within the legals set of values for this Type; assumes we already know
   * that the Type of the constant is assignment compatible with this Type
   *
   * @param object an MPCObject giving the constant value to test
   * @return whether object is a legal constant value for this Type
   */
  /*
  public boolean constIsInType (MPCObject object) {
    return false;  // override in TypePrim and TypeRange
  }
  */

}

// Local Variables:
// mode: jde
// indent-tabs-mode: nil
// c-basic-offset: 2
// End:

