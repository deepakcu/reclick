package reclick;
//import reclick.Tuples.Cursor;
/**
 * This interface defines things common to all Tuple visitor classes. Given
 * that it is natural for a visitor interface, we omit documentation for most
 * methods.
 *
 * @version 1.0
 */
public interface TupleVisitor {

  // methods for work related to every kind of Tuple
  public void visitEveryBefore (Tuple t);
  public void visitEveryAfter  (Tuple t);
  
  // methods for work related to each opcode
  public void visitProgStart (Tuple t);
  public void visitMainEnd   (Tuple t);
  public void visitProgEnd   (Tuple t);
  public void visitDeclPort  (Tuple t);
  public void visitSetStmt   (Tuple t);
  public void visitGetStmt   (Tuple t);

  /**
   * Intended for visiting the whole program
   */
  public void visitProg ();
  
  /**
   * Intended for visiting individual basic (or extended basic) blocks
   *
   * @param c a Cursor bounding the Tuple's of the basic (or extended)
   * block
   */
  public void visitBlock (Cursor c);
  
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
