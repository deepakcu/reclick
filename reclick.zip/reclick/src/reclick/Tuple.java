package reclick;
import static reclick.TupleCode.*;
import java.util.ArrayList;
/**
 * This class defines the tuples of Mini-Pascal's intermediate language. Most
 * fields are not final so that optimizations can mutate them. They should do
 * so what care, since this class does not (and cannot easily) check such
 * mutations the way it checks fields upon Tuple construction.
 *
 * In order to perform such checks, rather than exposing the Tuple constructor
 * we provide a static method for building each kind of Tuple, which can check
 * that its arguments are appropriate (and supply Empty fields for those not
 * used in that kind of Tuple).
 *
 * @version 1.0
 */
public class Tuple {

  /**
   * The string of the Tuple
   */
  public TupleCode code;
  
  /**
   * The string of the Tuple
   */
  public String tupString;
  
  /**
   * Get and Set statements require the word info
   * get and set statements corresponding to the same word
   * must be encapusulated within the same case block
   * tupWord will give info about this
   */
  public String tupWord;
    
  /**
   * An instance name (for insert and remove module tuples)
   */
  public String instanceName;
  
  /**
   * Any Tuple can have a String comment
   */
  public String comment = null;

  /**
   * Creates a new Tuple from values for its most important fields; note that
   * it is private, as discussed in the class documentation.
   *
   * @param Tuple code
   */
  
  private Tuple (TupleCode code) {
    this.code = code;
  }
  
  /**
   * Creates a new Tuple from values for its most important fields; note that
   * it is private, as discussed in the class documentation.
   *
   * @param Tuple code
   */
  
  private Tuple (TupleCode code, String tstring) {
	  this.code = code;
	  this.tupString = tstring;
  }
  

  /**
   * This method is convenient for building a Tuple and adding a comment to it
   *
   * @param c the String comment to add (can even be null)
   * @return the Tuple to which we are adding the comment
   */
  
  public Tuple addComment (String c) {
    comment = c;
    return this;
  }
  
  /**
   * X format tuple builder: all fields Empty, only the operator matters
   *
   * @param op the TupleOp operator of the Tuple
   * @return the new Tuple
   */
  
  private static Tuple X (TupleCode code) {
      return new Tuple(code);
  }

  /**
   * ProgStart tuples have X format
   *
   * @return the new Tuple
   */
  public static Tuple makeProgStart (String name) {
      return new Tuple(ProgStart, TupleTemplate.ProgStartTemplate(name));
  }    
  

  /**
   * ProgEnd tuples have X format
   *
   * @return the new Tuple
   */
  public static Tuple makeProgEnd () {
	    return new Tuple(ProgEnd, TupleTemplate.ProgEndTemplate());
  }
  
  /**
   * makeInput 
   *
   * @return the new Tuple
   */
  public static Tuple makeInput (String portName) {
	    return new Tuple(DeclInput, TupleTemplate.inputPortTemplate(portName));
  }  
  
  /**
   * makeOutput 
   *
   * @return the new Tuple
   */
  public static Tuple makeOutput (String portName) {
	    return new Tuple(DeclOutput, TupleTemplate.outputPortTemplate(portName));
  }
  
  /**
   * makeSet 
   *
   * @return the new Tuple
   */
  public static Tuple makeSet (ArrayList<TupletSet> caseTuplets) {
	    return new Tuple(SetStmt, TupleTemplate.setTemplate(caseTuplets));
  } 
  
  
  public static Tuple makeSchedule(ArrayList<TupletSchedule> scheduleTuplets) {
	  return new Tuple(SetStmt, TupleTemplate.scheduleTemplate(scheduleTuplets));
  }
  
  public static Tuple makeOrdinaryVarAssign(ArrayList<TupletOrdinaryVar> ordinaryVarTuplets) {
	  return new Tuple(SetStmt, TupleTemplate.ordinaryVarTemplate(ordinaryVarTuplets));
  }
  
  
  /**
   * makeGet 
   *
   * @return the new Tuple
   */
  public static Tuple makeGet (int word, String fName, int high, int low) {
	    return new Tuple(GetStmt, TupleTemplate.getTemplate(word, fName, high, low));
  } 
  
  /**
   * makeGet 
   *
   * @return the new Tuple
   */
  public static Tuple makeGet (String word, ArrayList<String> getVariables) {
	    return new Tuple(GetStmt, TupleTemplate.getTemplate(word, getVariables));
  } 
  
  
  /**
   * makeWire 
   *
   * @return the new Tuple
   */
  public static Tuple makeWire (String fName, String high, String low) {
	    return new Tuple(GetStmt, TupleTemplate.wireTemplate(fName, high, low));
  } 
  
  /**
   * makeReg 
   *
   * @return the new Tuple
   */
  public static Tuple makeRegister (String fName, String high, String low) {
	    return new Tuple(GetStmt, TupleTemplate.regTemplate(fName, high, low));
  } 
  
  
  /**
  * makeWireAssign - Assigns a statement/expression to a wire
  * @param condition - Conditions (if any) for assigning to this wire
  * @param assigner  - Expression/Statement that is assigned
  * @param assignee  - Target wire of assignment
  * @return
  */
  public static Tuple makeWireAssign (String condition, String assigner, String assignee) {
	    return new Tuple(GetStmt, TupleTemplate.wireAssignTemplate(condition, assigner, assignee));
  }
  
  /**
  * makeRegisterAssign - Assigns a statement/expression to a register.
  * The assignment will be made in the execute logic.
  * @param word      - The word in the packet for which this assignment will be made
  * @param condition - Conditions (if any) for assigning to this register
  * @param assigner  - Expression/Statement that is assigned
  * @param assignee  - Target wire of assignment
  * @return
  */
  public static Tuple makeRegisterAssign (int word, String condition, String assigner, String assignee) {
	    return new Tuple(GetStmt, TupleTemplate.registerAssignTemplate(word, condition, assigner, assignee));
  }
  
  /**
   * makeInsert
   *
   * @return the new Tuple
   */
  public static Tuple makeInsert (String insertInstanceId, int newBytes,int insertData,int position, int insertWord) {
	  return new Tuple(GetStmt, TupleTemplate.insertTemplate(insertInstanceId, newBytes, insertData, position, insertWord));
  }
  
  /**
   * makeInsert
   *
   * @return the new Tuple
   */
  public static Tuple makeRemove (String removeInstanceId, int pos, int word, int bits) {
	    return new Tuple(GetStmt, TupleTemplate.removeTemplate(removeInstanceId, pos, word, bits));
  }
  
  public static Tuple makeShift(DeclInput input, ArrayList<DeclOutput> outputs, int clockCycles) {
	  return new Tuple(GetStmt, TupleTemplate.shiftTemplate(input,outputs, clockCycles));
  }
  
  /**
   * Support TupleVisitor functionality, as if each TupleOp defined a separate
   * subclass of Tuple, which is not actually the case. Hence it simply does a
   * switch on TupleOp and calls the appropriate visit method. (This COULD be
   * done with instance-specific methods in TupleOp, but would be verbose and
   * painful to write.)
   *
   * @param v a TupleVisitor visiting this Tuple
   */
  public void accept (TupleVisitor v) {
    v.visitEveryBefore(this);
    switch (code) {
    	case ProgStart: v.visitProgStart(this); break;
    	case ProgEnd  :	v.visitProgEnd(this); 	break;
    	case DeclInput: v.visitDeclPort(this);  break;
    	case DeclOutput:v.visitDeclPort(this);  break;
    	case SetStmt  : v.visitSetStmt(this);   break;
    	case GetStmt  : v.visitGetStmt(this);   break;
    	default       : assert false; 			break;
    }
    v.visitEveryAfter(this);
  }
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

