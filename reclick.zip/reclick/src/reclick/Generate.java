package reclick;
import java.util.*;
import static reclick.reclickContext.Flag.*;
//import reclick.Tuples.Cursor;

/**
 * This class drives code (Tuple) generation
 *
 * @version 1.0
 */
public class Generate extends Phase<Integer,Object> {

  /**
   * The obvious constructor
   *
   * @param context the compilation context
   */
  public Generate (reclickContext context) {
    super(context);
  }

  /**
   * perform runs the phase
   *
   * @return number of Tuple generation errors
   */
  public Integer perform () {
    if (context.flag(Verbose))
      context.verbStream.println("Generating tuples ...");
    setStream(context.flag(TuplePrint), context.baseName, "tuple", "tuple", true);
    
    Tuples programHeadTuples = new Tuples(TupleTemplate.programHeader() ,TupleTemplate.nullTemplate());	
    Tuples ioPortTuples 	 = new Tuples(TupleTemplate.ioHeader()	    ,TupleTemplate.ioTrailer());
    Tuples wireTuples 		 = new Tuples(TupleTemplate.wireHeader()    ,TupleTemplate.nullTemplate());
    Tuples registerTuples 	 = new Tuples(TupleTemplate.registerHeader(),TupleTemplate.registerTrailer());
    Tuples decodeTuples 	 = new Tuples(TupleTemplate.decodeHeader()  ,TupleTemplate.decodeTrailer());
    Tuples executeTuples 	 = new Tuples(TupleTemplate.executeHeader() ,TupleTemplate.executeTrailer());
    Tuples insertTuples      = new Tuples(TupleTemplate.insertHeader()  ,TupleTemplate.insertTrailer());
    Tuples removeTuples      = new Tuples(TupleTemplate.removeHeader()  ,TupleTemplate.removeTrailer());
    Tuples shiftTuples		 = new Tuples(TupleTemplate.nullTemplate()  ,TupleTemplate.nullTemplate());
    Tuples assignTuples		 = new Tuples(TupleTemplate.assignHeader()  ,TupleTemplate.nullTemplate());
    Tuples programTailTuples = new Tuples(TupleTemplate.nullTemplate()  ,TupleTemplate.programTrailer());
    
    
    ArrayList<Tuples> programTuples  = new ArrayList<Tuples>();
    ArrayList<Cursor> programCursors = new ArrayList<Cursor>();
     
    
    TupleGenVisitor tupVis = new TupleGenVisitor(programHeadTuples, 
    											 ioPortTuples, 
    											 decodeTuples, 
    											 executeTuples, 
    											 programTailTuples, 
    											 registerTuples, 
    											 wireTuples,
    											 assignTuples,
    											 insertTuples,
    											 removeTuples,
    											 shiftTuples); 
    	
    context.component.accept(tupVis);
    if (tupVis.numErrors > 0)
      context.errStream.printf("Number of tuple generation errors: %d%n", tupVis.numErrors);
    
    //Process the insert and remove tuples and generate interconnection wires
    tupVis.postProcessTuples(insertTuples, removeTuples, wireTuples);
    
    //Cursor c = ;
    
    
    if (ps != null) {
      //Tuples.accept(new TuplePrintVisitor(ps));
      programHeadTuples.accept(new TuplePrintVisitor(ps));
      decodeTuples.accept(new TuplePrintVisitor(ps));
      executeTuples.accept(new TuplePrintVisitor(ps));
      programTailTuples.accept(new TuplePrintVisitor(ps));
      registerTuples.accept(new TuplePrintVisitor(ps));
      wireTuples.accept(new TuplePrintVisitor(ps));
      assignTuples.accept(new TuplePrintVisitor(ps));
      ps.close();
    }
    
    /*Add in the order we want the tuples to be printed in the Verilog output*/
    programTuples.add(programHeadTuples); programCursors.add(new Cursor(programHeadTuples));
    programTuples.add(ioPortTuples);	  programCursors.add(new Cursor(ioPortTuples));
    programTuples.add(wireTuples);		  programCursors.add(new Cursor(wireTuples));
    programTuples.add(registerTuples);	  programCursors.add(new Cursor(registerTuples));
    programTuples.add(decodeTuples);	  programCursors.add(new Cursor(decodeTuples));
    programTuples.add(executeTuples);	  programCursors.add(new Cursor(executeTuples));
    programTuples.add(insertTuples);	  programCursors.add(new Cursor(insertTuples));
    programTuples.add(removeTuples);	  programCursors.add(new Cursor(removeTuples));
    programTuples.add(shiftTuples);		  programCursors.add(new Cursor(shiftTuples));
    programTuples.add(assignTuples); 	  programCursors.add(new Cursor(assignTuples));
    programTuples.add(programTailTuples); programCursors.add(new Cursor(programTailTuples));
    
    Cursor programHeadTuplesCursor = new Cursor(programHeadTuples);
    //reclick.printTuples(programTuples,programCursors, context.flag(BBPrint), context.flag(XBBPrint),context.baseName, "");
    reclick.printTuples(programTuples,programCursors, context.flag(BBPrint), context.flag(XBBPrint),context.rtlDirectory, "");
    return tupVis.numErrors;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

