package reclick;
  /**
   * ObjectValueError is the class of the (unique) error MPCObject
   *
   * @author Eliot Moss
   * @version 1.0
   */
public class ObjectValueError extends reclickObject {

  /**
   * the unique error MPCObject
   */
  public static final ObjectValueError theErrorObject = new ObjectValueError();

  /**
   * Creates a new ObjectValueError instance; private since we
   * create a unique one on class initialization
   */
  /*
  private ObjectValueError () {
    // written to insure there is only one instance
    type = Type.theErrorType;
  }
  */

  /**
   * Handles MPCObject visiting for ObjectValueError nodes
   *
   * @param v an ObjectVisitor
   */
  public void accept (ObjectVisitor v) {
    super.acceptBefore(v);
    v.visitObjectValueError(this);
    super.acceptAfter(v);
  }

  /**
   * equals in this case means "the same Java object", because there is a
   * single instance
   *
   * @param o an Object value
   * @return a boolean value
   */
  public boolean equals (Object o) {
    return this == o;
  }

  /**
   * We need an implementation of tupleField here to satisfy the compiler, but
   * it should never be called and will cause an assertion failure
   *
   * @return a TupleField (in fact, always gives an assertion
   * failure)
   */
  /*
  public TupleField tupleField () {
    assert false;
    return (TupleField)null;
  }
  */

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

