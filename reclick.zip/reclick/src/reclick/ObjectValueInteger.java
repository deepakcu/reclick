package reclick;
/**
 * An ObjectValueInteger describes a run-time value that is an integer
 * constant
 *
 * @author Eliot Moss
 * @version 1.0
 */
public class ObjectValueInteger extends reclickObject {

  /**
   * unique TokenInt giving the value of the integer constant
   */
  public final TokenInt value;

  /**
   * Creates a new ObjectValueInteger instance given its TokenInt
   * value
   *
   * @param v a TokenInt giving the value of the integer constant
   * value
   */
  
  public ObjectValueInteger (TokenInt v) {
    this(v, Type.theIntType);
  }
  

  /**
   * Creates a new ObjectValueInteger instance with the given
   * mathematical integer constant value and the given Mini-Pascal Type
   *
   * @param v a TokenInt giving the value
   * @param t a Type giving the Mini-Pascal type of the constant
   */
  public ObjectValueInteger (TokenInt v, Type t) {
    value = v;
    type  = t;
  }

  /**
   * Handles MPCObject visiting for ObjectValueInteger nodes
   *
   * @param v an ObjectVisitor
   */
  public void accept (ObjectVisitor v) {
    super.acceptBefore(v);
    v.visitObjectValueInteger(this);
    super.acceptAfter(v);
  }

  /**
   * getValue returns the integer value of this ObjectValueInteger.
   *
   * @return the integer value of this value object
   */
  public int getValue () {
    return value.value;
  }
  
  
  /**
  * returns the base type of the integer (dec/hex)
  * @return
  */
  public BaseType getBaseType() {
	return value.base;
  }

  /**
   * equals in this case requires being the same Java class and having the
   * same integer value, but not necessarily being the same object
   *
   * @param o the Object with which to compare
   */
  public boolean equals (Object o) {
    return (o instanceof ObjectValueInteger) &&
      value.value == ((ObjectValueInteger)o).value.value;
  }

  /**
   * Returns a TupleField.Const for this constant valued MPCObject
   *
   * @return a TupleField.Const having the value of this constant
   */
  /*
  public TupleField tupleField () {
    return new TupleField.Const(value.value);
  }
  */

  /**
   * Since this is a constant, its min value is simply its value
   *
   * @return an int giving the value of this constant
   */
  public int minValue () {
    return getValue();
  }

  /**
   * Since this is a constant, its max value is simply its value
   *
   * @return an int giving the value of this constant
   */
  public int maxValue () {
    return getValue();
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

