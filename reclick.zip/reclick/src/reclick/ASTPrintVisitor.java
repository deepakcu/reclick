package reclick;
import java.util.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for printing ASTs.
 *
 * @version 1.0
 */
public class ASTPrintVisitor extends ASTNullVisitor
  implements TokenVisitor
{

  /**
   * the stream to which to print
   */
  public final reclickStream ps;

  /**
   * the obvious constructor
   *
   * @param ps the stream to which to print
   */
  public ASTPrintVisitor (reclickStream ps) {
    this.ps = ps;
  }

  /**
   * Prints a Binding, by printing its TokenId, line number, (declaration
   * number and scope)
   *
   * @param b the Binding to print
   */
  public void visitBinding (Binding b) {
    b.id.accept(this);
    ps.printf("[%d]", InputPos.lineOf(b.pos));
    Decl decl = b.decl;
    if (decl != null) {
      ps.printf(", number: %d", decl.declNumber);
      //SymbolTable s = decl.symbolTable;
      //if (s != null) {
      //  ps.printf(", scope:  %d", s.sequenceNum);
      //}
    }
    
  }

  /**
   * Prints a Block: Decls, (offset), Stmts
   *
   * @param b the Block to print
   */
  
  public void visitBlock (Block b) {
    ps.printStart("block");
    //Deepak commented
    /*
    if (b.mySymtab != null)
      ps.printf(" [offset=%d]", b.mySymtab.getOffset());
      */
    b.decls.accept(this);
    b.stmts.accept(this);
    ps.printFinish();
  }
  

  /**
   * Prints a CaseElement, CaseLabelList, (code label), Stmt
   *
   * @param c the CaseElement to print
   */
  /*
  public void visitCaseElement (CaseElement c) {
    c.labels.accept(this);
    if (c.codeLabel != null) {
      ps.printIndent();
      ps.print("label: ");
      c.codeLabel.accept(this);
    }
    ps.printIndent();
    c.stmt.accept(this);
  }
  */

  /**
   * Prints a CaseLabelList by printing each Expr (and its allocated temp
   * object) in the list
   *
   * @param l the CaseLabelList to print
   */
  /*
  public void visitCaseLabelList (CaseLabelList l) {
    ps.printIndent();
    ps.printStart("labellist");
    Iterator<MPCObject> oo = l.temps.iterator();
    for (Expr c : l.labels) {
      ps.printIndent();
      c.accept(this);
      if (!oo.hasNext()) {
        mpc.ShowError(l.pos, "ASTPrintVisitor.visitCaseLabelList: " +
                      "code labels list does not have enough elements!");
      } else {
        MPCObject o = (MPCObject)oo.next();
        if (o != null) {
          ps.printIndent();
          ps.print("temp=");
          o.accept(this);
        }
      }
    }
    ps.printFinish();
  }
  */

  /**
   * Prints each Decl in a Decls
   *
   * @param dd the Decls to print
   */
  public void visitDecls (Decls dd) {
    ArrayList<Decl> decls = dd.decls;
    if (decls != null && decls.size() > 0) {
      ps.printIndent();
      ps.printStart("decllist");
      for (Decl d : decls) {
        if (d != null) {
          ps.printIndent();
          d.accept(this);
        }
      }
      ps.printFinish();
    }
  }

  /**
   * Prints each Expr in an Exprs
   *
   * @param ee the Exprs to print
   */
  /*
  public void visitExprs (Exprs ee) {
    ArrayList<Expr> exprs = ee.exprs;
    if (exprs != null && exprs.size() > 0) {
      ps.printIndent();
      ps.printStart("exprlist:");
      for (Expr e : exprs) {
        ps.printIndent();
        e.accept(this);
      }
      ps.printFinish();
    }
  }
  */
  
  /**
   * Prints a Program: top level Decls, (offset), Block
   *
   * @param p the Prorgram to print
   */
  public void visitComponent (Component c) {
    ps.printStart("component");
    /*
    if (c.mySymtab != null)
      ps.printf(" [offset=%d]", p.mySymtab.getOffset());
    */
    c.decls.accept(this);
    ps.printIndent();
    c.block.accept(this);
    ps.printFinish();
    ps.println();
  }

  /**
   * Prints each Stmt in a Stmts
   *
   * @param ss the Stmts to print
   */
  
  public void visitStmts (Stmts ss) {
    ArrayList<Stmt> stmts = ss.stmts;
    if (stmts != null && stmts.size() > 0) {
      ps.printIndent();
      ps.printStart("stmtlist");
      for (Stmt s : stmts) {
        ps.printIndent();
        s.accept(this);
      }
      ps.printFinish();
    }
  }
  

  // methods related to Decl classes

  /**
   * Prints an identifying tag before each Decl form
   *
   * @param d the Decl form (ignored since we output the same tag always)
   */
  public void visitDeclBefore (Decl d) {
    ps.printStart("decl->");
  }

  /**
   * Matches the printStart of visitDeclBefore
   *
   * @param d the Decl form being visited (ignored, since we are just ending
   * indentation)
   */
  public void visitDeclAfter (Decl d) {
    ps.printFinish();
  }

  /**
   * Prints a DeclConst: tag, Binding, Expr (value)
   *
   * @param d the DeclConst to print
   */
  
  public void visitDeclConst (DeclConst d) {
    ps.print("const: ");
    d.bind.accept(this);
    ps.printIndent();
    d.expr.accept(this);
  }
  

  /**
   * Prints a DeclField: tag, Binding, (offset), Type
   */
  
  public void visitDeclField (DeclField d) {
    ps.print("field: ");
    d.bind.accept(this);
    if (d.offset >= 0) {
      ps.printIndent();
      ps.printStart("field offset: " + d.offset);
      ps.printFinish();
    }
    ps.printIndent();
    d.type.accept(this);
  }
  
  
  /**
   * Prints a DeclFormal: tag, Binding, mode, Type, (allocated address)
   *
   * @param d the DeclFormal to print
   */
  /*
  public void visitDeclFormal (DeclFormal d) {
    ps.print("formal ");
    d.bind.accept(this);
    ps.printIndent();
    ps.printf("(varmode=%b)", d.isVar);
    ps.printIndent();
    d.type.accept(this);
    if (d.address != null) {
      ps.printIndent();
      d.address.accept(this);
    }
  }
  */

  /**
   * Prints a DeclProcFunc: function/procedure tag, Binding (name), (offset),
   * formals, result Type (if any), (result address, if any), (code label),
   * Block
   *
   * @param d the DeclProcFunc to print
   */
  /*
  public void visitDeclProcFunc (DeclProcFunc d) {
    ps.print(d.resultType != null ? "function: " : "procedure: ");
    d.bind.accept(this);
    if (d.mySymtab != null) {
      ps.printf(" [offset=%d]", d.mySymtab.getOffset());
    }
    ArrayList<Decl> ff = d.formals.decls;
    if (ff != null && ff.size() > 0) {
      // avoid recursion on the Decls so we can mark this as a formals list
      ps.printIndent();
      ps.printStart("formallist");
      
      for (Decl f : ff) {
        ps.printIndent();
        f.accept(this);
      }
      ps.printFinish();
    }
    if (d.resultType != null) {
      ps.printIndent();
      d.resultType.accept(this);
    }
    if (d.resultAddress != null) {
      ps.printIndent();
      d.resultAddress.accept(this);
    }
    if (d.topLabel != null) {
      ps.printIndent();
      ps.print("top label: ");
      d.topLabel.accept(this);
    }
    ps.printIndent();
    d.block.accept(this);
  }
  */

  /**
   * Prints a DeclProgram: tag, Binding (name)
   *
   * @param d the DeclProgram to print; note: this is NOT the program as a
   * whole: that is of class Program, not DeclProgram
   */
  public void visitDeclComponent (DeclComponent d) {
    ps.print("component: ");
    d.bind.accept(this);
  }

  /**
   * Prints a DeclSpecial: tag, Binding (name)
   *
   * @param d the DeclSpecial to print
   */
  /*
  public void visitDeclSpecial (DeclSpecial d) {
    ps.print("special: ");
    d.bind.accept(this);
  }
  */

  /**
   * Prints a DeclType: tag, Binding (name), Type
   *
   * @param d the DeclType to print
   */
  
  public void visitDeclType (DeclType d) {
    ps.print("type: ");
    d.bind.accept(this);
    ps.printIndent();
    d.type.accept(this);
  }
  

  /**
   * Prints a DeclVar: tag, Binding (name), Type, (allocated address)
   *
   * @param d the DeclVar to print
   */
  
  public void visitDeclVar (DeclVar d) {
    ps.print("variable: ");
    d.bind.accept(this);
    ps.printIndent();
    d.type.accept(this);
    if (d.address != null) {
      ps.printIndent();
      //d.address.accept(this); //deepak comment
    }
  }
  

  // methods for Expr classes

  /**
   * Prints a tag for all Expr nodes, and fields common to all Expr's:
   * (allocated object, rhs/lhs (rvalue/lvalue), (estimated registers needed
   * to evaluate)
   *
   * @param e the Expr being visited
   */
  
  public void visitExprBefore (Expr e) {
    ps.printStart("expr->");
    /*//Deepak commented
    if (e.object != null)
      e.object.accept(this);
      */
    ps.print("[");
    ps.print(e.rvalue ? "rhs" : "lhs");
    if (e.regCount > 0) {
      ps.printf("/regcnt=%d", e.regCount);
    }
    ps.print("]");
    ps.print(" ");
  }
  

  /**
   * Concludes printing an Expr: prints Type (if any) and unindents
   *
   * @param e the Expr being visited
   */
  
  public void visitExprAfter (Expr e) {
    if (e.type != null) {
      ps.printIndent();
      ps.print("type->");
      e.type.accept(this);
    }
    ps.printFinish();
  }
  

  /**
   * Prints an ExprBinary: tag, operator, (evaluation order), left Expr, right
   * Expr
   *
   * @param e the ExprBinary being visited
   */
  
  public void visitExprBinary (ExprBinary e) {
    ps.print("binexp: ");
    e.op.accept(this);
    ps.print(e.evalExpr1First ? " [expr1 first]" : " [expr2 first]");
    ps.printIndent();
    e.expr1.accept(this);
    ps.printIndent();
    e.expr2.accept(this);
  }
  
  
  /**
   * Prints an ExprBinding: tag, (whether it is an argument-less function
   * call), Binding (name)
   *
   * @param e the ExprBinding being visited
   */
  
  public void visitExprBinding (ExprBinding e) {
    ps.print("binding: ");
    if (e.isCall) ps.print("(call) ");
    e.bind.accept(this);
  }
  

  /**
   * Prints an ExprCall: tag, Binding (name), actuals argument Exprs
   *
   * @param e the ExprCall being visited
   */
  /*
  public void visitExprCall (ExprCall e) {
    ps.print("call: ");
    e.bind.accept(this);
    e.actuals.accept(this);
  }
  */

  /**
   * Print an ExprError: tag
   *
   * @param e the ExprError being visited
   */
  /*
  public void visitExprError (ExprError e) {
    ps.print("error:");
  }
  */

  /**
   * Prints an ExprId: tag, TokenId
   *
   * @param e the ExprId being visited
   */
  
  public void visitExprId (ExprId e) {
    ps.print("id: ");
    e.id.accept(this);
  }
  

  /**
   * Prints an ExprInt: tag, integer literal value (decimal)
   *
   * @param e the ExprInt being visited
   */
  
  public void visitExprInt (ExprInt e) {
    ps.printf("int: %d", e.value);
  }
  

  /**
   * Prints an ExprNil: tag
   *
   * @param e the ExprNil being visited
   */
  /*
  public void visitExprNil (ExprNil e) {
    ps.print("nil:");
  }
  */
  

  /**
   * Prints an ExprString: tag, string literal
   *
   * @param e the ExprString being visited
   */
  
  public void visitExprString (ExprString e) {
    ps.printf("string: '%s'", e.value);
  }
  

  /**
   * Prints an ExprUnary: tag, operator, Expr (subexpression)
   *
   * @param e the ExprUnary being visited
   */
  
  public void visitExprUnary (ExprUnary e) {
    ps.print("unexp: ");
    e.op.accept(this);
    ps.printIndent();
    e.expr.accept(this);
  }
  


  // methods for Stmt classes

  /**
   * Prints a tag before each Stmt
   *
   * @param s the Stmt being visited (ignored since we are outputting a fixed
   * tag for all here)
   */  
  public void visitStmtBefore (Stmt s) {
    ps.printStart("stmt->");
  }

  /**
   * Concludes printing a Stmt (unindents)
   *
   * @param s the Stmt being visited (ignored since all we do is unindent)
   */
  public void visitStmtAfter (Stmt s) {
    ps.printFinish();
  }

  /**
   * Prints a StmtAssign: tag, variable Expr, value Expr
   *
   * @param s the StmtAssign to print
   */
  
  public void visitStmtAssign (StmtAssign s) {
    ps.print("assignstmt:");
    ps.printIndent();
    //s.var.accept(this);
    //ps.printIndent();
    //s.expr.accept(this);
  }
  
  /**
   * Prints a StmtAssign: tag, variable Expr, value Expr
   *
   * @param s the StmtAssign to print
   */
  
  public void visitStmtEquals (StmtEquals s) {
    ps.print("assignstmt:");
    ps.printIndent();
    s.var.accept(this);
    ps.printIndent();
    s.expr.accept(this);
  }

  /**
   * Prints a StmtCall: tag, ExprCall
   *
   * @param s the StmtCall to print
   */
  /*
  public void visitStmtCall (StmtCall s) {
    ps.print("callstmt:");
    ps.printIndent();
    s.call.accept(this);
  }
  */

  /**
   * Prints a StmtCase: tag, case Expr, list of CaseElement's
   *
   * @param s the StmtCase to print
   */
  /*
  public void visitStmtCase (StmtCase s) {
    ps.print("casestmt:");
    ps.printIndent();
    s.expr.accept(this);
    ps.printIndent();
    ps.printStart("caselist");
    for (CaseElement ce : s.list) {
      ce.accept(this);
    }
    ps.printFinish();
  }
  */

  /**
   * Prints a StmtCompound: tag, the contained Stmts
   *
   * @param s the StmtCompound to print
   */
  
  public void visitStmtCompound (StmtCompound s) {
    ps.print("compoundstmt:");
    s.stmts.accept(this);
  }
  

  /**
   * Prints a StmtEmpty: just a tag
   *
   * @param s the StmtEmpty to print
   */
  
  public void visitStmtEmpty (StmtEmpty s) {
    ps.print("emptystmt:");
  }
  

  /**
   * Prints a StmtFor: tag, Binding (variable name), init Expr, to Expr, (to
   * (limit) allocated temporary object), (two extra temporary objects used in
   * the generated code), direction (up/down), body Stmt
   *
   * @param s the StmtFor to print
   */
  
  public void visitStmtFor (StmtFor s) {
    ps.print("forstmt:");
    s.name.accept(this);
    ps.printIndent();
    s.init.accept(this);
    ps.printIndent();
    s.condition.accept(this);
    if (s.limitObj != null) {
      ps.printIndent();
      ps.print("limitObj=");
      //s.limitObj.accept(this); //Deepak comment
    }
    if (s.tempObj1 != null) {
      ps.printIndent();
      ps.print("tempObj1=");
      //s.tempObj1.accept(this); //Deepak comment
    }
    if (s.tempObj2 != null) {
      ps.printIndent();
      ps.print("tempObj2=");
      //s.tempObj2.accept(this); //Deepak comment
    }
    ps.printIndent();
    //ps.printf("(upward:%b)", s.upward);
    ps.printIndent();
    s.stmt.accept(this);
  }
  

  /**
   * Prints a StmtIf: tag, if Expr, then Stmt, else Stmt (if any)
   *
   * @param s the StmtIf to print
   */
  
  public void visitStmtIf (StmtIf s) {
    ps.print("ifstmt:");
    ps.printIndent();
    s.expr.accept(this);
    ps.printIndent();
    s.stmtThen.accept(this);
    if (s.stmtElse != null) {
      ps.printIndent();
      ps.printStart("else");
      ps.printIndent();
      s.stmtElse.accept(this);
      ps.printFinish();
    }
  }
  

  /**
   * Prints a StmtRepeat: tag, body Stmt, until Expr
   *
   * @param s the StmtRepeat to print
   */
  /*
  public void visitStmtRepeat (StmtRepeat s) {
    ps.print("repeatstmt:");
    ps.printIndent();
    s.expr.accept(this);
    s.stmts.accept(this);
  }
  */

  /**
   * Prints a StmtWhile: tag, while Expr, do Stmt
   *
   * @param s the StmtWhile to print
   */
  /*
  public void visitStmtWhile (StmtWhile s) {
    ps.print("whilestmt:");
    ps.printIndent();
    s.expr.accept(this);
    ps.printIndent();
    s.stmt.accept(this);
  }
  */


  // methods for Type classes

  /**
   * Prints a tag for all Type nodes and some things in common to all nodes:
   * tag, (size), kind
   *
   * @param t the Type being visited (largely ignored, though size is
   * relevant)
   */
  
  public void visitTypeBefore (Type t) {
    ps.printStart("type->");
    ps.printf("size=%d, ", t.size);
    ps.print("kind=");
  }
  

  /**
   * Does work necessary after printing each Type, namely unindent
   *
   * @param t the Type being visited (ignored since all we are doing is
   * unindent)
   */
  
  public void visitTypeAfter (Type t) {
    ps.printFinish();
  }
  

  /**
   * Prints a TypeArray: tag, index Type, element Type
   *
   * @param t the TypeArray to print
   */
  /*
  public void visitTypeArray (TypeArray t) {
    ps.print("array:");
    t.indexType.accept(this);
    ps.printIndent();
    t.elementType.accept(this);
  }
  */

  /**
   * Prints a TypeError: tag only
   *
   * @param t the TypeError to print (ignored; we print just a tag)
   */
  
  public void visitTypeError (TypeError t) {
    ps.print("ERROR");
  }
  

  /**
   * Print a TypeId: tag, Binding (name)
   *
   * @param t the TypeId to print
   */
  
  public void visitTypeId (TypeId t) {
    ps.print("ident: ");
    t.bind.accept(this);
  }
  

  /**
   * Prints a TypePointer: tag, element (pointed at) Type
   *
   * @param t the TypePointer to print
   */
  /*
  public void visitTypePointer (TypePointer t) {
    ps.print("pointer:");
    ps.printIndent();
    if (t.bind != null) t.bind.accept(this);
  }
  */

  /**
   * Does work for each primitive type: the name of the type
   * Note: there are no type-specific methods, since the tag is all we print
   *
   * @param t the TypePrim to print
   */
  
  public void visitTypePrimBefore (TypePrim t) {
    ps.print(t.name);
  }
  

  /**
   * Prints a TypeRecord: tag, each DeclField
   *
   * @param t the TypeRecord to print
   */
  /*
  public void visitTypeRecord (TypeRecord t) {
    ps.print("record:");
    ps.printIndent();

    if (t.numFields() > 0) {
      ps.printStart("field list");
      for (DeclField df : t.fields) {
        ps.printIndent();
        df.accept(this);
      }
      ps.printFinish();
    }
  }
  */

  /**
   * Prints a TypeRange: tag, low value Expr, high value Expr
   *
   * @param t the TypeRange to print
   */
  /*
  public void visitTypeRange (TypeRange t) {
    ps.print("subrange:");
    ps.printIndent();
    t.lo.accept(this);
    ps.printIndent();
    t.hi.accept(this);
  }
  */

  public void visitPacket(Packet p) {
	  ps.print("Packet: ");
	  
  }
  
  public void visitStmtSet(StmtSet set) {
	  ps.print("Set statement: ");
	  
  }
  
  public void visitStmtGet(StmtGet set) {
	  ps.print("Get statement: ");
	  
  }
 
  public void visitStmtRemove(StmtRemove rem) {
	  ps.print("remove statement: ");
	  
  }
  
  public void visitStmtInsert(StmtInsert insafter) {
	  ps.print("insert after: ");
	  
  }  
  
  public void visitStmtLookup(StmtLookup s) {
	  ps.print("Lookup statement: ");
	  
  } 
  
  public void visitStmtConcat(StmtConcat s) {
	  ps.print("Concat statement: ");
	  
  }

  // ObjectVisitor method implementations
  // methods for work related to every kind of MPCObject

  /**
   * Does no work, but must be here ot implement the interface
   *
   * @param n the MPCObject being visited
   */
  
  public void visitEveryBefore (reclickObject n) {}
  
  /**
   * Does no work, but must be here ot implement the interface
   *
   * @param n the MPCObject being visited
   */
  
  public void visitEveryAfter (reclickObject n) {}
  
  // methods for work related to each subclass

  /**
   * Prints and ObjectMemory: level, offset, whether indirect, temporary
   * indicator
   *
   * @param m the ObjectMemory to print
   */
  
  public void visitObjectMemory (ObjectMemory m) {
    ps.printf("[lev=%d,off=%d", m.procedureLevel, m.offset);
    if (m.indirect) ps.print(",ind");
    if (m.temp != ObjectMemory.Temp.NOT) ps.printf(",tmp=%s", m.temp.toString());
    ps.print("]");
  }
  

  /**
   * Prints an ObjectValueError: just a tag
   *
   * @param e the ObjectValueError to print
   */
  public void visitObjectValueError (ObjectValueError e) {
    ps.print("[error]");
  }

  /**
   * Print an ObjectValueInteger: tag, integer value (decimal)
   *
   * @param i the ObjectValueInteger to print
   */
  public void visitObjectValueInteger (ObjectValueInteger i) {
    ps.printf("[value=%s]", i.value.toString());
  }

  /**
   * Prints an ObjectValueString: tag, the (literal) string value
   *
   * @param s the ObjectValueString to print
   */
  public void visitObjectValueString (ObjectValueString s) {
    ps.printf("[value=\'%s\']", s.text);
  }


  // implementations of TokenVisitor methods
  // methods for work related to every kind of Token

  /**
   * Prints a Token (Id, etc.); uses the toString() method, implemented by
   * each Token class, to get the String to print.
   *
   * @param t the Token to print
   */
  public void visitEveryBefore (Token t) { ps.print(t.toString()); }

  // The rest of these must be here to complete implementation of the interface

  public void visitToken       (Token t) {}
  public void visitEveryAfter  (Token t) {}
  
  // methods for work related to each subclass
  public void visitTokenId     (TokenId     t) {}
  public void visitTokenInt    (TokenInt    t) {}
  public void visitTokenKey    (TokenKey    t) {}
  public void visitTokenOp     (TokenOp     t) {}
  public void visitTokenString (TokenString t) {}




  // implementations of TupleFieldVisitor methods (really only need Label here)
  // methods for work related to every kind of TupleField
  /*
  public void visitEveryBefore (TupleField t) {}
  public void visitEveryAfter  (TupleField t) {}
  
  // methods for work related to each subclass
  public void visitTFConst (TupleField.Const f) {}

  public void visitTFConstAddress (TupleField.ConstAddress f) {}

  public void visitTFVar (TupleField.Var f) {}

  public void visitTFVarIndirect (TupleField.VarIndirect f) {}

  public void visitTFArg (TupleField.Arg f) {}

  public void visitTFArgAddress (TupleField.ArgAddress f) {}

  public void visitTFStr (TupleField.Str f) {}
  */
  
  /**
   * Prints a TupleField.Label: the label number (decimal)
   *
   * @param f the TupleField.Label to print
   */
  /*
  public void visitTFLabel (TupleField.Label f) { ps.print(String.valueOf(f.num)); }

  public void visitTFStrLabel (TupleField.StrLabel f) {}

  public void visitTFReg (TupleField.Reg f) {}

  public void visitTFAddress (TupleField.Address f) {}

  public void visitTFErrorCode (TupleField.ErrorCode f) {}

  public void visitTFEmpty (TupleField.Empty f) {}
  */
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
