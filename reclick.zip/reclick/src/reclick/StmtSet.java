package reclick;
/**
 * Representation of a InsertAfter statement.
 *
 * <i>
 * The InsertAfter statement is used to insert a field after a particular
 * field of the packet.
 * </i>
 *
 * Example:
 * 
 * INSERT binding:b AFTER binding:b OF Packet:p
 *
 * @version 1.0
 */
public class StmtSet extends Stmt {

  /**
  * The expression
  */
  public final Binding field;
	  
	
  /**
   * The packet that will be pushed
   */
  public final Binding packet;
  
  /**
   * The expression
   */
  public final Expr expression;
  
  /**
   * Two temporary MPCObject's used in code generation
   */
  public reclickObject tempObj1;
  public reclickObject tempObj2;

  /**
   * Creates a new StmtInsertAfter instance given the Binding (name) of
   * its control variable, the init Expr, direction of progression (up/down),
   * the final/limit Expr, the Stmt for the loop body, and the source
   * (start/end) position
   *
   * @param b     Binding (name) of the control variable
   * @param i     initialization Expr
   * @param up    direction of progression
   * @param t     final Expr
   * @param st    Stmt to execute
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public StmtSet (Binding fld,Binding pkt, Expr e, int left, int right) {
    super(left, right);
    field = fld;
    packet=pkt;
    expression = e;
  }

  /**
   * Handles AST visiting of StmtFor nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitStmtSet(this);
    super.acceptAfter(v);
  }

  /**
   * If false, suppresses code generation
   */
  public boolean ok = false;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

