package reclick;
import java.util.*;
import static reclick.reclickContext.Flag.Debug;

/**
 * A SymbolTable holds the Decls of a scope, and associated other information
 * including the SymbolTable for the next outer scope, the procedure and scope
 * level of this SymbolTable, the DeclProcFunc for the containing
 * procedure/function (if any), etc. A static field holds the current
 * SymbolTable, where insertions and lookups normally take place.
 *
 * @author Eliot Moss
 * @version 1.0
 */
public class SymbolTable /*implements StackConstants*/ {

  /**
   * The current SymbolTable, the default for entering and looking up a Decl
   * given a name (Binding, etc.).
   */
  private static SymbolTable current = null;

  /**
   * A counter used to give each SymbolTable a unique number for
   * identification purposes in output, etc.
   */
  private static int seqCounter = 0;

  /**
   * The sequence number of a particular SymbolTable, taken from seqCounter
   * upon creating the SymbolTable.
   */
  public final int sequenceNum;

  /**
   * The SymbolTable for the next outer scope from this one (if any).
   */
  public final SymbolTable outer;

  /**
   * The procedure nesting level of this scope. The outermost scope
   * (predefined names, etc.) and program scope are at level 0; top-level
   * procedures/functions at level 1, etc.
   */
  public final int procLevel;

  /**
   * The scope nesting level of this scope. The outermost scope (predefines)
   * is at level 0, and for each other scope, scopeLevel is i+1 if the
   * scopeLevel of outer is i.
   */
  public final int scopeLevel;

  /**
   * The Decls of things declared in this scope. Note that each includes a
   * Binding, which refers to a TokenId, so they include the names.
   */
  public final Decls decls;

  /**
   * The procedure/function, if any, associated with this scope.
   *
   */
  //public final DeclProcFunc procFunc;

  /**
   * This counter gives sequence numbers to the (properly formed) Decl's of
   * the scope.
   */
  private int count = 0;  // number of declarations (NOT bytes!)

  /**
   * Indicates whether the Decls have been "entered" yet (processed to give
   * sequence numbers, check for duplicates, etc.).
   */
  private boolean entered = false;  // Decls entered yet?

  /**
   * For variables/locals/temps, is the (negative) offset of the most recently
   * allocated variable; for formal/argument scopes, is the (positive) offset
   * of the next available byte in the frame.

   *   Note: linkage requires 12 bytes, 4 each for return address, dynamic
   *   chain (old frame pointer), and static chain (frame for next outer
   *   scope's variables)
   */
  //private int offset;

  /**
   * A collection of objects, each describing a variable allocated in the
   * scope.
   */
  public ArrayList<VarDesc> vars = new ArrayList<VarDesc>(2);

  /**
   * Enumeration of the variable categories
   */
  /*
  public static enum Category {
    Formal, Local, Temp;
  }
  */

  /**
   * A VarDesc described a variable allocated in the scope, giving its name
   * (optional; temporaries won't have names), kind (parameter, user-declared
   * local, temporary), offset, and size.
   */
  public class VarDesc {

    /**
     * The variable's name. May be null (e.g., for compiler-allocated
     * temporaries).
     */
    public TokenId name;

    /**
     * Indicates the kind of the temporary:
     *   Formal parameter,
     *   user-declared Local variable, or
     *   compiler-allocated Temp
     */
    //public Category kind;

    /**
     * Gives the offset of the variable in the stack frame. Should be >= 12
     * for parameters, < 0 for others.
     */
    //public int offset;

    /**
     * Gives the size of the variable in bytes.
     */
    public int size;

    /**
     * In some sense the obvious constructor, but with code to check all the
     * predicates that should hold, including that variables not overlap.
     *
     * @param name name of the variable being allocated; may be null for Temp
     * variables
     * @param kind gives the kind of variable being allocated; should be
     * Formal, Local, or Temp
     * @param offset the offset in bytes from the frame pointer; should be >=
     * 12 for Formal variables and < 0 for others
     * @param size the size of the variable in bytes; should be > 0
     */
    public VarDesc (TokenId name/*, Category kind, int offset, int size*/) {
      this.name   = name;
      //this.kind   = kind;
      //this.offset = offset;
      //this.size   = size;
      //assert kind == Category.Formal ? offset >= 12 : offset < 0;
      //assert size > 0;
      assert name != null /*|| kind == Category.Temp*/;
      // check for overlap
      /*
      for (VarDesc v : vars) {
        assert (v.offset >= offset+size) || (offset >= v.offset+v.size);
      }
      */
    }

  }

  /**
   * Provides means to allocate a VarDesc in a particular SymbolTable.
   * @see VarDesc
   *
   * @param name name of the variable being allocated
   * @param kind kind of variable being allocated
   * @param offset offset (in bytes) in the stack frame of the variable
   * @param size size (in bytes) of the variable
   * @return the constructed VarDesc
   */
  private VarDesc makeVarDesc (TokenId name, /*Category kind,*/ int offset, int size) {
    return new VarDesc(name/*, kind, offset, size*/);
  }

  /**
   * Constructor for a SymbolTable given the next outer scope's SymbolTable,
   * the Decls of the new scope, the associated procedure/function (may be
   * null), and whether this should be at a new procLevel from the next outer
   * scope.
   *
   * @param nextOuter the SymbolTable of the next outer scope
   * @param dd the Decls of the scope we are building
   * @param dpf the DeclProcFunc for the associated proc/func (null if none)
   * @param newProcLevel whether this scope's procLevel should be different
   * from the next outer scope's
   */
  public SymbolTable (SymbolTable nextOuter, Decls dd, /*DeclProcFunc dpf,*/ boolean newProcLevel) {

    outer = nextOuter;
    sequenceNum = ++seqCounter;
    if (nextOuter == null) {
      procLevel  = 0;
      scopeLevel = 0;
    } else {
      procLevel  = (newProcLevel ? nextOuter.procLevel + 1 : nextOuter.procLevel);
      scopeLevel = nextOuter.scopeLevel + 1;
    }
    count = 0;
    //offset = (newProcLevel ? FrameLinkageSize : 0);
    decls = dd;
    //procFunc = dpf;
  }



  /**
   * Enters each Decl of the scope, and then marks the scope as "entered", so
   * that these actions will happen only once. Also makes this scope the
   * current one.
   */
  public void enterScope () {
    current = this;
    if (reclick.flag(Debug))
      reclick.verbStream.printf("Entering scope %d at level %d, plevel %d%n",
                            sequenceNum, scopeLevel, procLevel);
    //reclick.verbStream.printf("decls size is "+decls.);
    for (Decl d : decls) {
      enterDecl(d);
    }
    entered = true;
  }

  /**
   * Removes each of the scope's Decl's and make its outer scope current.
   */
  public void exitScope () {
    for (Decl d : decls) {
      removeDecl(d);
    }
    if (reclick.flag(Debug))
      reclick.verbStream.printf("Exiting scope %d at level %d, plevel %d%n",
                            sequenceNum, scopeLevel, procLevel);
    current = outer;
  }

  /**
   * Does the work to enter Decl d. In the simple SymbolTable design this
   * checks the Id of the Decl (to make sure it is not a duplicate name
   * definition in the same scope, etc.), and assigns it a sequence number
   * (from count). In the faster SymbolTable design this needs to save the
   * Id's current info in d.outer (the next outer definition of the same name)
   * and set the Id's current info to Decl d. Also in the "fast" design, if
   * the SymbolTable has already been entered, and the Decl has a non-zero
   * declNumber, its Id's info needs to be set to Decl d.
   *
   * @param d the Decl to enter
   */
  public void enterDecl (Decl d) {
    if (!entered) {
      TokenId id = d.bind.id;
      if (reclick.flag(Debug))
        reclick.errStream.printf("Adding %s from line %d to symbol table%n",
                             id.toString(), InputPos.lineOf(d.pos));
      if (checkIdDecl(d)) {
        d.symbolTable = this;
        d.declNumber  = ++count;
        d.outer  = (Decl)id.info;
        id.info = d;
      }
    }
    else {
      if (d.declNumber != 0)
        d.bind.id.info = d;
    }
  }

  /**
   * Removes a Decl from current visibility. In the simple SymbolTable design
   * this does nothing; in the "fast" design it restores to Id's info to refer
   * to the next outer definition (d.outer), but only if its declNumber is
   * non-zero (meaning it is a "good" Decl).
   *
   * @param d the Decl to remove
   */
  public static void removeDecl (Decl d) {
    if (d.declNumber != 0) {
    	
      TokenId id = d.bind.id;
      if (id.info != d) {
        reclick.ShowError(d.pos, "SymbolTable.removeDecl: id does not refer to this Decl!");
        return;
      }
      id.info = d.outer;
    }
  }

  /**
   * Insures that the Id of Decl decl is not defined in the current
   * SymbolTable. Also emits a warning if the declaration would shadow a
   * formal parameter of the current proc/func.
   *
   * @param decl the Decl to check
   * @return true iff the definition is not a duplicate (i.e., it is ok)
   */
  public boolean checkIdDecl (Decl decl) {
    TokenId ident = decl.bind.id;
    Decl    d     = lookup(ident);

    if (d != null && d.symbolTable == current) {
      reclick.ShowError(decl.pos, "Identifier " + ident + " already defined in same scope");
      return false;
    }

    if (d != null) {
      assert d.symbolTable != null;
      if (d.symbolTable.procLevel == current.procLevel)
        reclick.ShowError(decl.pos, "Warning: declaration of " + ident + " shadows proc/func formal");
    }

    return true;
  }

  /**
   * Looks up the given TokenId, returning its currently visible Decl, if any.
   *
   * @param ident the TokenId to look up
   * @return the Decl for it, if any; otherwise, null
   */
  public static Decl lookup (TokenId ident) {
    return (Decl)ident.info;
  }

  /**
   * Checks the use of a name (the TokenId of the Binding b). It sets the decl
   * field of the Binding to the resulting Decl, if there is one, and
   * otherwise throws an exception.
   *
   * @param b the Binding we are to check
   * @return the Decl currently visible for the TokenId of the Binding; if
   * there is no Decl for the name, it throws a SemanticException
   */
  public static Decl checkBindUse (Binding b) {
    if (b == null)
      return null;
    
    Decl    d  = b.decl;
    
    TokenId id = b.id;
    if (d != null)
      return d;
    if (id == null)
      return null;
    
    d = lookup(id);
    if (d != null) {
      b.decl = d;
      return d;
    }

    throw new SemanticException(b.pos, "Use of undeclared identifier \"" + id + "\"");
  }


  // Accessor methods on symbol table statics

  /**
   * Provides read-only access to current (the current SymbolTable for lookup
   * and definition).
   *
   * @return the current SymbolTable
   */
  public static SymbolTable current () {
    return current;
  }

  // Accessor methods on symbol table instances

  /**
   * Provides read-only access to count (number of entries in the
   * SymbolTable).
   *
   * @return the number of entries in this SymbolTable
   */
  public int getCount () {
    return count;
  }

}


// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

