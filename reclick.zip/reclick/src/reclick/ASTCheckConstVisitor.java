package reclick;
import java.util.*;
import static reclick.TokenOp.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for computing
 * compile-time constants, as used in type declarations, case statements, and
 * CONST declarations.
 *
 * @version 1.0
 */
public class ASTCheckConstVisitor extends ASTNullVisitor
{

  /**
   * This remembers the ASTCheckVisitor with which this ASTCheckConstVisitor
   * is working, so that it can access the instance variables of this visitor.
   */
  private final ASTCheckVisitor ckVis;

  /**
   * The obvious constructor, given that we wish to remember the
   * ASTCheckVisitor with which we are working
   *
   * @param cv the ASTCheckVisitor with which we are working
   */
  public ASTCheckConstVisitor (ASTCheckVisitor cv) {
    ckVis = cv;
  }

  /**
   * A private constructor, never invoked, declared precisely so that it
   * cannot be invoked.
   */
  private ASTCheckConstVisitor () { // private so it can't be called
    ckVis = null;  // keeps the compiler happy
  }

  // methods for Expr classes

  /**
   * We should not be called on any kind of Expr for which we have not
   * implemented a specific visit method, so this method will cause an
   * assertion failure if called.
   *
   * @param e an Expr we are trying to visit
   */
  public void visitExpr (Expr e) {
    assert false;  // the visitor should be called only on certain Expr forms
  }

  /**
   * Processes an ExprBinding that we expect to name a constant value.
   *
   * @param e an ExprBinding that should name a constant
   */
  public void visitExprBinding (ExprBinding e) {
    Decl d = SymbolTable.checkBindUse(e.bind);
    ++ckVis.numErrors;
    if (d == null) {
      // error message already emitted
    } else {
      if (!(d instanceof DeclConst)) {
        reclick.ShowError(e.pos, "Identifier must be bound to a constant");
      } else if (!d.resolved) {
        reclick.ShowError(e.pos, "Constant may not involve forward reference");
      } else {
        Expr expr = ((DeclConst)d).expr;
        if (e == null) {
          // would have already printed out an error message
        } else {
          e.object = expr.object;
          e.type   = expr.type;
          --ckVis.numErrors;
        }
      }
    }

    Type      type   = e.type;
    reclickObject object = e.object;
    if (type == null && object != null)
      e.type = object.type;
  }

  /**
   * An ExprInt (integer literal) is fine as a constant.
   *
   * @param e an ExprInt constant
   */
  public void visitExprInt (ExprInt e) {
    // no work necessary
  }

  /**
   * An ExprString is a fine constant
   *
   * @param e an ExprString constant
   */
  public void visitExprString (ExprString e) {
    // no work necessary
  }

  /**
   * An ExprUnary that should describe an expression. The legal cases are + or
   * - of a constant expression.
   *
   * @param e an ExprUnary that should describe a constant value
   */
  public void visitExprUnary (ExprUnary e) {
    reclickObject result = null;
    Expr expr = e.expr;
    expr.accept(this);

    reclickObject o = expr.object;
    if (o.type != Type.theIntType) {
      reclick.ShowError(e.pos, "A signed constant must refer to an integer value");
      ++ckVis.numErrors;
    } else {
      if (MINUS == e.op)
        result = new ObjectValueInteger(TokenInt.get(-o.getValue(),o.getBaseType(),o.getHexValue()));
      else
        result = o;
    }

    if (e.object == null)
      e.object = result;
    if (e.type == null && e.object != null)
      e.type = e.object.type;
  }

@Override
public void visitPacket(Packet p) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtFor(StmtFor s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtInsert(StmtInsert s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtRemove(StmtRemove s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtSet(StmtSet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtGet(StmtGet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtEquals(StmtEquals s) {
	// TODO Auto-generated method stub
	
}

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

