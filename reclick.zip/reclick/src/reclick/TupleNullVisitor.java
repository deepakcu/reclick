package reclick;
//import reclick.Tuples.Cursor;
/**
 * This abstract class can be used as a convenient base for Tuple Visitor
 * classes. Its form is the natural one for a visitor, so we mostly omit
 * documentation on individual methods.
 *
 * @version 1.0
 */
public abstract class TupleNullVisitor implements TupleVisitor {

  public TupleNullVisitor () {}

  // methods for work related to every kind of Tuple
  public void visitEveryBefore (Tuple t) {}
  public void visitEvery       (Tuple t) {}  // gives default behavior (not in TupleVisitor)
  public void visitEveryAfter  (Tuple t) {}
  
  // methods for work related to each opcode
  public void visitProgStart (Tuple t) { visitEvery(t); }
  public void visitMainEnd   (Tuple t) { visitEvery(t); }
  public void visitProgEnd   (Tuple t) { visitEvery(t); }
  public void visitDeclPort  (Tuple t) { visitEvery(t); }
  public void visitSetStmt   (Tuple t) { visitEvery(t); }
  public void visitGetStmt   (Tuple t) { visitEvery(t); }
  /**
   * Intended for visiting the whole program
   */
  public void visitProg () {}
  
  /**
   * Intended for visiting individual basic (or extended basic) blocks
   *
   * @param c a Cursor bounding the Tuple's of the basic (or extended)
   * block
   */
  public void visitBlock (Cursor c) {}
  
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
