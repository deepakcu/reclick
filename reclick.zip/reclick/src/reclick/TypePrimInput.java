package reclick;
/**
 * Represents the (Mini-)Pascal primitive type INTEGER.
 *
 * @version 1.0
 */
public class TypePrimInput extends TypePrim {

  /**
   * unique Java object representing this Type
   */
  public static final TypePrimInput theInputType = new TypePrimInput();

  /**
   * Creates the unique TypePrimInt instance, held in theIntType
   */
  private TypePrimInput () {
    super("input");
    size = 4;
  }

  /**
   * Handles AST visiting for TypeInt nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitTypePrimInput(this);
    super.acceptAfter(v);
  }

  /**
   * indicate that this is indeed the INTEGER Type
   *
   * @return whether this is the Type for INTEGER, namely true
   */
  public boolean isIntegerType () {
    return false;
  }

  /**
   * indicate that this is indeed an INTEGER based Type
   *
   * @return whether this Type is based on INTEGER, namely true
   */
  public boolean isIntBasedType () {
    return false;
  }

  /**
   * indicate that this is indeed an ordinal Type
   *
   * @return whether this Type is ordinal, namely true
   */
  public boolean isOrdinalType () {
    return true;
  }

  /**
   * indicate whether t is compatible with this Type
   *
   * @param t the Type to test
   * @return whether t is compatible with INTEGER, which is true if t's base
   * Type is INTEGER
   */
  public boolean isCompatibleWith (Type t) {
    assert t != null;
    return this == t.getBaseType();
  }

  /**
   * the minimum value legal for this type, namely 0x40000000 (which has a
   * nice Java name :-)
   *
   * @return the minimum legal INTEGER value
   */
  /*
  public int minValue () {
    return Integer.MIN_VALUE;
  }
  */

  /**
   * the maxnimum value legal for this type, namely 0x3fffffff (which has a
   * nice Java name :-)
   *
   * @return the maximum legal INTEGER value
   */
  /*
  public int maxValue () {
    return Integer.MAX_VALUE;
  }
  */

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

