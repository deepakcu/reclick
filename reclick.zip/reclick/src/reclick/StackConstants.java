package reclick;
/**
 * StackConstants defines names for registers, stack frame offsets, etc.
 *
 * @version 1.0
 */
public interface StackConstants {

  /**
   * We bound the frame size at 2^16-1 since that it the maximum offset we can
   * use in lw/sw instructions for our target architecture (MIPS).
   */
  public static final int MaxFrameSize = 32767;

  /**
   * Offset from the frame pointer of the return address for the frame.
   */
  public static final int RETURN_ADDR = 0;

  /**
   * Offset from the frame pointer of the dynamic chain for the frame, i.e.,
   * the frame pointer for the caller.
   */
  public static final int DYNAMIC_CHAIN = 4;

  /**
   * Offset from the frame pointer of the static chain for the frame, i.e.,
   * the frame pointer for the nearest frame for the statically enclosing
   * procedure, supporting reference to outer scope variables.
   */
  public static final int STATIC_CHAIN = 8;

  /**
   * Total size of the linkage part of a frame, consisting of the return
   * address and static and dynamic chains.
   */
  public static final int FrameLinkageSize = 12;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
