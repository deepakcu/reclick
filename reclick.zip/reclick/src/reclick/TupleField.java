package reclick;
/**
 * This class defines the various kinds of fields that can occur in the
 * Mini-Pascal compiler's tuple intermediate language. TupleField is itself an
 * abstract class; each kind of TupleField is a concrete subclass of it,
 * defined as a static nested class here.
 *
 * @version 1.0
 */
public abstract class TupleField {

  /**
   * Indicates whether the field describes a temporary (versus non-temporary)
   * variable; for many kinds of fields does not make sense, but is convenient
   * to provide at this level (avoids verbose casts).
   */
  public boolean isTemp = false;



}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

