package reclick;
/**
 * This interface defines things common to all AST (Abstract Syntax Tree)
 * visitor classes.
 *
 * We omit javadoc on individual methods, since their interface is obvious.
 * @see ASTNullVisitor for additional explanation
 * @version 1.0
 */
public interface ASTVisitor {

  // methods for work related to every node
  public void visitEveryBefore (ASTNode n);
  public void visitEveryAfter  (ASTNode n);
  
  public void visitStmts (Stmts ss);
  public void visitBlock (Block b);
  public void visitComponent (Component c);
  public void visitBinding (Binding b);
  
  // methods related to Decl classes
  public void visitDeclBefore (Decl d);  // these are for all kinds
  public void visitDecl       (Decl d);
  public void visitDecls      (Decls dd);
  public void visitExprs      (Exprs ee);
  public void visitDeclAfter  (Decl d);
  public void visitDeclConst  (DeclConst d);
  public void visitDeclField  (DeclField d);
  public void visitDeclPosition  (DeclPosition p);
  //public void visitDeclFormal (DeclFormal d);
  //public void visitDeclProcFunc (DeclProcFunc d);
  public void visitDeclComponent (DeclComponent d);
  //public void visitDeclSpecial (DeclSpecial d);
  public void visitDeclType 	(DeclType d);
  public void visitDeclVar 		(DeclVar d);
  public void visitDeclPacket 	(DeclPacket p);
  public void visitDeclInput	(DeclInput d);
  public void visitDeclOutput	(DeclOutput d);

  // methods for Expr classes
  public void visitExprBefore (Expr e);  // these are for all kinds
  public void visitExpr       (Expr e);
  public void visitExprAfter  (Expr e);
  public void visitPacket     (Packet p);
  
  public void visitExprBinary (ExprBinary e);
  public void visitExprBinding (ExprBinding e);
  //public void visitExprCall (ExprCall e);
  public void visitExprError (ExprError e);
  public void visitExprId (ExprId e);
  public void visitExprInt (ExprInt e);
  //public void visitExprNil (ExprNil e);
  public void visitExprString (ExprString e);
  public void visitExprUnary (ExprUnary e);

  
  

  // methods for Stmt classes
  public void visitStmtBefore (Stmt s);  // these are for all kinds
  public void visitStmt       (Stmt s);
  public void visitStmtAfter  (Stmt s);

  public void visitStmtAssign (StmtAssign s);
  //public void visitStmtCall (StmtCall s);
  //public void visitStmtCase (StmtCase s);
  public void visitStmtCompound (StmtCompound s);
  public void visitStmtEmpty (StmtEmpty s);
  public void visitStmtFor (StmtFor s);
  public void visitStmtIf (StmtIf s);
  //public void visitStmtRepeat (StmtRepeat s);
  //public void visitStmtWhile (StmtWhile s);
  public void visitStmtInsert (StmtInsert s);
  //public void visitStmtPush (StmtPush s);
  public void visitStmtRemove (StmtRemove s);
  public void visitStmtSet (StmtSet s);
  public void visitStmtGet (StmtGet s);
  public void visitStmtEquals(StmtEquals s);
  public void visitStmtConcat(StmtConcat s);
  public void visitStmtLookup(StmtLookup s);
  
  // methods for Type classes
  public void visitTypeBefore (Type t);  // these are for all kinds
  public void visitType       (Type t);
  public void visitTypeAfter  (Type t);

  //public void visitTypeArray (TypeArray t);
  public void visitTypeError (TypeError t);
  public void visitTypeId (TypeId t);
  //public void visitTypePointer (TypePointer t);
  
  public void visitTypePrimBefore (TypePrim t);  // for all Prim types
  public void visitTypePrim       (TypePrim t);
  public void visitTypePrimAfter  (TypePrim t);

  public void visitTypePrimBool (TypePrimBool t);
  public void visitTypePrimInt (TypePrimInt t);
  public void visitTypePrimPacket (TypePrimPacket p);
  public void visitTypePrimField (TypePrimField f);
  public void visitTypePrimPosition (TypePrimPosition p);
  public void visitTypePrimOutput(TypePrimOutput typePrimOutput);
  public void visitTypePrimInput(TypePrimInput typePrimInput);
  
  //public void visitTypePrimNil (TypePrimNil t);
  

  public void visitTypePrimString (TypePrimString t);
  //public void visitTypeRecord (TypeRecord t);
  //public void visitTypeRange (TypeRange t);


  
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
