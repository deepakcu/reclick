package reclick;
/**
 * Represents the (Mini-)Pascal primitive type Boolean.
 *
 * @version 1.0
 */
public class TypePrimBool extends TypePrim {

  /**
   * unique Java object representing this primitive Type
   */
  public static final TypePrimBool theBoolType = new TypePrimBool();

  /**
   * Creates a new TypePrimBool instance; private since we allow
   * just the one instance theBoolType
   */
  private TypePrimBool () {
    super("boolean");
    size = 4;
  }

  /**
   * Handles AST visiting for TypePrimBool nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitTypePrimBool(this);
    super.acceptAfter(v);
  }

  /**
   * indicates that this is indeed a Boolean Type
   *
   * @return whether this is theBoolType, namely true
   */
  public boolean isBoolType () {
    return true;
  }

  /**
   * indicates that this is indeed an ordinal Type
   *
   * @return whether this is an ordinal type, namely true
   */
  public boolean isOrdinalType () {
    return true;
  }

  /**
   * indicates whether t is compatible with this Type, i.e., its base type is
   * theBoolType
   *
   * @param t the Type we are to test
   * @return whether t is compatible with this Type
   */
  public boolean isCompatibleWith (Type t) {
    assert t != null;
    return this == t.getBaseType();
  }

  /**
   * the min value of this Type is 0, which represents FALSE
   *
   * @return the minimum value of this Type, namely 0 (FALSE)
   */
  public int minValue () {
    return 0;
  }

  /**
   * the max value of this Type is 1, which represents TRUE
   *
   * @return the maximum value of this Type, namely 1 (TRUE)
   */
  public int maxValue () {
    return 1;
  }

}
// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

