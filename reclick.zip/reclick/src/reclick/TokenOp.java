package reclick;
/**
 * Represents all operator tokens in the <i>Pascal</i> language that are used
 * in <i>Mini-Pascal</i> as defined by the <i>Pascal User Manual and
 * Report</i>.
 *
 * @version 1.0
 */
public enum TokenOp implements Token {

  // single character operators
  PLUS   ("+" , sym.PLUS  ),
  MINUS  ("-" , sym.MINUS ),
  LT     ("<" , sym.LT    ),
  GT     (">" , sym.GT    ),
  LPAREN ("(" , sym.LPAREN),
  RPAREN (")" , sym.RPAREN),
  AND    ("&" , sym.AND  ),
  OR	 ("|" , sym.OR   ),
  AST    ("*" , sym.AST  ),
  DIV    ("/" , sym.DIV  ),
  MOD    ("%" , sym.MOD  ),
  COMMA  ("," , sym.COMMA ),
  SEMI   (";" , sym.SEMI  ),
  LBRACK ("[" , sym.LBRACK),
  RBRACK ("]" , sym.RBRACK),
  LCBRACK("{" , sym.LCBRACK),
  RCBRACK("}" , sym.RCBRACK),
  EQUAL  ("=" , sym.EQUAL),
  COL	 (":" , sym.COL),
  NOT	 ("~" , sym.NOT),
  USCORE ("_" , sym.USCORE),
  
  // double character operators
  LE     ("<=", sym.LE    ),
  GE     (">=", sym.GE    ),
  EQ     ("==", sym.EQ    ),
  NE     ("!=", sym.NE   ),
  LSHIFT ("<<", sym.LSHIFT),
  RSHIFT (">>", sym.RSHIFT),
  HEX	 ("0x", sym.HEX),
  
  EOF    ("EOF", sym.EOF  );  // conveniently ends the list
  // EOF is not really an operator, but this was a convenient
  // enum in which to place it :-)

  /**
   * StringMap holding all operator tokens, to allow them to be
   * looked up given their String representation
   */
  private static final StringMap<TokenOp> opMap = new StringMap<TokenOp>();

  /**
   * the string defining this operator
   */
  public final String string;

  /**
   * the Token's unique token code
   */
  private final int code;

  /**
   * return the Token's unique token code
   *
   * @return the Token's unique token code
   */
  public int code () {
    return code;
  }

  /**
   * Creates a new TokenOp instance.
   * <b>NOTE: this assumes that s is new!</b>
   *
   * Private: all instances are created by a static initializer of this class.
   *
   * @param cs CharSequence defining this operator
   * @param c symbol code for this operator
   */
  TokenOp (CharSequence cs, int code) {
    // note: this assume that cs is new!
    this.code   = code;
    this.string = cs.toString();
  }

  /**
   * Retrieves TokenOp given its CharSequence representation.
   *
   * @param cs defining CharSequence
   * @return matched TokenOp, null otherwise
   */
  public static TokenOp get (CharSequence cs) {
    return opMap.get(cs);
  }

  /**
   * provides a "hook" for a visitor to do something before each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptBefore (TokenVisitor v) {
    v.visitEveryBefore(this);
  }

  /**
   * Supports visiting objects in the Token class hierarchy; calls
   * acceptBefore() and acceptAfter() hooks as well as a visit method
   * particular to this class.
   *
   * @param v the TokenVisitor to call, indicating this object is a TokenOp
   */
  public void accept (TokenVisitor v) {
    this.acceptBefore(v);
    v.visitTokenOp(this);
    this.acceptAfter(v);
  }

  /**
   * provides a "hook" for a visitor to do something after each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptAfter (TokenVisitor v) {
    v.visitEveryAfter(this);
  }

  /**
   * String representation of an operator.
   *
   * @return the String defining this operator
   */
  public String toString () {
    return string;
  }

  /**
   * Pretty string of an operator.
   *
   * @return the String defining this operator, with a prefix to distinguish
   * it from other kinds of Token objects
   */
  public String toPrettyString () {
    String suffix = this.toString();
    if (this == EOF) return suffix;
    return "@" + suffix;
  }

  static {
    for (TokenOp t : TokenOp.values()) {
      String s = t.string;
      if (t != EOF)
        opMap.put(s, t, StringMap.getHash(s));
    }
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

