package reclick;
/**
 * Representation for an expression binding.  This is used to bind a name or
 * symbol used in an expression to its declaration, for example, the use of a
 * variable or constant.
 *
 * @version 1.0
 */
public class ExprBinding extends Expr {

  /**
   * the Binding of this expression
   */
  public final Binding bind;

  /**
   * indicates if this binding is a no-argument function/procedure call
   */
  public boolean isCall = false;

  /**
   * Creates a new ExprBinding instance given its Binding
   *
   * @param b the Binding of this expression
   */
  public ExprBinding (Binding b) {
    super(b.pos, b.endPos);
    bind = b;
  }

  /**
   * Handles AST visiting for ExprBinding nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitExprBinding(this);
    super.acceptAfter(v);
  }

  /**
   * Tries to bind this ExprBinding as a reference to a constant value, e.g.,
   * in a CONST Decl, and TypeRange, etc.
   */
  
  public void bindConstant () {
    Decl d = SymbolTable.checkBindUse(bind);

    if (d == null) {
      // error message already emitted
    }
    else {
      if (!(d instanceof DeclConst)) {
        reclick.errStream.println ("Identifier must be bound to a constant");
      }
      else if (!d.resolved) {
        reclick.errStream.println ("Constant may not involve forward reference");
      }
      else {
        Expr e = ((DeclConst)d).expr;
        if (e == null) {
          // would have already printed out an error message
        }
        else {
          object = e.object;
          type   = e.type;
        }
      }
    }

    if (type == null && object != null)
      type = object.type;
  }
  

  /**
   * This form has a variable name, namely the String in the TokenId in the
   * Binding
   *
   * @return a String giving the name of the variable/constant
   * being accessed
   */
  public String varName () {
    return bind.id.string;
  }
  
  
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

