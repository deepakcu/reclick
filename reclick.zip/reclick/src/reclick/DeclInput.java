package reclick;
/**
 * Representation of a variable declaration.
 *
 * @version 1.0
 */
public class DeclInput extends Decl {

  /**
   * Type of this variable
   */
  public Type type;
  // Note: cannot be final because we allocate DeclVar objects and set their
  // type later (see Decls.parseVarDecls)

  /**
   * MPCObject representing the address allocated to this variable;
   * should be an ObjectMemory.
   */
  public reclickObject address;

  /**
   * Creates a new DeclVar instance given its Binding (name)
   *
   * @param b the binding (name) of this variable declaration
   */
  public DeclInput (Binding b) {
    super(b, b.pos, -1);
    type = Type.theInputType;
  }

  /**
   * Handles AST visiting for DeclVar nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclInput(this);
    super.acceptAfter(v);
  }

  /**
   * Returns the MPCObject for the variables allocated address
   *
   * @return an MPCObject giving the address allocated to this
   * variable
   */
  public reclickObject getObject () {
    return getObject(address);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

