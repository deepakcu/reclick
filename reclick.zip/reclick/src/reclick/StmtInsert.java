package reclick;
/**
 * Representation of a InsertAfter statement.
 *
 * <i>
 * The InsertAfter statement is used to insert a field after a particular
 * field of the packet.
 * </i>
 *
 * Example:
 * 
 * INSERT binding:b AFTER binding:b OF Packet:p
 *
 * @version 1.0
 */
public class StmtInsert extends Stmt {

  /**
   * srcField (The field which will be inserted)
   */
  public final Binding src;
  
  /**
   * The position (word, bit) at which the field will be inserted
   *    */
  public final Binding pos;
  
  /**
   * The packet for which the inesrtion will be made
   */
  public final Binding packet;
  
  
  /**
   * Two temporary MPCObject's used in code generation
   */
  public reclickObject tempObj1;
  public reclickObject tempObj2;

  /**
   * Creates a new StmtInsertAfter instance given the Binding (name) of
   * its control variable, the init Expr, direction of progression (up/down),
   * the final/limit Expr, the Stmt for the loop body, and the source
   * (start/end) position
   *
   * @param b     Binding (name) of the control variable
   * @param i     initialization Expr
   * @param up    direction of progression
   * @param t     final Expr
   * @param st    Stmt to execute
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public StmtInsert (Binding src, Binding pos, Binding pkt, int left, int right) {
    super(left, right);
    this.src 	= src;
    this.pos 	= pos;
    this.packet = pkt;    
  }

  /**
   * Handles AST visiting of StmtFor nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitStmtInsert(this);
    super.acceptAfter(v);
  }

  /**
   * If false, suppresses code generation
   */
  public boolean ok = false;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

