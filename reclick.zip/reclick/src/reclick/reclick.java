package reclick;
import java.io.*;
import static reclick.reclickContext.*;
import static reclick.reclickContext.Flag.*;
import java.util.ArrayList;
/**
 * reclick stands for Field REconfigurable Click - An high
 * level programming language for modular designs in FPGAs
 * This is the driver class that initiates other compiler passes
 * Author: Deepak Unnikrishnan
 * Courtesy: Dr. Eliot J Moss, UMass CS
 */
public class reclick {

  /**
   * Stream to receive error output; generally System.err.
   */
  public static reclickStream errStream = new reclickStream(new PrintStream(System.err));

  /**
   * Stream to receive verbose output; 
   * generally the same as errStream, which is typically System.err.
   */
  public static reclickStream verbStream = errStream;

  /**
   * The Parser instantiated for this input file.
   */
  public static Parser parser;

  /**
   * Compilation context for this run; generally should not access it as a
   * static, but it should be passed to the phase, etc.
   */
  public static final reclickContext context = new reclickContext(verbStream, errStream);

  /**
   * Convenient short-hand for testing flags
   *
   * @param flag to test
   * @return a boolean indicating whether the flag is set
   */
  public static boolean flag (Flag flag) {
    return context.flag(flag);
  }

  /**
   * Extracts the root (basename) part of a filename
   *
   * @param base the String from which to extract the root part
   * @return the root part String
   */
  private static String getRootPart (String base) {
    int idxDot  = base.lastIndexOf('.');
    int idxDir  = base.lastIndexOf(File.separatorChar);  // namely '/' under Unix, etc.
    int rootLen = base.length();
    if (idxDir < idxDot) {
      // if there is a dot, and no slash after it, then
      //    the part up to the dot is the root
      // otherwise, the whole name is the root (as in the initialization above)
      rootLen = idxDot;
    }
    return base.substring(0, rootLen);
  }
  
  private static String getRTLDirectory (String base) {
	  int idxDir  = base.indexOf(File.separatorChar);  // namely '/' under Unix, etc.
	  int lastIndex = base.lastIndexOf(File.separatorChar);
	  String fileName = base.substring(lastIndex,base.length());
	  return base.substring(0, idxDir)+File.separator+"rtl"+File.separator+fileName;
  }
  

  /**
   * Constructs a filename given an original name and a new extension.
   * An <i>extension</i> is the part after the dot in a filename; thus
   * pas is the extension in the name "foo.pas".
   * @param base  The original filename String; may or may not have an extension
   * @param ext   The desired new extension String
   * @return      The String giving a filename formed by replacing (or adding)
   *              the new extension to the base filename
   */
  private static String makeFilename (String base, String ext) {
    return getRootPart(base) + "." + ext;
  }

  /**
   * Tries to open the file that makeFilename builds; prints error message and
   * returns null if it fails.
   *
   * @param base The original filename String
   * @param ext  The extension for the new file
   * @param which Short description of which output file (for error messages)
   * @return An open reclickStream for output to the file, or null if there is an error
   */
  public static reclickStream makereclickStream (String base, String ext, String which) {
    String name = makeFilename(base, ext);
    try {
      return new reclickStream(name);
    } catch (Throwable e) {
      errStream.printf("Could not open %s output file %s%n", which, name);
      e.printStackTrace(errStream);
      return null;
    }
  }

  /**
   * Goes through flag letters, adjusting debug and output controls as appropriate.
   *
   * @param flags Command line argument String containing flags,
   * including leading '-'.
   */
  private static void processCommandLineFlags (String flags) {
    // start at 1, to skip the leading '-'
    for (int j = 1, n = flags.length(); j < n; ++j) {
      char c = flags.charAt(j);
      if (letterToFlag.containsKey(c)) {
        letterToFlag.get(c).toggle(context.flags);
      } else {
        errStream.printf("Unrecognized flag %c ignored%n", c);
      }
    }
  }

  /**
   * Prints a "usage" message, describing how to invoke reclick and the available
   * command line arguments and flags.
   * @param ps Where to print the "usage" message.
   */
  /*
  private static void printUsage (PrintStream ps) {
    ps.print("Usage: reclick [-");
    for (Flag flag : Flag.values()) {
      ps.print(flag.letter);
    }
    ps.println("] infile");
    ps.println("  infile may omit a trailing .p or .pas");
    for (Flag flag : Flag.values()) {
      ps.printf("  -%c %s%n", flag.letter, flag.help);
    }
  }
  */
  
  /**
   * Displays (to an output) the current reclick flag settings.
   * @param ps Where to display the flag settings.
   */
  /*
  private static void showFlags (PrintStream ps) {
    ps.println("Flag settings:");
    for (Flag flag : Flag.values()) {
      ps.printf("  %-28s = %s%n", flag.desc,
                (flag(flag) ? "on" : "off"));
    }
  }
  */

  /**
   * Processes command line argument that gives the input filename. Tries name
   * as is, then with extension p and extension
   * pas. Terminates processing if it cannot find a file and open
   * it successfully.
   * @param inName Initial name for file to try to open.
   * @return An opened input stream to the Pascal input file.
   */
  private static InputStream openInputStream (String inName) {
    // try name as is, and then with extension "p" and "pas"
    File inFile = new File(inName);
    if (!inFile.canRead()) {
      String inName2 = makeFilename(inName, "r");
      inFile = new File(inName2);
      if (!inFile.canRead()) {
        String inName3 = makeFilename(inName, "rclk");
        inFile = new File(inName3);
        if (!inFile.canRead()) {
          errStream.printf("Could not open %s, %s, or %s!%n",
                           inName, inName2, inName3);
          System.exit(1);
          // should not get here
          return null;
        }
      }
    }
    context.inFileName = inFile.getName();

    // Now that we have the name, try to open it as a FileInputStream
    InputStream inStream = null;
    try {
      inStream = new FileInputStream(inFile);
    } catch (Throwable e) {
      errStream.printf("Could not open input file %s!%n", inFile);
      e.printStackTrace(errStream);
      System.exit(1);
      // should not get here
    }
    return inStream;
  }

  /**
   * This is the "" method of the reclick Compiler. If invoked with an
   * empty command line, it will offer help describing its command line format
   * and available flags.
   * @param args The command line arguments String[]
   */
  public static void main (String args[]) {
    // Step 1: go through initial command line arguments and set flags, etc.
    int argNum;

    // Step 1a: go through any initial command line arguments that start
    // with a hyphen, to process flags
    for (argNum = 0;
         argNum < args.length && args[argNum].startsWith("-");
         ++argNum) {
      processCommandLineFlags(args[argNum]);
    }

    // Step 1b:
    // if there is no input file to process, give "usage" message
    if (argNum >= args.length) {
      //printUsage(errStream);
      errStream.println("Illegal use of program");
      System.exit(1);
      return; // should not get here ...
    }

    // Step 1c: show flag settings, if requested
    //if (flag(Verbose))
      //showFlags(verbStream);

    // Step 2: process command line arguments that follow any initial ones
    // that start with a hyphen: these result in the setting up of input
    // and output filenames and streams

    // Step 2a: Open the input file
    String inName = args[argNum++];
    inName = makeFilename(inName, "rclk");
    verbStream.print("Trying to open file "+inName);	
    InputStream inStream = openInputStream(inName);
    verbStream.print("File opened successfully ");
    if (argNum < args.length) {
      errStream.println("Extra command line argument(s) ignored.");
    }
    
    
    String baseName = context.baseName = getRootPart(inName);
    
    context.rtlDirectory = getRTLDirectory(baseName);
    
    // Step 3: parsing
    try {
      // quit if there was an error

      //Perform scanning and parsing
      if ((new Parse(context)).perform(inStream))
          System.exit(1);

      verbStream.print("Now checking for syntax errors..");
      if ((new Check(context)).perform() > 0)
          System.exit(2);
      
      int tupleErrors = (new Generate(context)).perform();
      if (tupleErrors > 0) {
        errStream.println("Terminating because of allocation / tuple generation errors.");
        System.exit(3);
        return;   // won't get here, but emphasizes control flow :-)
      }
      
      
      //Parser p = new Parser(new Lexer(new FileReader(inName)));
      //Object result = p.parse().value;      
	
      //if ((new Parse(context)).perform(inStream))
      //  System.exit(1);

    } catch (SemanticException e) {
      if (flag(Debug))
        e.printStackTrace(errStream);
      reclick.ShowError(e.pos, e.getMessage());
      return;
    } catch (Exception e) {
      errStream.println("Exception occurred:");
      e.printStackTrace(errStream);
      errStream.println("Aborting ...");
      System.exit(20);
      // cannot get here
      return;
    } catch (Error e) {
      errStream.println("Error occurred:");
      e.printStackTrace(errStream);
      errStream.println("Aborting ...");
      System.exit(21);
      // cannot get here
      return;
    }

    // Done
    if (flag(Verbose)) verbStream.println("Done.");
    System.exit(0);
    // should not get here
    return;
  }

  /**
   * Useful subroutine for printing the current Tuples, indicates whether to
   * print regular basic blocks (bbprint) and/or extended basic blocks
   * (xbbprint), and is given a base filename for the output and a suffix; it
   * adds bbor xbb to the suffix, as appropriate
   *
   * @param bbprint true iff we should print a regular basic blocks (bb) file
   * @param xbbprint true iff we should print an extended basic blocks (xbb) file
   * @param base the base name of the file(s) to receive output
   * @param suffix a suffix for the filename; we add "bb" or "xbb" to it
   */
  /*
  public static void printTuples (boolean bbprint, boolean xbbprint,
                                  String base, String suffix) {
    if (bbprint) {
      String suffbb = suffix + "bb";
      reclickStream pps = makereclickStream(base, suffbb, suffbb);
      if (pps != null) {
        BlocksIterator bi = new BlocksIterator(new Tuples.Cursor(), false);
        bi.accept(new TuplePrintVisitor(pps));
        pps.close();
      }
    }
    if (xbbprint) {
      String suffxbb = suffix + "xbb";
      reclickStream pps = makereclickStream(base, suffxbb, suffxbb);
      if (pps != null) {
        BlocksIterator bi = new BlocksIterator(new Tuples.Cursor(), true);
        bi.accept(new TuplePrintVisitor(pps));
        pps.close();
      }
    }
  }*/
  
  /**
   * Useful subroutine for printing the current Tuples, indicates whether to
   * print regular basic blocks (bbprint) and/or extended basic blocks
   * (xbbprint), and is given a base filename for the output and a suffix; it
   * adds bbor xbb to the suffix, as appropriate
   *
   * @param bbprint true iff we should print a regular basic blocks (bb) file
   * @param xbbprint true iff we should print an extended basic blocks (xbb) file
   * @param base the base name of the file(s) to receive output
   * @param suffix a suffix for the filename; we add "bb" or "xbb" to it
   */
  public static void printTuples (ArrayList<Tuples> t, ArrayList<Cursor> c,boolean bbprint, boolean xbbprint,
                                  String base, String suffix) {
      String suffbb = "v";
      reclickStream pps = makereclickStream(base, suffbb, suffbb);
      if (pps != null) {
        //BlocksIterator bi = new BlocksIterator(new Tuples.Cursor(), false);
    	for(int i=0;i<t.size();i++) {  
    		pps.print(t.get(i).tupleHeader);
    		BlocksIterator bi = new BlocksIterator(t.get(i), c.get(i), false);  
    		bi.accept(new TuplePrintVisitor(pps));
    		pps.print(t.get(i).tupleTrailer);
    	}
        pps.close();
      }
  }

  
  /**
   * Prints an error message given also a line number in the input file.
   * @param pos The input position of the start of the error; first line is 1
   * @see InputPos
   * @param message The error message to print
   */
  public static void ShowError (int pos, String message) {
    errStream.printf("line %d: %s%n", InputPos.lineOf(pos), message);
    errStream.flush();
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

