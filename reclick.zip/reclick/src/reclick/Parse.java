package reclick;
import java.util.*;
import java.io.*;
import static reclick.reclickContext.Flag.*;

/**
 * This class drives the semantic checking of the AST.
 *
 * @version 1.0
 */
public class Parse extends Phase<Boolean,InputStream> {

  /**
   * Obvious constructor
   *
   * @param context the compilation context
   */
  public Parse (reclickContext context) {
    super(context);
  }

  /**
   * perform runs the phase
   *
   * @param inStream an InputStream for the file to parse
   * @return a boolean indicating whether there was an error
   */
  public Boolean perform (InputStream inStream) {
    setStream(context.flag(TokenPrint), context.baseName, "token", "token", true);
    if (context.flag(Verbose)) {
      context.verbStream.printf("Parsing input file \"%s\".%n", context.inFileName);
      if (ps != null) {
        context.verbStream.printf("Writing tokens to file \"%s\".%n", ps.name);
      }
    }

    // create the Scanner for the parser
    context.scanner = new Lexer(inStream);//new reclickScanner(inStream, ps, context.errStream);

    // create the Parser
    context.parser = new Parser(context.scanner, context.errStream);

    // parse!
    try {
      context.component = (Component)(context.parser.parse().value);
    } catch (Exception e) {
      context.errStream.println("Exception occurred:");
      e.printStackTrace(context.errStream);
      context.errStream.println("Aborting ...");
      context.parser.error = true;
    }

    if (context.parser.error) return true;
    // ... and otherwise, print the parse tree, if requested
    
    if (context.flag(ParsePrint)) {
      //reclickStream str = reclick.makereclickStream(context.baseName, "parse", "parser");
      System.out.println("RTL directory is "+context.rtlDirectory);	
      reclickStream str = reclick.makereclickStream(context.rtlDirectory, "parse", "parser");	
      if (str != null) {
        context.component.accept(new ASTPrintVisitor(str));
        str.close();
      }
    }
    
    return false;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

