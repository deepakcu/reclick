package reclick;

/**
 * Representation of a variable declaration.
 *
 * @version 1.0
 */
public class DeclVar extends Decl {

  /**
   * Type of this variable
   */
  public Type type;
  // Note: cannot be final because we allocate DeclVar objects and set their
  // type later (see Decls.parseVarDecls)

  /**
  * A special boolean variable to indicate if this
  * variable requires special storage (Eg: memory) in hardware
  * True if it requires. False, otherwise
  */
  public boolean isHandlerVar;  
  
  /**
   * MPCObject representing the address allocated to this variable;
   * should be an ObjectMemory.
   */
  public reclickObject address;

  /**
   * Translation to hardware requires a unique bit width
   * for each variable (default = 32)
   */
  public int width;

  
  /**
   * The value assigned to this variable (if any) by an expression (ExprInt)
   * 
   */
  public int value;
  
  
  /**
   * Creates a new DeclVar instance given its Binding (name)
   *
   * @param b the binding (name) of this variable declaration
   */
  public DeclVar (Binding b) {
    super(b, b.pos, -1);
    type = Type.theErrorType;
  }

  /**
   * Handles AST visiting for DeclVar nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclVar(this);
    super.acceptAfter(v);
  }

  /**
   * Returns the MPCObject for the variables allocated address
   *
   * @return an MPCObject giving the address allocated to this
   * variable
   */
  public reclickObject getObject () {
    return getObject(address);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

