package reclick;
/**
 * An MPCObject represent the location (or, for constants, the
 * value) of an entity at run time. There are several kinds, each with their
 * own subclass.
 *
 * @author Eliot Moss
 * @version 1.0
 */
public abstract class reclickObject {

  /**
   * built-in primitive <i>Mini-Pascal</i> TRUE object
   */
  public static final reclickObject theTrueObject;

  /**
   * built-in primitive <i>Mini-Pascal</i> FALSE object
   */
  public static final reclickObject theFalseObject;

  /**
   * built-in primitive <i>Mini-Pascal</i> NIL object
   */
  public static final reclickObject theNilObject;

  /**
   * unique special error object
   */
  public static final reclickObject theErrorObject;

  public static boolean Ok (reclickObject obj) {
    if (obj == null)
      return false;
    else if (obj == theErrorObject)
      return false;
    else
      return true;
  }

  static {
    /* initialize built-in <i>Mini-Pascal</i> objects */
	  //Deepak temporary comment
    theTrueObject  = new ObjectValueInteger(TokenInt.get(1,BaseType.Dec,null), Type.theBoolType);
    theFalseObject = new ObjectValueInteger(TokenInt.get(0,BaseType.Dec,null), Type.theBoolType);
    theNilObject   = null; //new ObjectValueInteger(TokenInt.get(0), Type.theNilType ); //Deepak comment
    theErrorObject = ObjectValueError.theErrorObject;
  }

  /**
   * Type of the object
   */
  public Type type;

  /**
   * Handles MPCObject visiting work done before visiting the MPCObject
   *
   * @param v an ObjectVisitor
   */
  public void acceptBefore (ObjectVisitor v) {
    v.visitEveryBefore(this);
  }

  /**
   * Handles MPCObject visiting for MPCObject nodes
   *
   * @param v an ObjectVisitor
   */
  public abstract void accept (ObjectVisitor v);

  /**
   * Handles MPCObject visiting work done after visiting the MPCObject
   *
   * @param v an ObjectVisitor
   */
  public void acceptAfter (ObjectVisitor v) {
    v.visitEveryAfter(this);
  }

  /**
   * Used to return the value of an integer constant; should call ONLY on such
   * MPCObject nodes, since otherwise it causes an assertion failure
   *
   * @return an int giving the value of the constant
   */
  public int getValue () {
    assert false;  // override in ObjectValueInteger
    return -1;     // never reached, but needed to silence Java compiler
  }
  
  
  public BaseType getBaseType() {
	 assert false;        // override in ObjectValueInteger
	 return BaseType.Dec; // never reached, but needed to silence Java compiler	  
  }
  
  public String getHexValue() {
		 assert false;        // override in ObjectValueInteger
		 return null;         // never reached, but needed to silence Java compiler	  
	  }

  /**
   * Used to return the value of a string constant; should call ONLY on such
   * MPCObject nodes, since otherwise it causes an assertion failure
   *
   * @return a String giving the value of the string constant
   */
  public String getStringValue () {
    assert false;  // override in ObjectValueString
    return null;   // never reached, but needed to silence Java compiler
  }

  /**
   * interface to method to return a TupleField suitable for accessing this
   * MPCObject in a Tuple instruction
   *
   * @return a TupleField for this MPCObject
   */
  //public abstract TupleField tupleField ();

  /**
   * interface to method to return a TupleField suitable for accessing the
   * address of this (non constant) MPCObject in a Tuple instruction
   *
   * @return a TupleField for this MPCObject's address
   */
  /*
  public TupleField tupleFieldForAddress () {
    assert false;              // override in ObjectMemory
    return (TupleField)null;
  }
  */

  /**
   * Gives the minimum value for this MPCObject, taking into account its Type
   * (e.g., INTEGER vs range types) and its value (constant vs variable).
   *
   * @return an int giving the minimum possible value of this
   * MPCObject
   */
  public int minValue () {
    // override for objects with more tightly bounded values
    return Integer.MIN_VALUE;  // the most negative number;
  }

  /**
   * Gives the maximum value for this MPCObject, taking into account its Type
   * (e.g., INTEGER vs range types) and its value (constant vs variable).
   *
   * @return an int giving the maximum possible value of this
   * MPCObject
   */
  public int maxValue () {
    // override for objects with more tightly bounded values
    return Integer.MAX_VALUE;  // the largest positive number
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

