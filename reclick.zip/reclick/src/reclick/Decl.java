package reclick;
/**
 * An abstract representation of a <i>Pascal</i> declaration.
 *
 * @version 1.0
 */
public abstract class Decl extends ASTNode {

  /**
   * The Binding in the Pascal declaration, which gives access to the name
   * (TokenId)
   */
  public final Binding bind;

  /**
   * The next outer declaration of same identifier
   */
  public Decl outer = null;

  /**
   * The symbol table (scope) in which this Decl occurs
   */
  public SymbolTable symbolTable = null;

  /**
   * The declaration number within a scope; ok ones are number from 1 up
   */
  public int declNumber = 0;
  
  /**
   * Indicates if this declaration is "resolved", meaning we have determined
   * the proper scope in which all names within it are declared.
   */
  public boolean resolved = false;

  /**
   * Indicates whether the Decl has had any necessary variable successfully
   * allocated
   */
  public boolean allocated = false;

  /**
   * Creates a new Decl instance, given the Binding (name) and
   * its source code start and end positions
   *
   * @param b     Binding (name) of this declaration
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public Decl (Binding b, int left, int right) {
    super(left, right);
    bind   = b;
    b.decl = this;
  }

  /**
   * Creates a new Decl instance when the ending position
   * is not conveniently known.
   *
   * @param b Binding (name) of this declaration
   */
  public Decl (Binding b) {
    this(b, b.pos, -1);
  }

  /**
   * Handles AST visiting work that should happen before visiting each Decl
   * (or subclass) node
   *
   * @param v an ASTVisitor
   */
  public void acceptBefore (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclBefore(this);
  }

  /**
   * Handles AST visiting work that should happen after visiting each Decl
   * (or subclass) node
   *
   * @param v an ASTVisitor
   */
  public void acceptAfter (ASTVisitor v) {
    v.visitDeclAfter(this);
    super.acceptAfter(v);
  }

  /**
   * Gives a simple printable form of the Decl, namely the String form of the
   * TokenId of its declaration
   *
   * @return a String for the Decl's TokenId (name)
   */
  public String toString () {
    return bind.id.toString();
  }

  /**
   * Convenience function to get the MPCObject (run-time storage or constant)
   * for this Decl. This default returns null, but there should be an override
   * in each interesting subclass
   *
   * @return an MPCObject describing the run-time "location" of
   * the thing declared by this Decl
   */
  public reclickObject getObject () {
    return getObject((reclickObject)null);
    // default; override in subclasses
  }

  /**
   * A convenience method that makes it easier to implement getObject() in
   * subclasses
   *
   * @param obj an MPCObject
   * @return the MPCObject if it is not null, otherwise
   * MPCObject.theErrorObject
   */
  protected final reclickObject getObject (reclickObject obj) {
    if (obj != null) return obj;
    return reclickObject.theErrorObject;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

