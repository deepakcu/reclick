package reclick;
import java.util.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for "resolving"
 * declarations. It is concerned with getting the correct Decl inserted into
 * any Binding's used within declarations, so that we are checking against the
 * correct Decl associated with the name. To detect bad forward references, we
 * mark each Decl as we resolve it.
 *
 * @version 1.0
 */
public class ASTResolverVisitor extends ASTNullVisitor
{
  /**
   * This is in essence a _result_ "returned" by each Resolver visit method on
   * a type. It should be set by each such method before returning, and may
   * then be inspected and used by the caller.
   */
  private Type resolvedType;

  /**
   * The obvious constructor.
   */
  public ASTResolverVisitor () { }

  // Note that Resolver visit methods should generally mark their argument
  // object as being resolved, by setting the resolved field of that object to
  // "true".

  // resolve methods for declarations

  /**
   * Resolves a DeclConst: processing bindings in the Expr in a mode expecting
   * a constant.
   *
   * @param c the DeclConst we are resolving
   */
  public void visitDeclConst (DeclConst c) {
    /* a constant must be fully resolvable now */
    Expr expr = c.expr;
    assert expr != null;
    expr.bindConstant();  
    c.resolved = true;
  }

  /**
   * Resolve a DeclField: resolve its Type.
   *
   * @param f the DeclField we are resolving
   */
  public void visitDeclField (DeclField f) {
    Type type = f.type;
    assert type != null;
    type.accept(this);
    f.type     = resolvedType;
    f.resolved = true;
  }

  /**
   * Resolves a DeclFormal: resolve its type.
   *
   * @param f the DeclFormal we are resolving
   */
  /*
  public void visitDeclFormal (DeclFormal f) {
    Type type = f.type;
    assert type != null;
    type.accept(this);
    f.type     = resolvedType;
    f.resolved = true;
  }
  */

  /**
   * Resolves a DeclProcFunc: resolve the argument Type's (inside the
   * DeclFormal objects) in an inner scope, and the result type (if any) in
   * the current scope.
   *
   * @param f the DeclProcFunc we are resolving
   */
  /*
  public void visitDeclProcFunc (DeclProcFunc f) {
    // must resolve the argument types and result type 
    Decls formals = f.formals;
    f.mySymtab = new SymbolTable(SymbolTable.current(), formals, f, true);
    f.mySymtab.enterScope();
    for (Decl d : formals) {
      assert d instanceof DeclFormal;
      try {
        d.accept(this);
      } catch (SemanticException e) {
        assert e.pos != -1;
        mpc.ShowError(e.pos, e.getMessage());
      }
    }
    f.mySymtab.exitScope();
    
    Type resultType = f.resultType;
    if (resultType != null) {
      resultType.accept(this);
      f.resultType = resolvedType;
    }
    f.resolved = true;
  }
  */

  /**
   * Resolve a DeclType: resolve its Type.
   *
   * @param t the DeclType we are resolving
   */
  public void visitDeclType (DeclType t) {
    Type type = t.type;
    assert type != null;
    type.accept(this);
    t.type     = resolvedType;
    t.resolved = true;
  }

  /**
   * Resolve a DeclVar: resolve its Type.
   *
   * @param v the DeclVar we are resolving
   */
  public void visitDeclVar (DeclVar v) {
    /* must resolve the type of the variable */
    Type type = v.type;
    assert type != null;
    type.accept(this);
    v.type     = resolvedType; 
    v.resolved = true;
  }

  // methods for resolving types

  /**
   * Resolves a TypeArray: resolve its index and element Type's.
   *
   * @param a the TypeArray we are resolving
   */
  /*
  public void visitTypeArray (TypeArray a) {
    Type indexType   = a.indexType;
    Type elementType = a.elementType;
    assert indexType != null && elementType != null;
    indexType.accept(this);
    a.indexType   = resolvedType;
    elementType.accept(this);
    a.elementType = resolvedType;
    resolvedType  = a;
  }
  */

  /**
   * Resolves a TypeId: obtains the Decl for the Binding in the TypeId and
   * insures that it is not null, that it is already resolved (i.e., not an
   * illegal forward reference), and that it names a DeclType.
   *
   * @param i the TypeId we are resolving
   */
  public void visitTypeId (TypeId i) {
    Decl d = SymbolTable.checkBindUse(i.bind);
    if (d == null)
      resolvedType = Type.theErrorType;  // some error message will already have been offered
    else if (!d.resolved)
      throw new SemanticException(i.pos, d + " is an illegal forward or cyclic reference");
    else if (!(d instanceof DeclType))
      throw new SemanticException(i.pos, d + " is not bound to a type");
    else
      resolvedType = ((DeclType)d).type;
  }

  /**
   * Resolves a TypePointer: since these allow forward reference, do NOT
   * resolve them now, but rather _check_ them later.
   *
   * @param p the TypePointer we are resolving
   */
  /*
  public void visitTypePointer (TypePointer p) {
    // pointer types allow forward references, so we do NOT resolve them now 
    resolvedType = p;
  }
  */

  /**
   * Resolves a TypePrimBool: no work for primitive Type's.
   *
   * @param p the TypePrimBool we are resolving
   */
  
  public void visitTypePrimBool (TypePrimBool p) {
    /* nothing to do here, built-in */
    resolvedType = p;
  }
  

  /**
   * Resolves a TypePrimInt: no work for primitive Type's.
   *
   * @param p the TypePrimInt we are resolving
   */
  public void visitTypePrimInt (TypePrimInt p) {
    /* nothing to do here, built-in */
    resolvedType = p;
  }

  /**
   * Resolves a TypePrimNil: no work for primitive Type's.
   *
   * @param p the TypePrimNil we are resolving
   */
  /*
  public void visitTypePrimNil (TypePrimNil p) {
    // nothing to do here, built-in 
    resolvedType = p;
  }
  */

  /**
   * Resolves a TypePrimString: no work for primitive Type's.
   *
   * @param p the TypePrimString we are resolving
   */
  public void visitTypePrimString (TypePrimString p) {
    /* nothing to do here, built-in */
    resolvedType = p;
  }

@Override
public void visitPacket(Packet p) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtFor(StmtFor s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtInsert(StmtInsert s) {
	// TODO Auto-generated method stub
	
}


@Override
public void visitStmtRemove(StmtRemove s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtSet(StmtSet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtGet(StmtGet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtEquals(StmtEquals s) {
	// TODO Auto-generated method stub
	
}

  /**
   * Resolves a TypeRange: checks its lo and hi Expr's as constants.
   *
   * @param r the TypeRange we are resolving
   */
  /*
  public void visitTypeRange (TypeRange r) {
    Expr lo = r.lo;
    Expr hi = r.hi;
    assert lo != null && hi != null;
    lo.bindConstant();
    hi.bindConstant();
    resolvedType = r;
  }
  */

  /**
   * Resolves a TypeRecord: resolves each of its DeclField's.
   *
   * @param r the TypeRecord we are resolving
   */
  /*
  public void visitTypeRecord (TypeRecord r) {
    for (DeclField df : r.fields) {
      df.accept(this);
    }
    resolvedType = r;
  }
  */
}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

