package reclick;
import java.util.*;
import java.util.regex.*;

/**
 * Representation for expressions in <i>Pascal</i>.
 *
 * An <i>expression</i> denotes a rule of computation that yields a value when
 * the expression is evaluated.  The value that is yielded depends upon the
 * values of the constants, bindings, and variables in the expression and also
 * upon the operators and functions that the expression invokes. 
 * (Pascal Report, page 165)
 *
 * @version 1.0
 */
/**
 * @author Deepak
 *
 */
public abstract class Expr extends ASTNode {

  /**
   * built-in primitive <i>Mini-Pascal</i> TRUE expression
   */
  //public static final Expr theTrueExpr;

  /**
   * built-in primitive <i>Mini-Pascal</i> FALSE expression
   */
  //public static final Expr theFalseExpr;

  /**
   * built-in primitive <i>Mini-Pascal</i> NIL expression
   */
  //public static final Expr theNilExpr;

  /**
   * Type of this expression
   */
   public Type type;

   /**
    * MPCObject for address/value of expr
    */
   public reclickObject object;

   /**
    * String of the expression
    */
   public String expString;

   
   /**
   * Indicates whether the Expr describes an rvalue (pure value) or an lvalue
   * (a left-hand side (lhs) assignable piece of storage)
   */
  public boolean rvalue = true;

  /**
   * Nominal number of registers needed to evaluate this Expr, using
   * Sethi-Ullman algorithm for counting; used to help determine best
   * evaluation order, even though register allocation is actually done a
   * different way, later
   */
  public int regCount = 0;

  /**
   * Indicates whether the Expr has had any necessary temporary successfully
   * allocated
   */
  public boolean allocated = false;

  /**
   * Creates a new Expr instance; since the class in abstract,
   * this handles just the saving of the start/end source code positions
   *
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public Expr (int left, int right) {
    super(left, right);
  }

  /**
   * Handles AST visiting work to occur before visiting every Expr (or
   * subclass) node
   *
   * @param v an ASTVisitor
   */
  public void acceptBefore (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitExprBefore(this);
  }

  /**
   * Handles AST visiting work to occur after visiting every Expr (or
   * subclass) node
   *
   * @param v an ASTVisitor
   */
  public void acceptAfter (ASTVisitor v) {
    v.visitExprAfter(this);
    super.acceptAfter(v);
  }

  
  /**
   * Allocates a temporary location for holding the result of evaluating this
   * Expr
   */
  /*
  public void allocTemp () {
    if (object == null)
      object = ObjectMemory.allocTemp(type, false);
    allocated = MPCObject.Ok(object);
  }
  */
  
  /**
   * Convenience function that builds a TupleField describing where the result
   * of evaluating this expression will be at run time.
   *
   * @return a TupleField describing whether the Expr's value
   * will be at run time (for code generation)
   */
  /*
  public TupleField tupleField () {
    assert object != null;
    return object.tupleField().addComment(comment());
  }
  */
  
  /**
   * The purpose of bindConstant is to set the object member variable to a
   * suitable MPCObject for Exprs that must be constants (e.g., right hand
   * sides of CONST declarations, lower and upper limits of range types, and
   * CASE statement values used for selecting which arm of the CASE is to be
   * used for which values).
   */
  public void bindConstant () {
    /* Note: this should not be called for sub-classes of Expr */
    /* who do not override bindConstant                        */
    assert false;
  }

  
  /**
   * This checks the Expr as a CONST
   *
   * @param vis an ASTCheckConstVisitor
   */
  public final void checkConst (ASTCheckConstVisitor vis) {
    if (type == null) {
      assert object == null;
      accept(vis);
      if (type == null)
        type = Type.theErrorType;
    }
    if (type.isErrorType())
      throw new SemanticException(pos, "Constant expression has error type");
  }
  
  /**
   * Convenience function for indicating that an rvalue is being used in a
   * context that demands writability
   *
   * @param rhs a boolean indicating whether the context demands
   * a value (rhs) or a writable variable (lhs)
   */
  public final void insistRightHandSide (boolean rhs) {
    if (!rhs)
      throw new SemanticException(pos, "Context demands a writable variable");
  }

}



  
  /**************************************/
  /**** Methods related to constants ****/
  /**************************************/

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

