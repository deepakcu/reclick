package reclick;
import java.util.*;
import java.util.regex.Pattern;

import reclick.SymbolTable.VarDesc;
import static reclick.TokenKey.*;
import static reclick.TokenOp.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for generating Tuple
 * code.
 *
 * @version 1.0
 */
public class TupleGenVisitor extends ASTNullVisitor {

  /**
   * A helper visitor that calculates register needs for expressions, in the
   * sense of the Sethi-Ulmann algorithm.
   *
   */
  //private RegNeedsVisitor rnv = new RegNeedsVisitor();
	private Tuples programHeadTuples;	
	private Tuples ioPortTuples;
	private Tuples decodeTuples;
	private Tuples executeTuples;
	private Tuples programTailTuples;
	private Tuples registerTuples;
	private Tuples wireTuples;
	private Tuples assignTuples;
	private Tuples insertTuples;
	private Tuples removeTuples;
	private Tuples shiftTuples;
	
	
	//Deepak - Need to generate reset conditions for decode statments
	//So, we need to keep track of all variables that are assigned within
	//get statements. May be this can be done more elegantly.
	//But for time being, just do a workaround
	private ArrayList<String> decodeVariables;

	/**
	* A useful boolean variable that can be used to detect if the visit
	* was called within an If statement
	*/
	private boolean insideIf;
	
	/**
  * The condition for the IF statement
  * 
  */
	
  private String condition;

  /**
  * A useful boolean variable that can be used to detect if the visit
  * was called within an If statement
  */
  private int clockCycles;

 /**
  * An instance Id for each insert module  
  */
  private int insertInstanceId;
  
 /**
  * An instance Id for each remove module  
  */
  private int removeInstanceId;
  
    
  /**
  * The max number of outputs for the scheduler within an element
  * For now, hardcore. TBFixed - Change to export parameter
  */
  private int maxSchedulePorts = 4;

  private ArrayList<TupletSet> setTuplets;
  
  private ArrayList<TupletSchedule> scheduleTuplets;
  
  private ArrayList<TupletOrdinaryVar> ordinaryVarTuplets;
  
  /**
  * Indicates whether an Expr appears bad to proceed with code generation
  * for it.
  *
  * @param e the Expr to test
  * @return whether the Expr appears bad for code generation
  */
  private boolean exprBad (Expr e) {
    return
      e == null ||
      e.type == null ||
      e.type.isErrorType() ||
      objBad(e.object);
  }

  /**
   * Indicates whether an MPCObject appears bad to proceed with code
   * generation for it.
   *
   * @param o the MPCObject to test
   * @return whether the MPCObject appears bad for code generation
   */
  private boolean objBad (reclickObject o) {
    return o == null || o == reclickObject.theErrorObject;
  }

  /**
   * Counts the number of errors encountered; can be used to suppress later
   * phases, etc.
   */
  public int numErrors = 0;

  /**
   * The obvious constructor
 * @param wireTuples 
 * @param registerTuples 
   */
  public TupleGenVisitor (Tuples programHeadTuples,	
		  				  Tuples ioPortTuples,
		  				  Tuples decodeTuples,
		  				  Tuples executeTuples, 
		  				  Tuples programTailTuples,
		  				  Tuples registerTuples, 
		  				  Tuples wireTuples,
		  				  Tuples assignTuples,
		  				  Tuples insertTuples,
		  				  Tuples removeTuples,
		  				  Tuples shiftTuples)   {
	  
	  this.programHeadTuples = programHeadTuples;
	  this.ioPortTuples 	 = ioPortTuples;
	  this.decodeTuples		 = decodeTuples;
	  this.executeTuples 	 = executeTuples;
	  this.programTailTuples = programTailTuples;
	  this.registerTuples    = registerTuples;
	  this.wireTuples 		 = wireTuples;
	  this.assignTuples 	 = assignTuples;
	  this.insertTuples 	 = insertTuples;
	  this.removeTuples 	 = removeTuples;
	  this.shiftTuples       = shiftTuples;
	  this.setTuplets	     = new ArrayList<TupletSet>();
	  this.scheduleTuplets   = new ArrayList<TupletSchedule>();
	  this.ordinaryVarTuplets = new ArrayList<TupletOrdinaryVar>();
	  
	  this.decodeVariables    = new ArrayList<String>();
	  
	  //tuples = t;
	   
  }

  
  /**
   * Simply visits each Decl in turn
   *
   * @param dd the Decls we are visiting
   */
  public void visitDecls (Decls dd) {
    for (Decl d : dd) {
      d.accept(this);
    }
  }

  /**
   * Simply visits each Expr in turn
   *
   * @param ee the Exprs we are visiting
   */
  public void visitExprs (Exprs ee) {
    for (Expr e : ee) {
      e.accept(this);
    }
  }

  /**
   * Generates code for the Program, following these steps:
   * (1) Program prolog: ProgStart, FrmSize, Local tuples (for predefined
   * scope (which probably results in no tuples) and the main routine scope);
   * (2) Code for the main routine's statements and a MainEnd tuple;
   * (3) Code for the main routine's declarations (i.e., its nested procedures
   * and functions);
   * (4) Final things, namely Str constants and the ProgEnd tuple.
   *
   * @param p the Program we are visiting
   */
  public void visitComponent (Component c) {
	    Block block = c.block;
	    c.mySymtab.enterScope();
	    //Tuples.add(Tuple.makeProgStart(c.name.toString()));
	    programHeadTuples.add(Tuple.makeProgStart(c.name.toString()));
	    clockCycles = 1; //Min shift reg depth
	    insertInstanceId = 0;
	    removeInstanceId = 0;
	    block.mySymtab.enterScope();
	    
	    int scheduleId=0;
	    /*Add input and output ports*/
	    for (Decl d : block.mySymtab.decls) {
	    	if(d instanceof DeclInput) {
	    		//Tuples.add(Tuple.makeInput(d.bind.id.toString()));
	    		ioPortTuples.add(Tuple.makeInput(d.bind.id.toString()));
	    	}
	    	else if (d instanceof DeclOutput) {
	    		//Tuples.add(Tuple.makeOutput(d.bind.id.toString()));
	    		ioPortTuples.add(Tuple.makeOutput(d.bind.id.toString()));
	    		//Assign a unique scheduling ID to each output
	    		((DeclOutput)d).scheduleId = scheduleId++;
	    	}
	    }
	    
	    block.stmts.accept(this);
	    makeExecuteTuples();
	    makeScheduleTuples(block.mySymtab.decls);
	    makeOrdinaryVarTuples();
	    genShiftTuples(block.mySymtab.decls);
	    genOutputConnections(block.mySymtab.decls);
	    
	    System.out.println("Total clock cycles is "+clockCycles);
	    c.mySymtab.exitScope();
	  }

  /**
   * Generates code for each Stmt in order
   *
   * @param ss the Stmts we are visiting
   */
  public void visitStmts (Stmts ss) {
    for (Stmt s : ss) {
      s.accept(this);
    }
  }


  // methods related to Decl classes


  /**
   * Generates code for an ExprBinary:
   * (0) insure that the Expr is ok for generating code;
   * (1) perform register needs analysis;
   * (2) generate code for subexpressions, in the recommended order;
   * (3) for DIV and MOD insert zero divide check;
   * (4) for LBRACK and DOT generate address arithmetic Tuple, for others
   * generate ordinary Tuple
   *
   * @param e the ExprBinary we are visiting
   */
  
  public void visitExprBinary (ExprBinary e) {
    Expr e1 = e.expr2;
    Expr e2 = e.expr1;
    if (e.evalExpr1First) {
      e1 = e2;
      e2 = e.expr2;
    }
    e1.accept(this);
    e2.accept(this);
    
    
  }

  /**
   * An ExprBinding does not generally need code, but if it is a
   * parameter-less call, then if needs to invoke a helper routine just as
   * visitExprCall does
   *
   * @param e the ExprBinding we are visiting
   */
  
  public void visitExprBinding (ExprBinding e) {
    if (e.isCall) {
      Decl d = e.bind.decl;
      /*
      if (d instanceof DeclSpecial) {
        genExprSpecial(e, (DeclSpecial)d, Exprs.emptyList);
        return;
      }
      genCall((DeclProcFunc)d, Exprs.emptyList, e.object);
      */
    }
  }
  

  /**
   * Given an ExprUnary operator and the target and src1 fields, constructs
   * and returns a suitable unary operation Tuple. Analogous to
   * makeBinaryTuple.
   *
   * @param op the Expr unary operator
   * @param target the target TupleField
   * @param src the src1 TupleField
   * @return the constructed Tuple
   */
  
  private Tuple makeUnaryTuple (Token op, TupleField target, TupleField src) {
    /*
	if (op == PLUS ) return Tuple.makeWAsn  (target, src);
    if (op == MINUS) return Tuple.makeWMinus(target, src);
    if (op == CARET) return Tuple.makeWAsn  (target, src);
    if (op == NOT  ) return Tuple.makeBNot  (target, src);
    if (op == COPY ) return Tuple.makeWAsn  (target, src);
    assert false;
    */
    return (Tuple)null;  // to satisfy compiler :-)
    
  }
  

  /**
   * Generates code for an ExprUnary:
   * (0) Insure that proceedings with code generation is ok
   * (1) Generate code for the subexpression;
   * (2a) For IDX_SCL, generate bounds check Tuples as needed, then the IMul;
   * (2b) For IDX_ADJ, generate a suitable WAdd Tuple;
   * (2c) For CARET, generate Tuple for dealing with the address;
   * (2d) For others, generate an ordinary unary operation Tuple.
   *
   * (EBM: Where do/should we put in null pointer dereference checks?)
   *
   * @param e the ExprUnary we are visiting
   */
  
  public void visitExprUnary (ExprUnary e) {
    e.expr.accept(this);
  }
  

  // methods for Stmt classes

  /**
   * Generate code for a StmtAssign: after checking that it is ok, perform
   * register needs analysis, then generate code for the var and assigned expr
   * in the recommended order, then use genAssign to generate actual
   * assignment Tuples (including any necessary bounds checks).
   *
   * @param s the StmtEquals we are visiting
   */
  
  public void visitStmtEquals (StmtEquals s) {
    
	//Conditional Eq statements  
	  
	//Unconditional Eq statements to be implemented as wires  
	Decl d = SymbolTable.checkBindUse(((ExprBinding)s.var).bind);
	assert d instanceof DeclVar;
	if(((DeclVar)d).isHandlerVar) { //Handler variable assignments to be made in execute logic as register assigns
		if(insideIf) {
			int word = 0; //The packet word for handler variables will be changed Default = 0
			String formatStr = s.expr.expString.replaceAll("0x", ((DeclVar)d).width+"'h");
			setTuplets.add(new TupletSet(word, condition, formatStr, 0, ((DeclVar)d).width-1));
		}
		else {
			registerTuples.add(Tuple.makeRegister(d.bind.id.toString(), Integer.toString(((DeclVar)d).width), Integer.toString(0)));
			//If statements contain hex format numbers, convert them to equivalent verilog
			String formatStr = s.expr.expString.replaceAll("0x", ((DeclVar)d).width+"'h");
			executeTuples.add(Tuple.makeRegisterAssign(0, null, formatStr, d.bind.id.toString())); //Default assign in word 0
		}
	}
	//Normal variable assignments are wire assignments (combinational logic)
	else { 
		if(insideIf) {
			String formattedExpr = s.expr.expString.replaceAll("0x", ((DeclVar)d).width+"'h");
			ordinaryVarTuplets.add(new TupletOrdinaryVar(condition, d.bind.id.string, formattedExpr));
		}
		else {
			wireTuples.add(Tuple.makeWire(d.bind.id.toString(), Integer.toString(((DeclVar)d).width), Integer.toString(0)));
			//If statements contain hex format numbers, convert them to equivalent verilog
			String formatStr = s.expr.expString.replaceAll("0x", ((DeclVar)d).width+"'h");
			assignTuples.add(Tuple.makeWireAssign(null,formatStr, d.bind.id.toString()));
			System.out.println("variable is "+d.bind.id.string+" and string is "+s.expr.expString);
		}
	}
	
	if(s.expr instanceof ExprInt)
		((DeclVar)d).value = ((ExprInt)s.expr).value;  
  }
  
  /**
   * Generate code for a StmtIf: after checking that it is ok, perform
   * 
   * @param s the StmtIf we are visiting
   */
  
  public void visitStmtIf (StmtIf s) {
    
	insideIf = true;
    condition = s.expr.expString;
    s.stmtThen.accept(this);
    if(s.stmtElse!=null) {
    	condition = null;
    	s.stmtElse.accept(this);
    }
    insideIf = false;
	//System.out.println("The expresssion string is "+s.expr.expString);  
  }
  
  
  /**
   * Generate code for a StmtAssign: after checking that it is ok, perform
   * register needs analysis, then generate code for the var and assigned expr
   * in the recommended order, then use genAssign to generate actual
   * assignment Tuples (including any necessary bounds checks).
   *
   * @param s the StmtAssign we are visiting
   */
  public void visitStmtAssign (StmtAssign s) {
	Decl assignerDecl = SymbolTable.checkBindUse(s.assigner);
	Decl assigneeDecl = SymbolTable.checkBindUse(s.assignee);
	
	assert (assignerDecl instanceof DeclPacket||assignerDecl instanceof DeclInput);
	assert (assigneeDecl instanceof DeclPacket||assigneeDecl instanceof DeclOutput);
	
	//If assigner is packet, assignee must be output port type
	if(assignerDecl instanceof DeclPacket) {
		assert assigneeDecl instanceof DeclOutput;
		String asr = assignerDecl.bind.id.toString();
		String ase = assigneeDecl.bind.id.toString();
		if(insideIf) {
			//assignTuples.add(Tuple.makeWireAssign(condition,asr, ase));
			int scheduleId = ((DeclOutput)assigneeDecl).scheduleId;
			scheduleTuplets.add(new TupletSchedule(condition,scheduleId));
			((DeclPacket)assignerDecl).outputPorts.add((DeclOutput)assigneeDecl);
		}
		else {
			((DeclPacket)assignerDecl).outputPorts.add((DeclOutput)assigneeDecl);
		}
	}
	//If assigner is input port type, assignee must be packet type
	else if(assignerDecl instanceof DeclInput) {
		assert assigneeDecl instanceof DeclPacket;
		String asr = assignerDecl.bind.id.toString();
		String ase = assigneeDecl.bind.id.toString();
		((DeclPacket)assigneeDecl).inputPort = (DeclInput)assignerDecl;
	}
  }
  
  
  /**
   * Just generate code the Stmts
   *
   * @param s the StmtCompound we are visiting
   */
  
  public void visitStmtCompound (StmtCompound s) {
    s.stmts.accept(this);
  }
  
  public void visitStmtSet(StmtSet set) {
	String exprString = set.expression.expString;
	Decl d = SymbolTable.checkBindUse(set.field);
	assert d instanceof DeclField;
	int high = ((DeclField)d).upper.value;
	int low  = ((DeclField)d).lower.value;
	int word = ((DeclField)d).word.value;
	String fName = ((DeclField)d).bind.id.toString();
	if(insideIf) {
		//For now, we will just add tuplets. Later, we will post-process tuplets 
		//to combine similar states and build tuples
		setTuplets.add(new TupletSet(word, condition, exprString, high, low));
	}
	else {
		setTuplets.add(new TupletSet(word, condition, exprString, high, low));
	}
	
	//wireTuples.add(Tuple.makeWire(fName, low, high));
}

public void visitStmtGet(StmtGet get) {
	
	//ps.print("Get statement: ");
	
	Decl d = SymbolTable.checkBindUse(get.field);
	assert d instanceof DeclField;
	int field_low  = ((DeclField)d).lower.value;
	int field_high = ((DeclField)d).upper.value;
	int word = ((DeclField)d).word.value;
	
	//Calculate the max clock cycles required. Max clock cycles decides buffer size
	if(word>=clockCycles)
		clockCycles = word;
	
	String fName = ((DeclField)d).bind.id.toString();
	
	//Avoid unconventional register names like x[15:8] and instead convert them to [7:0]
	int reg_high = field_high - field_low;
	int reg_low  = field_low - field_low;
	//Make a register for the assignee
	String targetVar = get.variable.expString;
	//Add decode tuple for the get statement
	decodeTuples.add(Tuple.makeGet(word, targetVar, field_high, field_low));
	registerTuples.add(Tuple.makeRegister(targetVar, Integer.toString(reg_high), Integer.toString(reg_low)));
	
	//Add decode variables to this array so that we can produce reset conditions later
	decodeVariables.add(targetVar);
	
}

public void visitPacket(Packet p) {
	  //ps.print("remove statement: ");
}

public void visitStmtRemove(StmtRemove rem) {
	
	//Get position info
	Decl fieldDecl = SymbolTable.checkBindUse(rem.targetField);
	assert fieldDecl instanceof DeclField;
	
	int low = ((DeclField)fieldDecl).lower.value;
	int high = ((DeclField)fieldDecl).upper.value;
	int bits = high-low+1;
	assert bits>1;
	
	int word = ((DeclField)fieldDecl).word.value;
	int pos  = high;
	int width = bits;
	
	String remove_type = null;
	String insert_type = null;
	
	if(width==64) {
		if(pos==63) { //Position = 63
			remove_type = "remove_64_start"+removeInstanceId;
		}
		else {  //Any other position
			remove_type = "remove_64_middle"+removeInstanceId;
		}
	}
	
	//Inserting any word whose length is less than 64 bits
	else {
		if(pos==63) { //Position = 63
			remove_type = "remove_start"+removeInstanceId;
		}
		else {
			/*There are 3 subcases here*/
			if(width==pos+1) {
				remove_type = "remove_middle_eq"+removeInstanceId;
			}
			if(width<pos+1) {
				remove_type = "remove_middle_lt"+removeInstanceId;
			}
			if(width>pos+1) {
				remove_type = "remove_middle_gt"+removeInstanceId;
			}
		}
	}
	
	Tuple t = Tuple.makeRemove("remove"+removeInstanceId, pos, word, bits);
	t.instanceName = "remove"+removeInstanceId;
	removeInstanceId = removeInstanceId + 1;
	removeTuples.add(t);
}

public void visitStmtInsert(StmtInsert ins) {
	//Get position info
	Decl posDecl = SymbolTable.checkBindUse(ins.pos);
	assert posDecl instanceof DeclPosition;
	int word = ((DeclPosition)posDecl).word.value;
	int pos  = ((DeclPosition)posDecl).bit.value;
	
	//Get insert value info
	Decl valueDecl = SymbolTable.checkBindUse(ins.src);
	assert valueDecl instanceof DeclVar;
	int width = ((DeclVar)valueDecl).width;
	//Make sure that width is a byte-sized
	assert width%8==0;
	int value = ((DeclVar)valueDecl).value;
	
	/*Insert cases go here (from Justin)*/
	//Inserting word whose length is 64 bits
	Tuple t=null;
	String insert_type = null;
	
	if(width==64) {
		if(pos==63) { //Position = 63
			insert_type = "insert_64_start"+insertInstanceId;
		}
		else {  //Any other position
			insert_type = "insert_64_middle"+insertInstanceId;
		}
	}
	
	//Inserting any word whose length is less than 64 bits
	else {
		if(pos==63) { //Position = 63
			insert_type = "insert_start"+insertInstanceId;
		}
		else {
			/*There are 3 subcases here*/
			if(width==pos+1) {
				insert_type = "insert_middle_eq"+insertInstanceId;
			}
			if(width<pos+1) {
				insert_type = "insert_middle_lt"+insertInstanceId;
			}
			if(width>pos+1) {
				insert_type = "insert_middle_gt"+insertInstanceId;
			}
		}
	}
	
	int newBytes = width/8;
    int insertData = value;
    int position = pos;
    int insertWord = word;
	
    t = Tuple.makeInsert(insert_type,newBytes,insertData,position, insertWord);
	t.instanceName = insert_type;
	
	insertInstanceId = insertInstanceId + 1;
	insertTuples.add(t);
}  

/**
 * Combines multiple set tuplets into a single tuple
 */
public void makeExecuteTuples() {
	ArrayList<TupletSet> caseTuplets = null;
	ArrayList<Integer>   uniqueWords = new ArrayList<Integer>();
	
	for(int k=0;k<setTuplets.size();k++) {
		
		int currWord = setTuplets.get(k).word;
		if(!uniqueWords.contains(currWord))
			uniqueWords.add(currWord);
		else {
			continue;
		}
		 
		//Classify tuplets by word 
		caseTuplets = new ArrayList<TupletSet>();
		for(int i=0;i<setTuplets.size();i++) {
			TupletSet s = setTuplets.get(i);
			if(s.word==currWord) {
				caseTuplets.add(s);
			}
		}
		Tuple t = Tuple.makeSet(caseTuplets);
		executeTuples.add(t);
	}
}

/**
 * Combines multiple schedule tuplets into a single schedule tuple
 */
public void makeScheduleTuples(Decls decls) {
	
	if(scheduleTuplets.size()==0)
		return;
	else {
		Tuple t = Tuple.makeSchedule(scheduleTuplets);
		assignTuples.add(t);
	}
	
	ArrayList<Integer> scheduleIds = new ArrayList<Integer>();
	for(Decl d: decls) {
		
		if(!(d instanceof DeclPacket))
			continue;
		
		DeclPacket packet = (DeclPacket)d;
		for(int i=0;i<packet.outputPorts.size();i++) {
			DeclOutput outPort = packet.outputPorts.get(i);
			
			assignTuples.add(Tuple.makeWireAssign(null, "out_data_channel_"+outPort.scheduleId, "out_data_"+outPort.bind.id));
			assignTuples.add(Tuple.makeWireAssign(null, "out_ctrl_channel_"+outPort.scheduleId, "out_ctrl_"+outPort.bind.id));
			assignTuples.add(Tuple.makeWireAssign(null, "out_wr_channel_"+outPort.scheduleId, "out_wr_"+outPort.bind.id));
			assignTuples.add(Tuple.makeWireAssign(null, "out_rdy_"+outPort.bind.id, "out_rdy_channel_"+outPort.scheduleId));
			scheduleIds.add(outPort.scheduleId);
			//packet.outputPorts.get(i).scheduleId
		}
		//Tie unassigned ready wires to 1'b1
		for(int i=0;i<4;i++) {
			if(!scheduleIds.contains(i)) {
				assignTuples.add(Tuple.makeWireAssign(condition, "1'b1", "out_rdy_channel_"+i));
			}
		}
	}
	
}
	

/**
 * Combines multiple ordinary variable assign tuplets into a single assign tuple
 */
public void makeOrdinaryVarTuples() {
	if(ordinaryVarTuplets.size()>0) {
		Tuple t = Tuple.makeOrdinaryVarAssign(ordinaryVarTuplets);
		assignTuples.add(t);
	}
}

/**
 * Generates Shift blocks and appropriate connections between inputs and outputs
 */
public void genShiftTuples(Decls decls) {
	//Make shift registers for moving packets within the module from inputs to outputs
	for(Decl d: decls) {
		if(!(d instanceof DeclPacket))
			continue;
		
		assert d instanceof DeclPacket;
		DeclPacket pkt = (DeclPacket)d;
		shiftTuples.add(Tuple.makeShift(pkt.inputPort,pkt.outputPorts,clockCycles));
		wireTuples.add(Tuple.makeWire("shift_data", "DATA_WIDTH-1", Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("shift_ctrl", "CTRL_WIDTH-1", Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("shift_wr", Integer.toString(0), Integer.toString(0)));
		
	}
}

public void genOutputConnections(Decls decls) {
	for(Decl d:decls ) {
		if(!(d instanceof DeclPacket))
			continue;
		
		assert d instanceof DeclPacket;
		DeclPacket pkt = (DeclPacket)d;
		
		//Generate input assignments
		assert pkt.inputPort!=null;
		assignTuples.add(Tuple.makeWireAssign(null, "in_data_"+pkt.inputPort.bind.id.string, "input_data"));
		wireTuples.add(Tuple.makeWire("input_data", "DATA_WIDTH-1", Integer.toString(0)));
		
		if(pkt.outputPorts.size()==0) {
			//If module doesnt have any output ports (and is a sink component), be always ready forever to accept packets
			assignTuples.add(Tuple.makeWireAssign(null, "1'b1", "in_rdy_"+pkt.inputPort));
		}
		else if(pkt.outputPorts.size()==1) {
			assignTuples.add(Tuple.makeWireAssign(null, "out_rdy_"+pkt.outputPorts.get(0).bind.id.string, "output_rdy"));
			assignTuples.add(Tuple.makeWireAssign(null, "output_data_out", "out_data_"+pkt.outputPorts.get(0).bind.id.string));
			assignTuples.add(Tuple.makeWireAssign(null, "output_ctrl_out", "out_ctrl_"+pkt.outputPorts.get(0).bind.id.string));
			assignTuples.add(Tuple.makeWireAssign(null, "output_wr_out", "out_wr_"+pkt.outputPorts.get(0).bind.id.string));
			assignTuples.add(Tuple.makeWireAssign(null, "out_rdy_"+pkt.outputPorts.get(0).bind.id.string, "in_rdy_"+pkt.inputPort));
		}
		else {
			assignTuples.add(Tuple.makeWireAssign(null, "in_rdy_schedule",   "output_rdy"));
			assignTuples.add(Tuple.makeWireAssign(null, "output_data_out",   "in_data_schedule"));
			assignTuples.add(Tuple.makeWireAssign(null, "output_ctrl_out",   "in_ctrl_schedule"));
			assignTuples.add(Tuple.makeWireAssign(null, "output_wr_out"  ,   "in_wr_schedule"));
			assignTuples.add(Tuple.makeWireAssign(null, "in_rdy_schedule",   "in_rdy_"+pkt.inputPort));
			
		}
		
		//Generate input connections
		assignTuples.add(Tuple.makeWireAssign(null, "in_ctrl_"+pkt.inputPort, "input_ctrl"));
		assignTuples.add(Tuple.makeWireAssign(null, "in_wr_"+pkt.inputPort, "input_wr"));
		
		wireTuples.add(Tuple.makeWire("input_ctrl", "CTRL_WIDTH-1", Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("input_wr", Integer.toString(0), Integer.toString(0)));
		
		/*These registers for the extra 1 cycle delay for input and shifted data*/
		registerTuples.add(Tuple.makeRegister("shift_input_data", "DATA_WIDTH-1", Integer.toString(0)));
		registerTuples.add(Tuple.makeRegister("shift_input_ctrl", "CTRL_WIDTH-1", Integer.toString(0)));
		registerTuples.add(Tuple.makeRegister("shift_input_wr", Integer.toString(0), Integer.toString(0)));
		
		registerTuples.add(Tuple.makeRegister("shift_shift_data", "DATA_WIDTH-1", Integer.toString(0)));
		registerTuples.add(Tuple.makeRegister("shift_shift_ctrl", "CTRL_WIDTH-1", Integer.toString(0)));
		registerTuples.add(Tuple.makeRegister("shift_shift_wr", Integer.toString(0), Integer.toString(0)));
		
	}
	
	wireTuples.add(Tuple.makeWire("output_rdy", Integer.toString(0), Integer.toString(0)));
	registerTuples.add(Tuple.makeRegister("output_data_out", "DATA_WIDTH-1", Integer.toString(0)));
	registerTuples.add(Tuple.makeRegister("output_ctrl_out", "CTRL_WIDTH-1", Integer.toString(0)));
	registerTuples.add(Tuple.makeRegister("output_wr_out", Integer.toString(0), Integer.toString(0)));

	//Make wires for the schedule ports
	for(int i=0;i<maxSchedulePorts;i++) {
		wireTuples.add(Tuple.makeWire("out_data_channel_"+i, "DATA_WIDTH-1", Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("out_ctrl_channel_"+i, "CTRL_WIDTH-1", Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("out_wr_channel_"+i, Integer.toString(0), Integer.toString(0)));
		wireTuples.add(Tuple.makeWire("out_rdy_channel"+i, Integer.toString(0), Integer.toString(0)));
	}
	
	wireTuples.add(Tuple.makeWire("in_data_schedule", "DATA_WIDTH-1", Integer.toString(0)));
	wireTuples.add(Tuple.makeWire("in_ctrl_schedule", "CTRL_WIDTH-1", Integer.toString(0)));
	wireTuples.add(Tuple.makeWire("in_wr_schedule", Integer.toString(0), Integer.toString(0)));
	wireTuples.add(Tuple.makeWire("in_rdy_schedule", Integer.toString(0), Integer.toString(0)));
	
	double channelWidth = (Math.log(maxSchedulePorts)/Math.log(2));
	wireTuples.add(Tuple.makeWire("channel_select", Integer.toString(((int)channelWidth)-1), Integer.toString(0)));
	
	//Generate reset conditions for get blocks if any (and add it part of assign for now) //TBFixed
	if(decodeVariables.size()>0) {
		decodeTuples.add(Tuple.makeGet("default",decodeVariables));
	}	
	else {
		decodeVariables.add(new String("dummy_reg"));
		decodeTuples.add(Tuple.makeGet("default",decodeVariables));
	}	
	
}


/**
 * A post processing utility method to interconnect insert, remove modules
 * @param insertTuples
 * @param removeTuples
 * @param wireTuples
 */
public void postProcessTuples(Tuples insertTuples, Tuples removeTuples, Tuples wireTuples) {
	int totalInserts = insertTuples.totalTuples();
	int totalRemovals = removeTuples.totalTuples();
	int insertIndex = 0;
	int removeIndex = insertIndex+totalInserts;
	String tupString;
	//Check if there is atleast one or more insert/remove modules
	if(totalInserts+totalRemovals>0) {
		
		ArrayList<Tuple> all = new ArrayList<Tuple>();
		all.addAll(insertTuples.tuples);
		all.addAll(removeTuples.tuples);
		
		//The last outputs are from the getset modules
		String out_data_wire_from_last = "executed_data";
		String out_ctrl_wire_from_last = "executed_ctrl";
		String out_wr_wire_from_last   = "executed_wr";
		String out_rdy_wire_from_last  = "executed_rdy";
		
		for(int curr=0;curr<all.size();curr++) {
			Tuple currTuple = all.get(curr);
			int prev = curr-1;
			int next = curr+1;
			
			String inPort = TupleTemplate.inputPorts(out_data_wire_from_last, out_ctrl_wire_from_last, out_wr_wire_from_last, out_rdy_wire_from_last);
			tupString = all.get(curr).tupString.concat(inPort);
			
			if(next<all.size()) {
				Tuple nextTuple = all.get(next);
				out_data_wire_from_last = "wire_"+currTuple.instanceName+"_"+nextTuple.instanceName+"_out_data";
				out_ctrl_wire_from_last = "wire_"+currTuple.instanceName+"_"+nextTuple.instanceName+"_out_ctrl";
				out_wr_wire_from_last   = "wire_"+currTuple.instanceName+"_"+nextTuple.instanceName+"_out_wr";
				out_rdy_wire_from_last  = "wire_"+currTuple.instanceName+"_"+nextTuple.instanceName+"_out_rdy";
				wireTuples.add(Tuple.makeWire(out_data_wire_from_last, "DATA_WIDTH-1", Integer.toString(0)));
				wireTuples.add(Tuple.makeWire(out_ctrl_wire_from_last, "CTRL_WIDTH-1", Integer.toString(0)));
				wireTuples.add(Tuple.makeWire(out_wr_wire_from_last, Integer.toString(0), Integer.toString(0)));
				wireTuples.add(Tuple.makeWire(out_rdy_wire_from_last, Integer.toString(0), Integer.toString(0)));
			}
			else { //Connect the last output port to processed packet data
				out_data_wire_from_last = "processed_pkt_out_data";
				out_ctrl_wire_from_last = "processed_pkt_out_ctrl";
				out_wr_wire_from_last   = "processed_pkt_out_wr";
				out_rdy_wire_from_last  = "processed_pkt_out_rdy";
			}
			
			String outPort = TupleTemplate.outputPorts(out_data_wire_from_last, out_ctrl_wire_from_last, out_wr_wire_from_last, out_rdy_wire_from_last);
			tupString = tupString.concat(outPort);
			
			System.out.println("Insert tuple string is "+tupString);
			//Now set the appropriate tuple (insert/remove)
			if(totalRemovals==0) {
				Tuple t = insertTuples.tuples.get(curr);
				t.tupString = tupString;
				insertTuples.tuples.set(curr, t);
			}
			else if(totalInserts==0) {
				Tuple t = removeTuples.tuples.get(curr);
				t.tupString = tupString;
				removeTuples.tuples.set(curr, t);
			}
			else {
				if(curr<totalInserts) {
					Tuple t = insertTuples.tuples.get(curr);
					t.tupString = tupString;
					insertTuples.tuples.set(curr, t);
				}
				else {
					Tuple t = removeTuples.tuples.get(curr-totalInserts);
					t.tupString = tupString;
					removeTuples.tuples.set(curr-totalInserts, t);
				}
			}
		}
	}

}

}



// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
