package reclick;
/**
 * Represents a (Mini-)Pascal primitive type.
 *
 * @version 1.0
 */
public abstract class TypePrim extends Type {

  /**
   * String name of this primitive type
   */
  public final String name;

  /**
   * Creates a new TypePrim instance given its String name
   *
   * @param n String name of this primitive type
   */
  protected TypePrim (String n) {
    super(-1, -1);
    name = n;
  }

  /**
   * Handles AST visiting work that comes before visiting a TypePrim node
   *
   * @param v an ASTVisitor
   */
  public void acceptBefore (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitTypePrimBefore(this);
  }

  /**
   * Handles AST visiting work that comes after visiting a TypePrim node
   *
   * @param v an ASTVisitor
   */
  public void acceptAfter (ASTVisitor v) {
    v.visitTypePrimAfter(this);
    super.acceptAfter(v);
  }

  /**
   * indicates whether the given constant is a legal member of this Type; in
   * this case, the only type-legal constant is NIL, which is a member of
   * every pointer type
   *
   * @param object an MPCObject for a constant value compatible with this Type
   * @return whether the constant is a value of this Type; in this case, NIL
   * is in every pointer type, so we return true
   */
  public boolean constIsInType (reclickObject object) {
    // Note: assumes we have already checked type compatibility
    return true;
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

