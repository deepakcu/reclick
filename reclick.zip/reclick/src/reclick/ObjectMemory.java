package reclick;
/**
 * ObjectMemory is the subclass of MPCObject that describes, at compile time,
 * run-time memory locations. These exist at a procedure nesting level and
 * offset at that level. The level/offset may directly contain the described
 * value, or may contain the value's address, i.e., be indirect, as noted by
 * the "indirect" property. Finally, a memory object can be a short- or
 * long-term temporary, or not a temporary at all.
 *
 * @version 1.0
 */
public final class ObjectMemory extends reclickObject {

  /**
   * the kinds of temporaries
   */
  public static enum Temp {
    NOT  (  "0"),  // NOT a temporary
    SHORT(  "1"),  // a SHORT term temporary
    LONG ("100");  // a LONG term temporary

    /**
     * a code used in printing out (for backward compatibility)
     */
    private final String code;

    /**
     * the obvious constructor
     *
     * @param code the value to use in printing out
     */
    Temp (String code) {
      this.code = code;
    }

    /**
     * override toString to use our code
     */
    public String toString () {
      return code;
    }

  }

  /**
   * offset from frame pointer at that level
   */
  int offset;

  /**
   * procedure level; 1000 has a special meaning (argument area in
   * call under construction or result after return)
   */
  int procedureLevel;

  /**
   * levels of indirection
   *
   * false means none and true means one level of indirection
   */
  boolean indirect;

  /**
   * temporary-ness of this memory object
   */
  Temp temp;

  /**
   * Creates a new ObjectMemory instance from values for its fields.
   *
   * @param type Type for the type field
   * @param temp a Temp code for the temp field
   * @param indirect a boolean for the indirect field
   * @param plevel the procedure level
   * @param offset the offset at that level
   */
  public ObjectMemory (Type type, Temp temp, boolean indirect, int plevel, int offset) {
    this.type           = type;
    this.offset         = offset;
    this.procedureLevel = plevel;
    this.indirect       = indirect;
    this.temp           = temp;
  }

  /**
   * The standard accept method for an ObjectVisitor to this class of
   * MPCObject.
   *
   * @param v the ObjectVisitor visiting this object
   */
  public void accept (ObjectVisitor v) {
    super.acceptBefore(v);
    v.visitObjectMemory(this);
    super.acceptAfter(v);
  }

  /**
   * Indicates whether two ObjectMemory objects are functionally equivalent,
   * namely that they have the same level, offset, and indirect values.
   *
   * @param o the Object to compare this against
   * @return whether o and this will refer to the same memory at run time
   */
  public boolean equals (Object o) {
    if (!(o instanceof ObjectMemory)) return false;
    ObjectMemory m = (ObjectMemory)o;
    return
      procedureLevel == m.procedureLevel &&
      offset         == m.offset &&
      indirect       == m.indirect;
  }

  /**
   * Constructs a TupleField that describes the same memory as this
   * ObjectMemory does.
   *
   * @return a TupleField describing the same memory that this ObjectMemory does
   */
  /*
  public TupleField tupleField () {
    TupleField tf;
    if (procedureLevel > 0) {
      if (indirect)
        tf = new TupleField.VarIndirect(procedureLevel, offset);
      else
        tf = new TupleField.Var        (procedureLevel, offset);
    }
    else
      tf = new TupleField.Arg(offset);
    if (temp == Temp.SHORT) tf.isTemp = true;
    return tf;
  }
  */

  /**
   * Returns a TupleField describing the address of the datum this
   * ObjectMemory describes.
   *
   * @return a TupleField describing the address of the datum this
   * ObjectMemory describes.
   */
  /*
  public TupleField tupleFieldForAddress () {
    TupleField tf;
    if (procedureLevel > 0) {
      if (indirect)
        tf = new TupleField.Var(procedureLevel, offset);
      else
        tf = new TupleField.ConstAddress(procedureLevel, offset);
    }
    else
      tf = new TupleField.ArgAddress(offset);
    if (temp == Temp.SHORT) tf.isTemp = true;
    return tf;
  }
  */

  /**
   * Allocates space for a temporary variable of the Type/indirect properties
   * given, and returns a new ObjectMemory describing that space.
   *
   * @param type the Type of the temporary to allocate
   * @param indirect indicates whether the temporary is to be a pointer to
   * space of the indicated Type or directly hold a value of the Type
   * @return a new ObjectMemory describing the allocated temporary
   */
  /*
  public static ObjectMemory allocTemp (Type type, boolean indirect) {
    assert type != null;
    if (type == null)
      return null;
    if (type.size <= 0) 
      return null;

    int amount = (indirect ? 4 : type.size);
    int offset = SymbolTable.allocVariable(null, amount, true);
    return new ObjectMemory(type, Temp.SHORT, indirect,
                            SymbolTable.current().procLevel, offset);
  }
  */

  /**
   * For a this ObjectMemory that describes a formal parameter/result, returns
   * a corresponding actual argument ObjectMemory (i.e., having procedure
   * level 0) for use in call/return code generation.
   *
   * @return an MPCObject describing an actual argument/result corresponding
   * to a formal parameter/result
   */
  /*
  public MPCObject makeArgObject () {
    return new ObjectMemory(type, Temp.NOT, indirect, 0, offset);
  }
  */

  /**
   * Returns the minimum possible value of the contents of the ObjectMemory at
   * run time, which for an ObjectMemory is the minimum value of variables of
   * its Type.
   *
   * @return an int giving the minimum possible value for variable that the
   * ObjectMemory describes
   */
  
  public int minValue () {
    return type.minValue();
  }

  /**
   * Returns the maximum possible value of the contents of the ObjectMemory at
   * run time, which for an ObjectMemory is the maximum value of variables of
   * its Type.
   *
   * @return an int giving the maximum possible value for variable that the
   * ObjectMemory describes
   */
  public int maxValue () {
    return type.maxValue();
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

