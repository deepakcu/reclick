package reclick;
/**
 * Representation for a field declaration within a record declaration.
 *
 * @version 1.0
 */
public class DeclPosition extends Decl {

  /**
   * Type of the field declaration
   */
  public Type type;
  // Note: cannot be final because we allocate DeclField objects and set their
  // type later

  /**
   * indicates the offset of this field within a record
   */
  int offset = -1;  // -1 means "not yet assigned"

  public ExprInt word;
  
  public ExprInt bit;
  
  /**
   * Creates a new DeclField instance, given its Binding (name)
   *
   * @param b the binding to this field declaration
   */
  public DeclPosition (Binding b, ExprInt w, ExprInt bi) {
    super(b, b.pos, -1);
    type  = Type.thePositionType;
    word = w;
    bit  = bi;
  }

  /**
   * Handles AST visiting for DeclField nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclPosition(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

