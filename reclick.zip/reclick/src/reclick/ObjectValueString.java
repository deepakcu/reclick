package reclick;
/**
 * An ObjectValueString describes a run-time value that is a string constant
 *
 * @author Eliot Moss
 * @version 1.0
 */
public class ObjectValueString extends reclickObject {

  /**
   * unique TokenString giving the value of the string constant
   */
  public TokenString text;

  /**
   * Creates a new ObjectValueString instance given its TokenString value
   *
   * @param t a TokenString giving the value of the string constant value
   */
  
  public ObjectValueString  (TokenString t) {
    text = t;
    type = Type.theStringType;
  }
  

  /**
   * Handles MPCObject visiting for ObjectValueString nodes
   *
   * @param v an ObjectVisitor
   */
  public void accept (ObjectVisitor v) {
    super.acceptBefore(v);
    v.visitObjectValueString(this);
    super.acceptAfter(v);
  }

  /**
   * getStringValue returns the string value of this
   * ObjectValueString.
   *
   * @return the string value of this value object
   */
  public String getStringValue () {
    return text.string;
  }

  /**
   * equals requires that the objects have the same Java class and refer to
   * the same (interned, i.e., unique) String.
   *
   * @param o the Object with which to compare
   */
  public boolean equals (Object o) {
    return (o instanceof ObjectValueString) &&
      text.string == ((ObjectValueString)o).text.string;
  }

  /**
   * Returns a TupleField.StrLabel for this string constant
   *
   * @return a TupleField.StrLabel for this string constant
   */
  /*
  public TupleField tupleField () {
    return new TupleField.StrLabel(text.number);
  }
  */
  

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

