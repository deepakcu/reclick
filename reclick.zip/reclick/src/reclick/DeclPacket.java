package reclick;
import java.util.ArrayList;

/**
 * Representation of a variable declaration.
 *
 * @version 1.0
 */
public class DeclPacket extends Decl {

  /**
   * Type of this variable
   */
  public Type type;
  // Note: cannot be final because we allocate DeclVar objects and set their
  // type later (see Decls.parseVarDecls)
  
  /**
  * The input port  
  */
  DeclInput inputPort;
  
  /**
  * The output ports to which the packet may be assigned 
  */
  ArrayList<DeclOutput> outputPorts;
  
  
  /**
   * MPCObject representing the address allocated to this variable;
   * should be an ObjectMemory.
   */
  public reclickObject address;

  /**
   * Creates a new DeclVar instance given its Binding (name)
   *
   * @param b the binding (name) of this variable declaration
   */
  public DeclPacket (Binding b) {
    super(b, b.pos, -1);
    type = Type.thePacketType;
    outputPorts = new ArrayList<DeclOutput>();
  }

  /**
   * Handles AST visiting for DeclVar nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclPacket(this);
    super.acceptAfter(v);
  }

  /**
   * Returns the MPCObject for the variables allocated address
   *
   * @return an MPCObject giving the address allocated to this
   * variable
   */
  public reclickObject getObject () {
    return getObject(address);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

