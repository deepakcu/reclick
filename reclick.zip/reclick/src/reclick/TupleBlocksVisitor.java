package reclick;
/**
 * This Tuple Visitor class helps support proc/func and basic block visiting
 * of the tuple of the program. It identifies proc/func and basic block (or
 * extended basic block) boundaries. We do not dicument the individual visit
 * methods, since the other comments generally capture their behavior; you can
 * peruse the source code to get details if you need them.
 *
 * @version 1.0
 */
public class TupleBlocksVisitor extends TupleNullVisitor {

  /**
   * Indicates whether we are trying to recognize regular or extended basic
   * block boundaries; affects the interpretation of conditional jumps (JumpT
   * and JumpF): if regular, they end a block, if extended, they do not
   */
  public final boolean extended;

  /**
   * startsBlock is a visitor result indicating that this Tuple can start a
   * new block; primarily it is Label's that start blocks, but we must also
   * include ProcLabel's and the ProgStart Tuple
   */
  public boolean startsBlock;

  /**
   * endsBlock is a visitor result indicating that this Tuple can end a block;
   * Jump, Call, JumpC (except to internal run-time routines), and JumpR end
   * all blocks; JumpT/F end regular (but not extended) blocks
   */
  public boolean endsBlock;

  /**
   * inBlock is a visitor result indicating that this Tuple can be part of a
   * block; the exceptions are StringTup and ProgEnd Tuple's, which are not
   * executable and merely include data in the program
   */
  public boolean inBlock;

  /**
   * startsProc is a visitor result indicating that this Tuple starts a new
   * procedure/function; such Tuple's are ProgStart, ProcLabel, and FrmSize
   */
  public boolean startsProc;

  /**
   * endsProc is a visitor result indicating that this Tuple ends a
   * procedure/function; such Tuple's are JumpR, Return, MainEnd, and ProgEnd
   */
  public boolean endsProc;

  /**
   * procLevel indicates the static nesting level of the current
   * procedure/function; visiting ProgStart and ProcLabel Tuple's sets it
   */
  public int procLevel;

  /**
   * frameSize indicates the size of the frame of the current
   * procedure/function, in bytes; visiting a FrmSize Tuple sets it
   */
  public int frameSize;

  /**
   * The obvious constructor, its only argument is whether we are scanning for
   * regular or extended basic blocks (true for extended)
   *
   * @param extended a boolean that, if true, indicates we are scanning for
   * extended (versus regular) basic blocks
   */
  public TupleBlocksVisitor (boolean extended) {
    this.extended = extended;
  }

  // methods for work related to every kind of Tuple

  /**
   * this method sets the visitor result instance variables to default values,
   * immediately before visiting each Tuple; this way, each Tuple's visit
   * method need only indicate its non-default properties, and we need not
   * give methods for any Tuple that behaves in the default way (many of them
   * do)
   *
   * @param t the Tuple we are about to visit (ignored)
   */
  public void visitEveryBefore (Tuple t) {
    // set defaults
    startsBlock = false;
    endsBlock   = false;
    inBlock     = true;
    startsProc  = false;
    endsProc    = false;
  }
  
  // methods for work related to each opcode
  public void visitLabel (Tuple t) {
    startsBlock = true;
  }

  public void visitJump (Tuple t) {
    endsBlock = true;
  }

  public void visitJumpT (Tuple t) {
    endsBlock = !extended;
  }

  public void visitJumpF (Tuple t) {
    endsBlock = !extended;
  }

  public void visitStringTup (Tuple t) {
    inBlock = false;
  }

  /*
  public void visitProcLabel (Tuple t) {
    startsBlock = true;
    startsProc  = true;
    procLevel   = ((TupleField.Const)t.src2).value;
  }
  */

  public void visitCall (Tuple t) {
    endsBlock = true;
  }

  /*
  public void visitJumpC (Tuple t) {
    endsBlock = (t.target instanceof TupleField.Label);
  }
  */

  public void visitReturn (Tuple t) {
    endsBlock = true;
    endsProc  = true;
  }

  public void visitJumpR (Tuple t) {
    endsBlock = true;
    endsProc  = true;
  }

  public void visitProgStart (Tuple t) {
    startsBlock = true;
    startsProc  = true;
    procLevel   = 1;
  }

  public void visitMainEnd (Tuple t) {
    endsProc = true;
  }

  public void visitProgEnd (Tuple t) {
    inBlock = false;
    endsProc  = true;
  }

  /*
  public void visitFrmSize (Tuple t) {
    startsProc  = true;
    frameSize   = ((TupleField.Const)t.target).value;
  }
  */

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:
