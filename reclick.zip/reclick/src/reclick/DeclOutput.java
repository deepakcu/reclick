package reclick;
/**
 * Representation of a variable declaration.
 *
 * @version 1.0
 */
public class DeclOutput extends Decl {

  /**
   * Type of this variable
   */
  public Type type;
  // Note: cannot be final because we allocate DeclVar objects and set their
  // type later (see Decls.parseVarDecls)

  
  
  /**
  * A unique number used to identify this port (used for scheduling purposes) 
  */
  public int scheduleId;
  
  
  /**
   * MPCObject representing the address allocated to this variable;
   * should be an ObjectMemory.
   */
  public reclickObject address;

  /**
   * Creates a new DeclVar instance given its Binding (name)
   *
   * @param b the binding (name) of this variable declaration
   */
  public DeclOutput (Binding b) {
    super(b, b.pos, -1);
    type = Type.theOutputType;
  }

  /**
   * Handles AST visiting for DeclVar nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclOutput(this);
    super.acceptAfter(v);
  }

  /**
   * Returns the MPCObject for the variables allocated address
   *
   * @return an MPCObject giving the address allocated to this
   * variable
   */
  public reclickObject getObject () {
    return getObject(address);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

