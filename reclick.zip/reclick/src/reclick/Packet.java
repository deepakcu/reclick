package reclick;
import java.util.*;

/**
 * A Packet is indicated by a name of port and an index of the port Eg: in[0], out[1] etc.
 *
 * @see Packet
 * @author Deepak Unnikrishnan
 * @version 1.0
 */
public final class Packet extends ASTNode {

  /*name for the packet's port*/
  public final Binding name;

  /**
   * index of the port
   */
  public final Expr index;

  /**
   * the label, in the sense of an assembly language code label, for the (code
   * we generate for the) Stmt of this case of the CASE statement.
   */
  //public TupleField.Label codeLabel;

  /**
   * Creates a new CaseElement instance given the component
   * CaseLabelList and Stmt and the source position (start, end) of the
   * construct
   *
   * @param l a CaseLabelList containing the values that select this case
   * @param st a Stmt giving the actions for this case
   * @param left an int giving the starting source position
   * @param right an int giving the ending source position
   */
  public Packet (Binding b, Expr e, int left, int right) {
    super(left, right);
    name = b;
    index = e;
  }

  /**
   * Handles AST visiting for CaseElement nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitPacket(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

