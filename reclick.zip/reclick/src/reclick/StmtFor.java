package reclick;
/**
 * Representation of a FOR statement.
 *
 * <i>
 * The for statement indicates that a statement is to be repeatedly executed
 * while a progression of values is assigned to a variable that is called the
 * control variable of the for statement.
 * </i>
 *
 * Example:
 * <pre>
 *   for I := 1 to 63 do
 *      if I GrayScale[I] > 0.5 then write ('*')
 *      else write (' ')
 * </pre>
 *
 * @version 1.0
 */
public class StmtFor extends Stmt {

  /**
   * Binding (name) of the control variable
   */
  public final Binding name;

  /**
   * the initialization Expr
   */
  public Expr init;
  

  /**
   * the initialization Expr
   */
  public Expr condition;
  
  /**
   * loop Expr
   */
  public Expr loop;

  /**
   * Stmt to execute
   */
  public final Stmt stmt;

  /**
   * MPCObject describing the limit of the loop
   */
  public reclickObject limitObj;

  /**
   * Two temporary MPCObject's used in code generation
   */
  public reclickObject tempObj1;
  public reclickObject tempObj2;

  /**
   * Creates a new StmtFor instance given the Binding (name) of
   * its control variable, the init Expr, direction of progression (up/down),
   * the final/limit Expr, the Stmt for the loop body, and the source
   * (start/end) position
   *
   * @param b     Binding (name) of the control variable
   * @param i     initialization Expr
   * @param up    direction of progression
   * @param t     final Expr
   * @param st    Stmt to execute
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public StmtFor (Binding b, Expr i, Expr c, Expr t, Stmt st, int left, int right) {
    super(left, right);
    name   = b;
    init   = i;
    condition = c;
    loop   = t;
    stmt   = st;
  }

  /**
   * Handles AST visiting of StmtFor nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitStmtFor(this);
    super.acceptAfter(v);
  }

  /**
   * If false, suppresses code generation
   */
  public boolean ok = false;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

