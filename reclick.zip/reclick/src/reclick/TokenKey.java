package reclick;
/**
 * TokenKey is used to represent a <b>keyword</b> in the <i>Pascal</i>
 * language as defined by the <i>Pascal User Manual and Report</i>.
 *
 * @version 1.0
 */
public enum TokenKey implements Token {

	COMPONENT   ("COMPONENT"   , sym.COMPONENT),
	SET		    ("SET"   	   , sym.SET	  ),
	GET		    ("GET"   	   , sym.GET	  ),
	INSERT		("INSERT"  	   , sym.INSERT	  ),
	AFTER		("AFTER"   	   , sym.AFTER	  ),
	BEFORE		("BEFORE"      , sym.BEFORE	  ),
	OF		    ("OF"	  	   , sym.OF	  	  ),
	IF		    ("IF"   	   , sym.IF	 	  ),
	ELSE		("ELSE"   	   , sym.ELSE	  ),
	TO		    ("TO"   	   , sym.TO	  	  ),
	FROM		("FROM"   	   , sym.FROM	  ),
	FOR		    ("FOR"   	   , sym.FOR	  ),
	REMOVE		("REMOVE"      , sym.REMOVE	  ),
	INT			("INT"     	   , sym.INT  	  ),
	INPUT		("INPUT" 	   , sym.INPUT   ),
	OUTPUT		("OUTPUT" 	   , sym.OUTPUT  ),
	FIELD		("FIELD"	   , sym.FIELD	  ), 
	WORD		("WORD"		   , sym.WORD	  ),
	PACKET		("PACKET"	   , sym.PACKET	  ),
	ASSIGN      ("ASSIGN"      , sym.ASSIGN   ),
	CONCAT		("CONCAT"	   , sym.CONCAT   ),
	LOOKUP	    ("LOOKUP"	   , sym.LOOKUP	  ),
	POSITION	("POSITION"	   , sym.POSITION ),
	AT			("AT"		   , sym.AT		  ),
	HANDLER		("HANDLER"	   , sym.HANDLER  );
	
  /**
   * Constructs a TokenKey instance with the given string as its canonical
   * input form (lower case) and the given code as its Token code.
   *
   * @param string the String form of the keyword
   * @param code   the int Token code of the keyword
   */
  TokenKey (String string, int code) {
    this.string = string;
    this.code   = code;
  }

  /**
   * the string defining this keyword
   */
  public final String string;   

  /**
   * the Token's unique token code
   */
  private final int code;

  /**
   * return the Token's unique token code
   *
   * @return the Token's unique token code
   */
  public int code () {
    return code;
  }

  // There is no "get" operation, since we place all keywords in the TokenId
  // map at class initialization time

  /**
   * provides a "hook" for a visitor to do something before each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptBefore (TokenVisitor v) {
    v.visitEveryBefore(this);
  }

  /**
   * Supports visiting objects in the Token class hierarchy; calls
   * acceptBefore and acceptAfter hooks as well as a visit method particular
   * to this class.
   *
   * @param v the TokenVisitor to call, indicating this object is a TokenKey
   */
  public void accept (TokenVisitor v) {
    this.acceptBefore(v);
    v.visitTokenKey(this);
    this.acceptAfter(v);
  }

  /**
   * provides a "hook" for a visitor to do something after each Token
   *
   * @param v the TokenVisitor whose method we will invoke
   */
  public void acceptAfter (TokenVisitor v) {
    v.visitEveryAfter(this);
  }

  /**
   * String representation of this TokenKey.
   *
   * @return String defining this TokenKey
   */
  public String toString () {
    return string;
  }

  /**
   * String representation of this TokenKey.
   *
   * @return String defining this TokenKey; same as toString()
   */
  public String toPrettyString () {
    return toString();
  }

  /**
   * Enters all keywords into the table given; should be called only once.
   *
   * @param map the table into which to enter the keywords
   * @see TokenId which provides the table and calls this
   */
  protected static void EnterKeywords (StringMap<Token> map) {
    for (TokenKey tk : TokenKey.values()) {
      map.put(tk.string.toLowerCase(), tk); //Deepak lowercase
    }
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

