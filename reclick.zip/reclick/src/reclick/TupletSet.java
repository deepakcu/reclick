package reclick;

public class TupletSet {
	
	int word;
	String condition;
	String exprString;
	int low;
	int high;
	int max;
	int min;
	
	TupletSet(int word, String condition, String exprString, int high, int low) {
		this.word = word;
		this.condition = condition;
		this.exprString = exprString;
		this.low = low;
		this.high = high;
		this.max = 63; //Data word max bit
		this.min = 0;  //Data word min bit
	}
}
