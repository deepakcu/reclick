package reclick;
import java.util.*;

/**
 * This defines an AST (Abstract Syntax Tree) visitor for checking uses of
 * identifiers. The protocol is to set rValue to indicate whether the context
 * of use is as an rvalue or lvalue, and bind to indicate the name, and then
 * to visit the declaration associated with the name. The visit methods check
 * correctness of the use according to rvalue/lvalue context and fill in the
 * type of bind.
 *
 * @version 1.0
 */
public class ASTCheckUseVisitor extends ASTNullVisitor
{

  /**
   * Remembers the ASTCheckVisitor with which we are working, so we can access
   * its instance variables.
   */
  private final ASTCheckVisitor checkVis;

  /**
   * The obvious constructor, given that we wish to remember the
   * ASTCheckVisitor with which we are working.
   *
   * @param vis the ASTCheckVisitor with which we are working
   */
  public ASTCheckUseVisitor (ASTCheckVisitor vis) {
    checkVis = vis;
  }

  /**
   * Indicates whether the context of use is as an "rvalue", i.e., names a
   * value, or as an "lvalue", i.e., namely a settable variable.
   *
   * This is an INPUT to the visit methods.
   */
  public boolean rValue;

  /**
   * Indicates the name (ExprBinding) being checked.
   *
   * This is an INPUT to the visit methods.
   */
  public ExprBinding bind;

  // methods related to Decl classes

  /**
   * This method insures that our use checking is not attempted on
   * inappropriate kinds of things.
   *
   * @param d a Decl being visited
   */
  public void visitDecl (Decl d) {
    throw new SemanticException(bind.pos, "ASTCheckUseVisitor not implemented for this kind of declaration");
  }

  /**
   * Handles use checking of names bounds to constants.
   *
   * @param d the DeclConst for this binding
   */
  public void visitDeclConst (DeclConst d) {
    bind.type = d.expr.type;
    bind.insistRightHandSide(rValue);
  }

  /**
   * It seems impossible to visit a field declaration this way, so we simply assert false.
   *
   * @param d a DeclField we are trying to visit
   */
  public void visitDeclField (DeclField d) {
    assert false;
  }

  /**
   * Formals are read/write, so this is ok.
   *
   * @param d the DeclFormal bound to this name
   */
  /*
  public void visitDeclFormal (DeclFormal d) {
    bind.type = d.type;
  }
  */

  /**
   * This is a procedure/function name appearing without arguments, so we
   * check it as a call with an empty expression list. It had better be an
   * rvalue context (you can't assign to the result of calling a
   * function). Note that the wierd case in Pascal of assigning to the name of
   * the current function as a way of determining the result to return must be
   * handled specially elsewhere (in checking assignment statements).
   *
   * @param d the DeclProcFunc bound to this name
   */
  /*
  public void visitDeclProcFunc (DeclProcFunc d) {
    assert rValue;
    bind.checkArguments(checkVis, bind.bind, Exprs.emptyList, true);
  }
  */

  /**
   * These should never be referenced.
   *
   * @param d the DeclProgram bound to the name
   */
  public void visitDeclComponent (DeclComponent d) {
    throw new SemanticException(bind.pos, "Meaningless to reference program identifier");
  }

  /**
   * Special routines should never be referenced except in calls.
   *
   * @param d the DeclSpecial bound to the name
   */
  /*
  public void visitDeclSpecial (DeclSpecial d) {
    throw new SemanticException(bind.pos, "Inappropriate call of special function or procedure");
  }
  */

  /**
   * A type cannot be used as a value.
   *
   * @param d the DeclType bound to this name
   */
  public void visitDeclType (DeclType d) {
    throw new SemanticException(bind.pos, "Attempt to use a type as an expression");
  }

  /**
   * Variables are fine as rvalues and lvalues.
   *
   * @param d the DeclVar bound to this name
   */
  public void visitDeclVar (DeclVar d) {
    bind.type = d.type;
  }

@Override
public void visitPacket(Packet p) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtFor(StmtFor s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtInsert(StmtInsert s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtRemove(StmtRemove s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtSet(StmtSet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtGet(StmtGet s) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtEquals(StmtEquals s) {
	// TODO Auto-generated method stub
	
}

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

