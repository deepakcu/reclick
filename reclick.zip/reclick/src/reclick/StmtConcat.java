package reclick;
import java.util.ArrayList;
/**
 * Representation of a Remove statement.
 *
 * <i>
 * The InsertAfter statement is used to insert a field after a particular
 * field of the packet.
 * </i>
 *
 * Example:
 * 
 * REMOVE binding:b FROM Packet:p
 *
 * @version 1.0
 */
public class StmtConcat extends Stmt {

  /**
   * targetField (The field to be removed)
   *    */
  public final Expr target;
  
  public final ArrayList<Decl> concatStrings;
  
  /**
   * Two temporary MPCObject's used in code generation
   */
  public reclickObject tempObj1;
  public reclickObject tempObj2;

  /**
   * Creates a new StmtInsertBefore instance given the Binding    * @param b     Binding (name) of the control variable
   * 
   * @param left  starting position in program text
   * @param right ending position in program text
   */
  public StmtConcat (Expr tgt, ArrayList<Decl> vars, int left, int right) {
    super(left, right);
    
    target = tgt;
    concatStrings = vars;
    //packet = pkt;    
  }

  /**
   * Handles AST visiting of StmtFor nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitStmtConcat(this);
    
    super.acceptAfter(v);
  }

  /**
   * If false, suppresses code generation
   */
  public boolean ok = false;

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

