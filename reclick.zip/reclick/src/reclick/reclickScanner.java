package reclick;
import java.io.*;
import java.util.*;
import java_cup.runtime.*;

/**
 * Scans an input character stream into Pascal tokens. Its primary external
 * interface consists of its constructor and the next_token() method (expected
 * by the java_cup Parser). We implement it on top of ScanInStream, which adds
 * line/column position information to an ordinary Java InputStream.
 */
public class reclickScanner implements java_cup.runtime.Scanner {

  /**
   * Character classes, i.e., equivalence classes of input letters
   */
  private static enum CharClass {
    EOF,    // end of file
    SPC,    // white space
    LET,    // letters A-Z a-z
    DIG,    // digits 0-9
    OP,     // single character operators
    LC,     // left  curly bracket {
    RC,     // right curly bracket }
    EQ,     // equals =
    LT,     // less    than <
    GT,     // greater than >
    COL,    // colon :
    OTH,    // other non-bad characters
    BAD,    // illegal characters
    DOT,    // dot .
    QUO,    // (single) quote '
    NL,     // newline
    AST,    // asterisk *
    LP,     // left  paren (
    RP;     // right paren )
  }

  /**
   * table that maps input characters to their classes
   */
  private static CharClass classTable[] = new CharClass[257];

  /**
   * Really just a record/struct, indicating that a range of character values
   * (from lo through hi, inclusive) belong to the indicated character class
   * (and are treated equivalently for purposes of scanning).
   */
  private static class ClassRange {

    /**
     * The CharClass to associate with these input characters
     */
    CharClass charClass;

    /**
     * The low end value of the range of characters having this CharClass
     */
    char lo;

    /**
     * The high end value of the range of characters having this CharClass
     */
    char hi;

    /**
     * The obvious constructor
     *
     * @param charClass the CharClass for this ClassRange
     * @param lo the low end of the character values for this ClassRange
     * @param hi the high end of the character values for this ClassRange
     */
    ClassRange(CharClass charClass, char lo, char hi) {
      this.charClass = charClass;
      this.lo        = lo;
      this.hi        = hi;
    }
  }

  /**
   * data used for initializing classTable
   */
  private static final ClassRange classRanges[] = {
    // - each line gives a ClassRange
    // - we guarantee that the entries are processed in order, so an
    //   earlier entry can give defaults and a later one override
    new ClassRange(CharClass.BAD, '\000', '\u0100'),  // init all to the default: BAD
    new ClassRange(CharClass.OTH, '\040', '\176'),  // default for printable range is OTH
    new ClassRange(CharClass.SPC, '\011', '\012'),  // tab, nl
    new ClassRange(CharClass.SPC, '\015', '\015'),  // cr
    new ClassRange(CharClass.SPC, '\040', '\040'),  // space
    new ClassRange(CharClass.LET, '\101', '\132'),  // A-Z
    new ClassRange(CharClass.LET, '\141', '\172'),  // a-z
    new ClassRange(CharClass.DIG, '\060', '\071'),  // 0-9
    new ClassRange(CharClass.OP , '\050', '\051'),  // ( )
    new ClassRange(CharClass.OP , '\054', '\054'),  // ,
    new ClassRange(CharClass.OP , '\056', '\056'),  // .
    new ClassRange(CharClass.OP , '\073', '\073'),  // ;
    new ClassRange(CharClass.COL, '\072', '\072'),  // :
    new ClassRange(CharClass.LT , '\074', '\074'),  // <
    new ClassRange(CharClass.EQ , '\075', '\075'),  // =
    new ClassRange(CharClass.GT , '\076', '\076'),  // >
    new ClassRange(CharClass.LC , '\173', '\173'),  // {
    new ClassRange(CharClass.RC , '\175', '\175'),  // }
    new ClassRange(CharClass.NL , '\012', '\012'),  // nl
    new ClassRange(CharClass.NL , '\015', '\015'),  // cr
    new ClassRange(CharClass.QUO, '\047', '\047'),  // '
    new ClassRange(CharClass.LP , '\050', '\050'),  // (
    new ClassRange(CharClass.RP , '\051', '\051'),  // )
    new ClassRange(CharClass.AST, '\052', '\052'),  // *
    new ClassRange(CharClass.OP , '\053', '\055'),  // + , -
    new ClassRange(CharClass.DOT, '\056', '\056'),  // .
    new ClassRange(CharClass.OP , '\133', '\133'),  // [
    new ClassRange(CharClass.OP , '\135', '\136'),  // ] ^
    new ClassRange(CharClass.EOF, '\u0100', '\u0100')}; // EOF is 256 (only)

  /**
   * routine to initialize the characters class table given the data
   * immediately above here
   */
  private static void initClassTable () {
    // initialize classTable
    for (ClassRange cr : classRanges) {
      Arrays.fill(classTable, (int)(cr.lo), (int)(cr.hi)+1, cr.charClass);
    }
  }

  /**
   * codes for scanner actions, one for each accepting state that may return a
   * token
   */
  private static enum Action {
    NONE,       // no action
    ID,         // identifier
    INT,        // integer literal
    OP,         // operator
    STR,        // string literal
    LP,         // left parenthesis
    EOF;        // end of file
  }

  /**
   * the scanner is written as a finite state machine; this nested (but not
   * "inner") class defines the information we associate with each state
   */
  private static enum State {

    SBeg(Action.NONE, false), // starting state
    SId (Action.ID  , true ), // in an identifier
    SNum(Action.INT , true ), // in an integer literal
    SOp (Action.OP  , true ), // an operator
    SLt (Action.OP  , true ), // saw a <
    SGC (Action.OP  , true ), // saw a > or :
    SCom(Action.NONE, false), // in a comment
    SDot(Action.OP  , true ), // saw a .
    SQuo(Action.NONE, false), // string start '
    SStr(Action.NONE, true ), // in a string with chars
    SSQ (Action.STR , false), // in a string, see a '
    SQQ (Action.NONE, false), // string start, then '
    SLP (Action.LP  , false), // saw a (
    SCA (Action.NONE, false), // saw a * in a comment
    SErr(Action.NONE, false), // the error state
    SEOF(Action.EOF , false); // saw EOF

    /**
     * action, if any, associated with this state; NONE means it has no action
     * (and thus is not an accepting state)
     */
    public final Action action;         // action

    /**
     * should transitions into this state keep the input character in the
     * token buffer?
     */
    public final boolean keeps;        // should input character be kept?

    /**
     * transition array for this state: the next State to which we should go
     * for each class of input characters
     */
    private final EnumMap<CharClass,State> transitions;  // transition map

    /**
     * constructor to create State with given action and input keeping
     * behavior; we use other methods to set up transitions after creating
     * State objects
     *
     * @param action the action for this state
     * @param keeps whether or not to keep input characters causing
     * transitions into this State
     */
    State (Action action, boolean keeps) {
      this.action      = action;
      this.keeps       = keeps;
      this.transitions = new EnumMap<CharClass,State>(CharClass.class); // transitions NOT set up yet
    }
      
    /**
     * Sets the default target State for transitions out of this State.  In
     * general, this must be done AFTER all the State objects are created.
     * The default default is SErr, indicating no (legal) transition.  Note
     * that transitions for BAD and EOF are _ALWAYS_ to SErr, unless set
     * individually.
     *
     * @param state the default target State for transitions out of this State
     */
    public void setDefault (State state) {
      for (CharClass cc : CharClass.values()) {
        transitions.put(cc, state);
      }
      transitions.put(CharClass.BAD, State.SErr);
      transitions.put(CharClass.EOF, State.SErr);
    }

    /**
     * Sets a particular transition; generally done after setDefault.
     *
     * @param charClass the character class causing the transition
     * @param next      the target State for the transition
     */
    public void setTransition (CharClass charClass, State next) {
      transitions.put(charClass, next);
    }

    /**
     * Looks up the target State from this State, given an input character
     * class.
     *
     * @param charClass the input character class for which we wish to make a
     * transition
     */
    public State move (CharClass charClass) {
      return transitions.get(charClass);
    }
  }

  /**
   * This static initializer sets up the State transitions, after the above
   * enums are initialized.
   */
  private static void initStates () {
    // set the default default
    for (State state : State.values()) {
      state.setDefault(State.SErr);
    }
    // set default transition, if not SErr
    State.SCom.setDefault(State.SCom);
    State.SCA .setDefault(State.SCom);
    State.SQuo.setDefault(State.SStr);
    State.SStr.setDefault(State.SStr);

    // set individual, non-default, transitions for each state; * for changes
    State.SBeg.setTransition(CharClass.EOF, State.SEOF); //  start: end of file
    State.SBeg.setTransition(CharClass.SPC, State.SBeg); //  start: white space
    State.SBeg.setTransition(CharClass.NL , State.SBeg); // *start: newline
    State.SBeg.setTransition(CharClass.LET, State.SId ); //  start: letter => get identifier
    State.SBeg.setTransition(CharClass.DIG, State.SNum); //  start: digit => get integer
    State.SBeg.setTransition(CharClass.OP , State.SOp ); //  start: single character operator
    State.SBeg.setTransition(CharClass.EQ , State.SOp ); //  start: single character operator
    State.SBeg.setTransition(CharClass.RP , State.SOp ); // *start: single character operator (
    State.SBeg.setTransition(CharClass.AST, State.SOp ); // *start: single character operator *
    State.SBeg.setTransition(CharClass.LT , State.SLt ); //  start: single/double character operator
    State.SBeg.setTransition(CharClass.GT , State.SGC ); //  start: single/double character operator
    State.SBeg.setTransition(CharClass.COL, State.SGC ); //  start: single/double character operator
    State.SBeg.setTransition(CharClass.DOT, State.SDot); // *start: single/double character operator
    State.SBeg.setTransition(CharClass.QUO, State.SQuo); // *start: quote => string
    State.SBeg.setTransition(CharClass.LC , State.SCom); //  start: left curly bracket => comment
    State.SBeg.setTransition(CharClass.LP , State.SLP ); // *start: left paren => may start comment

    State.SId .setTransition(CharClass.LET, State.SId ); //  identifiers continue with LET or DIG
    State.SId .setTransition(CharClass.DIG, State.SId );

    State.SNum.setTransition(CharClass.DIG, State.SNum); //  integer literals continue with DIG

    // SOp has no outgoing transitions

    State.SLt .setTransition(CharClass.EQ , State.SOp ); //  double char operator <=
    State.SLt .setTransition(CharClass.GT , State.SOp ); //  double char operator <>

    State.SGC .setTransition(CharClass.EQ , State.SOp ); //  double char operators >= and :=

    State.SDot.setTransition(CharClass.DOT, State.SOp ); // *double char operator ..

    State.SQuo.setTransition(CharClass.QUO, State.SQQ ); // *quote right after quote: "special case"
    State.SQuo.setTransition(CharClass.NL , State.SErr); // *newline illegal in strings
                                      //  most transitions go to SStr

    State.SStr.setTransition(CharClass.QUO, State.SSQ ); // *see a quote when in a string
    State.SStr.setTransition(CharClass.NL , State.SErr); // *newline illegal in strings
                                      //  most transitions go to SStr

    State.SSQ .setTransition(CharClass.QUO, State.SStr); // *a quoted quote; otherwise string is ended

    State.SQQ .setTransition(CharClass.QUO, State.SStr); // *quoted quote at start of string
                                      //  differs from above since is NOT accepting

    State.SCom.setTransition(CharClass.RC , State.SBeg); //  finish a comment
    State.SCom.setTransition(CharClass.AST, State.SCA ); // *asterisk => may finish a comment
                                      //  most things continue it; see defaults

    State.SLP .setTransition(CharClass.AST, State.SCom); // *start a comment with (*

    State.SCA .setTransition(CharClass.AST, State.SCA ); // *another asterisk => may end comment next time
    State.SCA .setTransition(CharClass.RC , State.SBeg); // *end comment
    State.SCA .setTransition(CharClass.RP , State.SBeg); // *end comment
                                      //  most things continue it; see defaults

    // SEOF has no outgoing transitions

  }

  /**
   * The ScanInStream that we are scanning
   */
  private ScanInStream scanStr; // the customized input stream abstraction

  /**
   * A PrintStream to which we log all tokens created (but if tokstr is null,
   * we silently omit such logging)
   */
  private PrintStream  tokStr;  // output token logging stream (ok if null)

  /**
   * A PrintStream on which we can emit any error messages
   */
  private PrintStream  errStr;  // stream for error output

  /**
   * A buffer in which we accumulate characters for the current token
   */
  private StringBuffer tokBuf;  // buffer for building up a token

  /**
   * This clears the token buffer and alerts our ScanInStream that we are
   * looking for a new token. We should call it right before starting to scan
   * each token.
   */
  private void reset () {
    tokBuf.setLength(0);
    scanStr.reset();
  }

  /**
   * Adds an input character to the token buffer, first insuring that the
   * buffer can hold it (i.e., by growing the buffer if need be).
   *
   * @param newChar the character (as a Java short) that we wish to add
   */
  private void append (short newChar) {
    int oldLen = tokBuf.length();
    tokBuf.setLength(oldLen+1);
    tokBuf.setCharAt(oldLen, (char)newChar);
    scanStr.inToken();
  }

  /**
   * Builds a new scanner object given input, token output, and error output streams.
   *
   * @param inStream input stream to scan
   * @param tokStream stream on which to log created tokens (null means don't log)
   * @param errStream stream for any error messages
   */
  public reclickScanner (InputStream inStream,
                     PrintStream tokStream,
                     PrintStream errStream) {
    // set up stream instance variables
    scanStr = new ScanInStream(inStream);
    tokStr  = tokStream;
    errStr  = errStream;

    // initialize the token buffer
    tokBuf = new StringBuffer();

    // get the first character into the character scanner
    scanStr.advance();

    // get first token
    // next_token();
  }

  /**
   * Method that does the actual work of running the state machine to scan a
   * token; its name and interface are specified by java_cup.
   */
  public Symbol next_token () {
    // Start in SBeg and reset the token buffer and ScanInStream for start of token
    State currState = State.SBeg;
    reset();

    // run the state machine
    while (true) {
      // get the current input character and its class
      short inChar = scanStr.inChar();
      CharClass currClass = classTable[inChar];

      // check for a BAD input character
      if (currClass == CharClass.BAD) {
        System.err.println("========================================");
        reclick.ShowError(scanStr.getEndPos(), "Illegal character: " + charDescription(inChar));
        markError("ignoring bad character");
        System.err.println("========================================");
        System.err.flush();
      }
      else {
        // have a good character, but do we have a transition?
        State next = currState.move(currClass);
        if (next == State.SErr) {
          // if no transition, either accepting or an error
          Action action = currState.action;
          if (action != Action.NONE) {
            // There is an action, so this is an accepting state;
            // t is to receive the Token for what we just scanned
            //Token t = null; //Deepak: commented
            switch (action) {
            case ID:
              // convert to lower case
              for (int i = 0, n = tokBuf.length(); i < n; ++i) {
                tokBuf.setCharAt(i, Character.toLowerCase(tokBuf.charAt(i)));
              }
              // TokenId.get can also return keywords: TokenId has TokenKey
              // insert them all into the identifier table at class
              // initialization time.
              //t = TokenId.get(tokBuf);
              break;
            case INT:
              //t = TokenInt.get(tokBuf);
              break;
            case OP:
              //t = TokenOp.get(tokBuf);
              break;
            case EOF:
              //t = Token.EOF;
              break;
            case STR:
              //t = TokenString.get(tokBuf);
              break;
            case LP:
              // '(' is not in the buffer because it can start a comment
              //t = TokenOp.LPAREN;
              break;
            default:
              reclick.ShowError(scanStr.getEndPos(),
                            "Unexpected action code value: " + action);
              markError();
              throw new AssertionError("Unhandled scanner action code: scanner is broken");
            }
            // log the token we just built
            if (tokStr != null) {
              //tokStr.println(t.toPrettyString()); //Deepak commented

            }
            // return a suitable new Symbol object to Parser (java_cup conforming)
            //return new Symbol(t.code(), getPos(), getEndPos(), t); //Deepak commented
          }
          // non-accepting state: complain and restart
          reclick.ShowError(scanStr.getEndPos(), 
                        "Unexpected character: " + charDescription(inChar));
          markError("resetting to scan a new token");
          reset();
          currState = State.SBeg;
        }
        else {
          // have a transition: make it, and append input if we should
          currState = next;
          if (currState.keeps) {
            append(inChar);
          }
        }
      }
      // if we do not return, go to the next character in the input
      scanStr.advance();
    }
    // never get here
  }

  /**
   * Offers a description of an input character given its code as a short
   *
   * @param ch a short giving the code of the charcter to describe
   * @return a String describing that character code
   */
  private String charDescription (short ch) {
    String numericDesc = String.format("code = %d = %03o = 0x%04x", ch, ch, ch);
    String desc = null;
    if (ch  > 040 && ch < 177) {
      desc = "'" + (char)ch + "'";
    } else {
      switch (ch) {
      case  0010: desc = "backspace"; break;
      case  0011: desc = "tab"      ; break;
      case  0012: desc = "newline"  ; break;
      case  0015: desc = "return"   ; break;
      case  0040: desc = "space"    ; break;
      case  0177: desc = "delete"   ; break;
      case 0x100: desc = "EOF"      ; break;
      }
    }
    return desc == null ? numericDesc : desc + " (" + numericDesc + ")";
  }

  /**
   * Returns the input position of the start of the token most recently scanned.
   * @see InputPos
   */
  public int getPos () {
    return scanStr.getPos();
  }

  /**
   * Returns the input position of the end of the token most recently scanned.
   * @see InputPos
   */
  public int getEndPos () {
    return scanStr.getEndPos();
  }

  /**
   * Marks a scanning error, with no extra message;
   * @see #markError(int, String)
   */
  public void markError () {
    markError(InputPos.columnOf(scanStr.getEndPos()), null);
  }

  /**
   * Marks a scanning error, with an extra message;
   * @see #markError(int, String)
   *
   * @param more the extra message to print
   */
  public void markError (String more) {
    markError(InputPos.columnOf(scanStr.getEndPos()), more);
  }

  /**
   * Marks a scanning error in the current input line, given a column position
   * and an extra message. Does this to the error stream output, and marks by
   * writing dashes and then a caret in the position being marked. The first
   * column is number 1.
   *
   * @param col the column number to mark
   * @param more the additional String message to print
   */
  public void markError (int col, String more) {
    errStr.println(scanStr.getInputLine());
    for (int i = 1; i < col; ++i) {
      errStr.print("-");
    }
    errStr.println("^");
    if (more != null) {
      errStr.println(more);
    }
    errStr.flush();
  }

  /**
   * This static initializer makes sure that we set up the character class
   * table and the parsing State objects.
   */
  static {
    // initialize the character class table
    initClassTable();

    // initialize the static state objects
    initStates();
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

