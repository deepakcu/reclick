package reclick;
import java.util.*;
import static reclick.TokenKey.*;
import static reclick.TokenOp.*;
/**
 * This defines an AST (Abstract Syntax Tree) visitor for checking semantic
 * correctness. Different constructs have different checking protocols, to
 * wit:
 *
 * Decl node visiting:
 *   doProcBody is an INPUT, indicating whether this pass of Decl processing
 *   should dive into the bodies of nested procedures/functions
 *
 * CaseElement visiting:
 *    compatibleLabelType is an INPUT, giving the Type with which labels need
 *    to be compatible
 *
 * Type node visiting:
 *    resultType is an OUTPUT, giving the Type determined for the node
 *
 * Expr node visiting:
 *    rValue is an INPUT, indicating whether the context demands a value
 *    (rValue true) or a writable variable (rValue false)
 *
 * @version 1.0
 */
public class ASTCheckVisitor extends ASTNullVisitor
{

  /**
   * One phase of checking Decl nodes is "resolution", and this visitor helps
   * with that task.
   */
  private ASTResolverVisitor resolver;

  /**
   * This visitor assists in checking Expr trees that should define constant
   * values.
   */
  private ASTCheckConstVisitor ccv;

  /**
   * This visitor assists in checking uses of identifiers in bindings
   * (ExprBinding)
   */
  private ASTCheckUseVisitor   cuv;

  /**
   * INPUT to Decl visiting; indicates whether to process procedure/function
   * bodies in this "pass".
   */
  private boolean doProcBody;

  /**
   * INPUT to CaseElement visiting; indicates the Type against which to match
   * the labels of a CASE statement.
   */
  private Type compatibleLabelType;

  /**
   * OUTPUT of Type node visiting; indicates the Type determined for the node.
   */
  private Type resultType;

  /**
   * INPUT to Expr visiting methods; indicates whether the context demands an
   * rvalue or an lvalue.
   *
   */
  public boolean rValue;

  /**
   * Indicates how many checking errors we found.
   */
  public int numErrors = 0;

  /**
   * The obvious constructor; it creates our three helper visitors.
   */
  public ASTCheckVisitor () { 
    resolver = new ASTResolverVisitor();
    ccv      = new ASTCheckConstVisitor(this);
    cuv      = new ASTCheckUseVisitor(this);
  }

  /**
   * Checks a Program: processes predefined Decls, then Decls and Block of the
   * Program, in appropriate scopes.
   *
   * @param p the Program we are checking
   */
  public void visitComponent (Component c) {
    c.predefs = new SymbolTable((SymbolTable)null, Decls.predefines,
                                /*(DeclProcFunc)null,*/ true);
    c.predefs.enterScope();
    Decls.predefines.accept(this);

    c.mySymtab = new SymbolTable(c.predefs, c.decls,
                                 /*(DeclProcFunc)null,*/ true);
    c.mySymtab.enterScope();
    c.decls.accept(this);
    c.block.accept(this);

    c.mySymtab.exitScope();
    c.predefs.exitScope();
  }

  /**
   * Checks a Block: processes its Decls then its Stmts, in appropriate
   * scopes.
   *
   * @param b the Block we are checking
   */
  public void visitBlock (Block b) {
    SymbolTable outer = SymbolTable.current();
    b.mySymtab = new SymbolTable(outer, b.decls,
                                 /*outer.procFunc,*/ false);
    b.mySymtab.enterScope();
    b.decls.accept(this);
    b.stmts.accept(this);
    b.mySymtab.exitScope();
  }
    
  /**
   * Checks a Decls: involves three phases:
   *   (1) "resolving" the uses of identifiers to their definitions in
   *       appropriate scopes;
   *   (2) checks each Decl (but not procedure/function bodies);
   *   (3) check procedure/function bodies, now that we have checked all their
   *       headers
   *
   * @param dd the Decls we are checking
   */
  public void visitDecls (Decls dd) {
    /* first: resolve identifiers, etc. */
    for (Decl d : dd) {
      try {
        d.accept(resolver);
      } catch (SemanticException e) {
        assert e.pos != -1;
        reclick.ShowError(e.pos, e.getMessage());
        ++numErrors;
      }
    }
  
    /* now check the resolved declarations  */
    /* do not process procedure bodies here */
    boolean old = doProcBody;
    doProcBody = false;
    for (Decl d : dd) {
      try {
        if (d.resolved) d.accept(this);
      } catch (SemanticException e) {
        assert e.pos != -1;
        reclick.ShowError(e.pos, e.getMessage());
        ++numErrors;
      }
    }

    /* process any nested procedure bodies */
    doProcBody = true;
    for (Decl d : dd) {
      try {
        if (d.resolved) d.accept(this);
      } catch (SemanticException e) {
        assert e.pos != -1;
        reclick.ShowError(e.pos, e.getMessage());
        ++numErrors;
      }
    }
    doProcBody = old;
  }

  /**
   * Checks a DeclConst: check its Expr as a constant
   *
   * @param c the DeclConst we are checking
   */
  public void visitDeclConst (DeclConst c) {
    if (!doProcBody) {
      Expr expr = c.expr;
      assert expr != null;
      if (expr.type == null) {
        assert expr.object == null;
        expr.checkConst(ccv);
      }
    }
  }

  

  /**
   * Checks a DeclFormal: check its Type.
   *
   * @param f the DeclFormal we are checking
   */
  /*
  public void visitDeclFormal (DeclFormal f) {
    if (!doProcBody) {
      Type type = f.type;
      assert type != null;
      type.accept(this);
    }
  }
  */

  /**
   * Checks a DeclProcFunc: if we are NOT processing bodies, it checks the
   * Formals, and the result Type (if any), in appropriate scopes. If we ARE
   * processing bodies, then it processes the proc/func's Block.
   *
   * @param p the DeclProcFunc we are checking
   */
  /*
  public void visitDeclProcFunc (DeclProcFunc p) {
    SymbolTable mySymtab = p.mySymtab;
    if (!doProcBody) {
      assert mySymtab != null;
      mySymtab.enterScope();
      for (Decl d : p.formals) {
        try {
          d.accept(this);
        } catch (SemanticException e) {
          assert e.pos != -1;
          mpc.ShowError(e.pos, e.getMessage());
          ++numErrors;
        }
      }
      mySymtab.exitScope();
    
      Type resultType = p.resultType;
      if (resultType != null)
        resultType.accept(this);

    } else { // process procedure bodies
      if (p.resolved && mySymtab != null) {
        mySymtab.enterScope();
        p.block.accept(this);
        mySymtab.exitScope();
      }
    }
  }
  */

  /**
   * Checks a DeclType: checks its Type.
   *
   * @param t the DeclType we are checking
   */
  public void visitDeclType (DeclType t) {
    if (!doProcBody) {
      Type type = t.type;
      assert type != null;
      type.accept(this);
    }
  }

  /**
   * Checks a DeclVar: checks its type.
   *
   * @param v the DeclVar we are checking
   */
  public void visitDeclVar (DeclVar v) {
    if (!doProcBody) {
      Type type = v.type;
      assert type != null;
      type.accept(this);
    }
  }
  
  /**
   * Checks a DeclPacket: checks its type.
   *
   * @param v the DeclPacket we are checking
   */
  public void visitDeclPacket (DeclPacket p) {
    if (!doProcBody) {
      Type type = p.type;
      assert type != null;
      type.accept(this);
    }
  }
  
  /**
   * Checks a DeclField: checks its type.
   *
   * @param v the DeclField we are checking
   */
  public void visitDeclField (DeclField f) {
    if (!doProcBody) {
      Type type = f.type;
      assert type != null;
      type.accept(this);
    }
  }
  
  /**
   * Checks a DeclInput: checks its type.
   *
   * @param v the DeclInput we are checking
   */
  public void visitDeclInput (DeclInput i) {
    if (!doProcBody) {
      Type type = i.type;
      assert type != null;
      type.accept(this);
    }
  }
  
  /**
   * Checks a DeclOutput: checks its type.
   *
   * @param v the DeclOutput we are checking
   */
  public void visitDeclOutput (DeclOutput o) {
    if (!doProcBody) {
      Type type = o.type;
      assert type != null;
      type.accept(this);
    }
  }
  
  // Methods for checking statements

  /**
   * Checks a Stmts: checks each Stmt in turn.
   *
   * @param ss the Stmts we are checking
   */
  public void visitStmts (Stmts ss) {
    for (Stmt s : ss.stmts) {
      try {
        s.accept(this);
      } catch (SemanticException e) {
        assert e.pos != -1;
        reclick.ShowError(e.pos, e.getMessage());
        ++numErrors;
      } catch (Exception e) {
        e.printStackTrace();
        ++numErrors;
      }
    }
  }

  /**
   * Checks a StmtAssign: checks its var (lhs) as an lvalue; detects the case
   * of the var being an ExprBinding to a DeclProcFunc, which needs to be a
   * function (i.e., have a non-null resultType) and be the current proc/func
   * being processed; checks the Expr being assigned; and checks assignment
   * compatibility of the lhs and rhs Type's.
   *
   * @param s the StmtAssign we are checking
   */
  /*
  public void visitStmtAssign (StmtAssign s) {
    Expr var  = s.var;
    Expr expr = s.expr;
    assert var != null && expr != null;
    if (var instanceof ExprBinding) {
      // handle special case of function result assignment 
      ExprBinding eb = (ExprBinding)var;
      Decl         d = SymbolTable.checkBindUse(eb.bind);

      if (d instanceof DeclProcFunc) {
        var.type = ((DeclProcFunc)d).resultType;
        
        if (var.type == null)
          throw new SemanticException(s.pos, "Cannot assign to procedure name");
        if (d != SymbolTable.current().procFunc) // it's the wrong proc/func 
          throw new SemanticException(s.pos, "Cannot assign to function other than current one");
        var.rvalue = false;
      }
    }
	

    // first check the left hand side which may or may not have been handled 
    rValue = false;  
    if (var.type == null) var.accept(this);
    // now we check the right hand side 
    rValue = true;  
    expr.accept(this);
    if (expr.type == null) expr.type = Type.theErrorType;
    if (!var.type.isAssignableFrom(expr.type)) {
      var.type = Type.theErrorType; // suppress code generation 
      throw new SemanticException(s.pos, "Incompatible type in assignment");
    } 
  }
  */

  /**
   * Checks a StmtCall: first separates out the case of a parameter-less
   * proc/func (ExprBinding); otherwise the Expr must be an ExprCall, which it
   * checks.
   *
   * @param c the StmtCall we are checking
   */
  /*
  public void visitStmtCall (StmtCall c) {
    Expr call = c.call;
    assert call != null;
    if (call instanceof ExprBinding)
      call.checkArguments(this, ((ExprBinding)call).bind, Exprs.emptyList, false);
    else if (call instanceof ExprCall) {
      rValue = false;
      call.accept(this);
    }
    else
      throw new SemanticException(c.pos, "Ill formed call statement");
  }
  */

  /**
   * Checks a StmtCase: checks its Expr and insures that it is of ordinal
   * type; checks the CaseElement's; checks the case labels to see if there
   * are duplicates.
   *
   * @param c the StmtCase we are checking
   */
  /*
  public void visitStmtCase (StmtCase c) {
    Expr                   expr = c.expr;
    ArrayList<CaseElement> list = c.list;
    assert expr != null && list != null;

    expr.type = Type.theErrorType;

    rValue = true;
    expr.accept(this);
    if (!expr.type.isOrdinalType())
      throw new SemanticException(c.pos, "CASE expression has inappropriate type");

    // check case list 
    boolean ok = true;

    // will accumulate label values seen thus far
    ArrayList<Expr> oldLabs = new ArrayList<Expr>(list.size());

    for (CaseElement e : list) {
      // indicate the type which the label must be compatible with
      compatibleLabelType = expr.type;
      e.accept(this);

      // check for duplicate labels: we check each label to see if it has
      // already been seen, and add it to the list of seen labels
      for (Expr currLabel : e.labels) {
        for (Expr oldOne : oldLabs) {
          if (currLabel.equalToConstant(oldOne)) {
            mpc.ShowError(currLabel.pos, "Duplicate case label");
            ++numErrors;
            ok = false;
            break;  // avoids redundant error messages
          }
        } 
        oldLabs.add(currLabel);
      }
    }

    if (!ok)
      throw new SemanticException(c.pos, "Encountered duplicate labels in case statement");      
  }
  */

  /**
   * Checks a CaseElement: checks each of its labels as a constant, that it is
   * compatible with the CASE expression's Type (compatibleLabelType), that
   * the constant is in the range of values legal for the Type, and finally
   * checks the CaseElement's Stmt.
   *
   * @param c the CaseElement we are checking
   */
  /*
  public void visitCaseElement (CaseElement c) {
    // check labels
    for (Expr e : c.labels) {
      e.checkConst(ccv);
      if (!e.type.isCompatibleWith(compatibleLabelType))
        throw new SemanticException(e.pos, "CASE label type incompatible with CASE expression");
      else if (!e.constantIsInType(compatibleLabelType))
        throw new SemanticException(e.pos, "CASE label value out of range");
    }

    c.stmt.accept(this);
  }
  */

  /**
   * Checks a StmtCompound: checks its Stmts.
   *
   * @param c the StmtCompound we are checking
   */
  public void visitStmtCompound (StmtCompound c) {
     c.stmts.accept(this);
   }

  /**
   * Checks a StmtFor: the Binding must be to a DeclVar, at the current
   * procLevel, and of ordinal type; checks the init Expr, whose resulting
   * Type must be compatible with the variable; checks the to Expr, whose
   * resulting Type must also be compatible with the variable; and checks the
   * Stmt.
   *
   * @param f the StmtFor we are checking
   */
  
  public void visitStmtFor (StmtFor f) {
     Expr    init = f.init;
     Expr    to   = f.condition;
     Binding name = f.name;

     assert name != null && init != null && to != null;

     Decl d = SymbolTable.checkBindUse(name);
     if (!(d instanceof DeclVar))
       throw new SemanticException(f.pos, "FOR name must be a variable");

     if (SymbolTable.current().procLevel != d.symbolTable.procLevel)
       throw new SemanticException(f.pos, "FOR variable must be local to current procedure");

     DeclVar var = (DeclVar)d;
     if (!var.type.isOrdinalType())
       throw new SemanticException(f.pos, "FOR variable must be of an ordinal type");

     rValue = true;
     init.accept(this);
     if (!var.type.isCompatibleWith(init.type))
       throw new SemanticException(f.pos, "FOR variable and init expression have incompatible types");

     rValue = true;
     to.accept(this);
     if (!var.type.isCompatibleWith(to.type))
       throw new SemanticException(f.pos, "FOR variable and to expression have incompatible types");

     f.stmt.accept(this);

     f.ok = true;
   }
   

  /**
   * Check a StmtIf: checks the then Stmt; checks the else Stmt (if any);
   * checks the Expr, and insures it has Boolean Type.
   *
   * @param i the StmtIf we are checking
   */
  public void visitStmtIf (StmtIf i) {
     Expr expr     = i.expr;
     Stmt stmtThen = i.stmtThen;
     assert expr != null && stmtThen != null;

     expr.type = Type.theErrorType; /* suppress code generation if failure */

     stmtThen.accept(this);

     if (i.stmtElse != null)
       i.stmtElse.accept(this);

     rValue = true;
     
     //Accept the expression
     expr.accept(this);
     //System.out.println("Expression type is "+expr.type.);
     if (!expr.type.isBoolType())
       throw new SemanticException(i.pos, "IF test expression must be boolean");
   }

  /**
   * Checks a StmtRepeat: Checks the Stmts; checks the Expr, and that it has
   * Boolean Type.
   *
   * @param r the StmtRepeat we are checking
   */
  /*
  public void visitStmtRepeat (StmtRepeat r) {
     Expr  expr  = r.expr;
     Stmts stmts = r.stmts;
     assert expr != null && stmts != null;
     expr.type = Type.theErrorType; // suppress code generation if failure 

     stmts.accept(this);

     rValue = true;
     expr.accept(this);
     if (!expr.type.isBoolType())
       throw new SemanticException(r.pos, "REPEAT expression must be boolean");
   }
  */

  /**
   * Checks a StmtWhile: Checks the Stmt; checks the Expr, and that it has
   * Boolean Type.
   *
   * @param w the StmtWhile we are checking
   */
  /*
  public void visitStmtWhile (StmtWhile w) {
    Expr expr = w.expr;
    Stmt stmt = w.stmt;
    assert expr != null && stmt != null;

    expr.type = Type.theErrorType; // suppress code generation if failure 

    stmt.accept(this);
     
    rValue      = true;
    expr.accept(this);

    if (!expr.type.isBoolType())
      throw new SemanticException(w.pos, "WHILE expression must be boolean");
  }
  */

  // Methods for checking expressions

  /**
   * Checks an Exprs: checks each Expr of the list.
   *
   * @param ee the Exprs to check
   */
  public void visitExprs (Exprs ee) {
    for (Expr e : ee.exprs) {
      try {
        e.accept(this);
      } catch (SemanticException exc) {
        assert e.pos != -1;
        reclick.ShowError(e.pos, exc.getMessage());
        ++numErrors;
      } catch (Exception exc) {
        exc.printStackTrace();
        ++numErrors;
      }
    }
  }

  /**
   * Checks an ExprBinary: checks expr1 (with rValue same as passed in);
   * checks expr2 (with rValue true); depending on the operator, checks types
   * of operands, as described in the table; sets the result Type. Insures
   * that the context is not demanding an lvalue result (unless the operator
   * is LBRACK (subscript) or DOT (record field)).
   *
   * AND, OR: (boolean, boolean) -> boolean
   * PLUS, MINUS, AST, DIV, MOD: (integer, integer) -> integer
   * LT, GT, LE, GE: compatible ordinal types -> boolean
   * EQ, NE: compatible ordinal or pointer types -> boolean
   * DOT: record, suitable field -> type of the field
   * LBRACK: array, compatible with index type -> element type
   *
   * @param b the ExprBinary we are checking
   */
  public void visitExprBinary (ExprBinary b) {
     boolean rvin = rValue;
     b.rvalue = rValue;
     Expr expr1 = b.expr1;
     Expr expr2 = b.expr2;
     assert expr1 != null && expr2 != null;
     
     b.type = Type.theErrorType;
     expr1.accept(this);

     rValue = true;
     expr2.accept(this);
     /* note that right expressions need never be writable */

     Type lt = expr1.type;
     Type rt = expr2.type;

     Token op = b.op;
     if (op == AND /*|| op == OR*/) {
       if (lt.isBoolType() && rt.isBoolType()) {
         b.type = Type.theBoolType;
         b.insistRightHandSide(rvin);
       }
       else
         throw new SemanticException(b.pos, "Illegal types of operands in binary expression");
     }
     else if (op == PLUS || op == MINUS || op == AST ||
              op == DIV  || op == MOD) {
       if (lt.isCompatibleWith(rt) && lt.isIntBasedType()) {
         b.type = Type.theIntType;
         b.insistRightHandSide(rvin);
       }
       else
         throw new SemanticException(b.pos, "Illegal types of operands in binary expression");
     }
     else if (op == LT || op == GT || op == LE || op == GE || op == EQ || op == NE) {
       if (lt.isCompatibleWith(rt) && lt.isOrdinalType()) {
         b.type = Type.theBoolType;
         b.insistRightHandSide(rvin);
       }
       else {
           System.out.println("Is ordinal type is "+lt.toString());
           System.out.println("compatibility is "+lt.isCompatibleWith(rt));
    	   throw new SemanticException(b.pos, "Illegal types of operands in binary expression");
       }
     }
     //Deepak commented
     /*
     else if (op == EQ || op == NE) {
       if (lt.isCompatibleWith(rt) &&
           (lt.isOrdinalType() || lt.isPointerType())) {
         b.type = lt;
         b.insistRightHandSide(rvin);
       }
       else
         throw new SemanticException(b.pos, "Illegal types of operands in binary expression");
     }
     */
     else if (op == LSHIFT || op == RSHIFT) {
         if (lt.isCompatibleWith(rt)) {
           b.type = Type.theBoolType;
           b.insistRightHandSide(rvin);
         }
         else
           throw new SemanticException(b.pos, "Illegal types of operands in binary expression");
       }
     /*
     else if (op == DOT) {
    	 
       if (lt instanceof TypeRecord) {
         TypeRecord rect = (TypeRecord)lt;
         assert expr2 instanceof ExprId;
         ExprId id = (ExprId)expr2;
         assert id.id != null;
         DeclField f = rect.findField(id.id);
         if (f != null)
           b.type = f.type;
         else
           throw new SemanticException(b.pos, "Bad field name " + f + " in record selection");
       }
       else
         throw new SemanticException(b.pos, "Attempt to select from non-record");
     }
     
     else if (op == LBRACK) {
       if (lt instanceof TypeArray) {
         TypeArray ta = (TypeArray)lt;
         if (ta.indexType.isCompatibleWith(rt))
           b.type = ta.elementType;
         else
           throw new SemanticException(b.pos, "Index type incompatible with array index type");
       }
       else
         throw new SemanticException (b.pos, "Attempt to index non-array");
     }
     */
     else
       throw new SemanticException(b.pos, "Unknown binary operator '" + op + "'");
     rValue = rvin;
   }

  /**
   * Checks an ExprBinding: using the CheckUseVisitor (cuv), visits the
   * ExprBinding's Decl (obtained from SymbolTable.checkBindUse).
   *
   * @param b the ExprBinding we are checking
   */
  public void visitExprBinding (ExprBinding b) {
     b.rvalue = rValue;
     b.type = Type.theErrorType;
     Decl d = SymbolTable.checkBindUse(b.bind);
     cuv.rValue = rValue;
     cuv.bind   = b;
     d.accept(cuv);
   }

  /**
   * Checks an ExprCall: Uses c.checkArguments to check the call.
   *
   * @param c the ExprCall we are checking
   */
  /*
  public void visitExprCall (ExprCall c) {
     c.rvalue = rValue;
     assert c.bind != null;
     c.checkArguments(this, c.bind, c.actuals, rValue);
   }
   */

  /**
   * Checks an ExprId: This is used only in record field selection; its use
   * will be checked in the context of the DOT operator, so there is no work
   * here.
   *
   * @param i the ExprId we are checking
   */
  public void visitExprId (ExprId i) {
     /* uses will be checked contextually (record selection); has no type */
   }

  /**
   * Checks an ExprInt (integer literal): needs only to insure that the
   * context does not demand an lvalue.
   *
   * @param i the ExprInt we are checking.
   */
  public void visitExprInt (ExprInt i) {
     i.rvalue = rValue;
     i.insistRightHandSide(rValue);
   }

  /**
   * Checks an ExprNil (occurrence of Pascal NIL): needs only to insure that
   * the context does not demand an lvalue.
   *
   * @param n the ExprNil we are checking
   */
  /*
  public void visitExprNil (ExprNil n) {
     n.rvalue = rValue;
     n.insistRightHandSide(rValue);
   }
   */

  /**
   * Checks and ExprString (string literal): needs only to insure that the
   * context does not demand an lvalue.
   *
   * @param s the ExprString we are checking
   */
  public void visitExprString (ExprString s) {
     s.rvalue = rValue;
     s.insistRightHandSide(rValue);
   }

  /**
   * Checks an ExprUnary: checks expr (with rValue true); depending on the
   * operator, checks type of the operand, as described in the table; sets the
   * result Type. Insures that the context is not demanding an lvalue result
   * (unless the operator is CARET (pointer dereference)).
   *
   * NOT: boolean -> boolean
   * PLUS, MINUS: integer -> integer
   * CARET: pointer type -> its element type
   *
   * @param u the ExprUnary we are checking
   */
   public void visitExprUnary (ExprUnary u) {
     u.rvalue = rValue;
     Expr expr = u.expr;
     assert expr != null;

     boolean rvin = rValue;
     u.type = Type.theErrorType;

     rValue = true;
     expr.accept(this);

     Token op   = u.op;
     Type  type = expr.type;
     if (op == NOT) {
       if (type.isBoolType())
         u.type = Type.theBoolType;
       u.insistRightHandSide(rvin);
     }
     else if (op == PLUS || op == MINUS) {
       if (type.isIntBasedType())
         u.type = Type.theIntType;
       u.insistRightHandSide(rvin);
     }
     /*
     else if (op == CARET) {
       if (type.isPointerType()) {
         TypePointer pt = (TypePointer)type;
         assert pt.element != null;
         u.type = pt.element;
       }
       else
         throw new SemanticException(u.pos, "Attempt to dereference non-pointer");
     }
     */
     else
       throw new SemanticException(u.pos, "Incompatible operation in unary expression");

     rValue = rvin;
   }

  // Methods for checking types

  /**
   * Checks a TypeArray: Checks the index Type, that it is ordinal, not
   * INTEGER (which would be too big a range :-), and warns if it is large;
   * checks the element Type (unconstrained);
   *
   * @param a the TypeArray we are checking
   */
   /*
  public void visitTypeArray (TypeArray a) {
    if (!a.checked) {
      Type indexType   = a.indexType;
      Type elementType = a.elementType;
      assert indexType != null && elementType != null;
      indexType.accept(this);
      if (!indexType.isOrdinalType())
        throw new SemanticException(a.pos, "Index types must be ordinal types");
      if (indexType.isIntegerType())
        throw new SemanticException(a.pos, "INTEGER may not be an index type");
      int number = indexType.getNumber();
      if (number > 1000000)
        mpc.ShowError(a.pos, "Warning: array type very large");
      elementType.accept(this);
      a.size = number * elementType.size;
      a.checked = true;
    }
    resultType = a;
  }
  */

  /**
   * Checks a TypeId: insures that the Decl of the Binding (obtained from
   * SymbolTable.checkBindUse) is a DeclType, and returns its Type as the
   * result.
   *
   * @param i the TypeId we are checking
   */
  public void visitTypeId (TypeId i) {
    Type result = i;

    if (!i.checked) {
      Binding bind = i.bind;
      assert bind != null;
      Decl d = SymbolTable.checkBindUse(bind);
      if (d == null)
        result = Type.theErrorType;
      else if (!(d instanceof DeclType))
        throw new SemanticException(i.pos, bind.id + " is not a type");
      else {
        /* bypass the re-binding of the id */
        result = ((DeclType)d).type;
      }
      i.checked = true;
    }

    resultType = result;
  }

  /**
   * Checks a TypePointer: Checks the named Type (must be a TypeId); keeps the
   * Binding in p.bind.
   *
   * @param p the TypePointer we are checking
   */
  /*
  public void visitTypePointer (TypePointer p) {
    if (!p.checked) {
      // check the named type 
      Type element = p.element;
      assert element != null && element instanceof TypeId && p.bind == null;
      p.bind = ((TypeId)element).bind;
      element.accept(this);
      p.element = resultType;
      p.checked = true;
    }
    resultType = p;
  }
  */

  /**
   * Checks a TypePrimBool: nothing to do for a primitive Type.
   *
   * @param p the TypePrimBool we are checking
   */
  public void visitTypePrimBool (TypePrimBool p) {
    /* nothing to do here, built-in */
    resultType = p;
  }

  /**
   * Checks a TypePrimInt: nothing to do for a primitive Type.
   *
   * @param p the TypePrimInt we are checking
   */
  public void visitTypePrimInt (TypePrimInt p) {
    /* nothing to do here, built-in */
    resultType = p;
  }

  /**
   * Checks a TypePrimNil: nothing to do for a primitive Type.
   *
   * @param p the TypePrimNil we are checking
   */
  /*
  public void visitTypePrimNil (TypePrimNil p) {
    // nothing to do here, built-in 
    resultType = p;
  }
  */

  /**
   * CHecks a TypePrimString: nothing to do for a primitive Type.
   *
   * @param p the TypePrimString we are checking
   */
  public void visitTypePrimString (TypePrimString p) {
    /* nothing to do here, built-in */
    resultType = p;
  }

  /**
   * CHecks a TypePrimString: nothing to do for a primitive Type.
   *
   * @param p the TypePrimString we are checking
   */
  public void visitStmtAssign (StmtAssign s) {
    /* nothing to do here, built-in */
    Decl assignerDecl = SymbolTable.checkBindUse(s.assigner);
	Decl assigneeDecl = SymbolTable.checkBindUse(s.assignee);
		
	assert (assignerDecl instanceof DeclPacket||assignerDecl instanceof DeclInput);
	assert (assigneeDecl instanceof DeclPacket||assigneeDecl instanceof DeclOutput);
		
	//If assigner is packet, assignee must be output port type
	if(assignerDecl instanceof DeclPacket) {
		assert assigneeDecl instanceof DeclOutput;
	   	//throw new SemanticException(assignerDecl.pos, "If assigner is packet, assignee must be output port type");
	}  
	//If assigner is input port type, assignee must be packet type
	else if(assignerDecl instanceof DeclInput) {
		assert assigneeDecl instanceof DeclPacket;
	    //throw new SemanticException(assignerDecl.pos, "If assigner is input port type, assignee must be packet type");
	}
  }

  
  @Override
public void visitPacket(Packet p) {
	// TODO Auto-generated method stub
	
}

@Override
public void visitStmtInsert(StmtInsert s) {
	Decl valueDecl = SymbolTable.checkBindUse(s.src);
	assert valueDecl instanceof DeclVar;
	
	//check that the width is less than 32 bits
	assert ((DeclVar)valueDecl).width<32;
	
	//Make sure that the packet was declared before
	Decl packetDecl = SymbolTable.checkBindUse(s.packet);
	assert packetDecl instanceof DeclPacket;
	 
}

@Override
public void visitStmtRemove(StmtRemove s) {
	Decl valueDecl = SymbolTable.checkBindUse(s.targetField);
	assert valueDecl instanceof DeclField;
	
	//Make sure that the packet was declared before
	Decl packetDecl = SymbolTable.checkBindUse(s.packet);
	assert packetDecl instanceof DeclPacket;
	
}

@Override
public void visitStmtSet(StmtSet s) {
	  // TODO Auto-generated method stub
	  Binding field  = s.field;
	  Binding packet = s.packet;
	  Expr expr 	 = s.expression;
	  
      assert packet != null;
      Decl d = SymbolTable.checkBindUse(packet);
      
      if(!(d instanceof DeclPacket))
    	  throw new SemanticException(d.pos, "Set target must be a packet entity");
        
      assert field != null;
      d = SymbolTable.checkBindUse(field);
      if(!(d instanceof DeclField))
    	  throw new SemanticException(d.pos, "Set variable not a field entity");
        
      expr.type = Type.theErrorType;
      expr.accept(this);
}

@Override
public void visitStmtGet(StmtGet s) {
	
	// TODO Auto-generated method stub
	Binding field  = s.field;
	Binding packet = s.packet;
	Expr expr 	   = s.variable;
	  
	
	Decl d = SymbolTable.checkBindUse(packet);
	
	if(!(d instanceof DeclPacket))
  	  throw new SemanticException(d.pos, "Get source not a packet entity");
	
	d = SymbolTable.checkBindUse(field);
	
	if(!(d instanceof DeclField))
	  	  throw new SemanticException(d.pos, "Get source not a valid field in packet");
	expr.accept(this);
}

@Override
public void visitStmtEquals(StmtEquals s) {
	// TODO Auto-generated method stub
	
	
}

@Override
public void visitStmtConcat(StmtConcat s) {
	// TODO Auto-generated method stub	
}

@Override
public void visitStmtLookup(StmtLookup s) {
	// TODO Auto-generated method stub	
}



  /**
   * Checks a TypeRange: check the lo and hi Expr's as constants (using our
   * ASTCheckConstVisitor, ccv); insure lo and hi have compatible Type's, that
   * the Type's are integer-based; and that the range includes at least one
   * value. Sets the base Type and the resultType.
   *
   * @param r a TypeRange to check
   */
  /*
  public void visitTypeRange (TypeRange r) {
    Expr lo = r.lo;
    Expr hi = r.hi;
    lo.checkConst(ccv);
    hi.checkConst(ccv);

    if (!lo.type.isCompatibleWith(hi.type))
      throw new SemanticException(r.pos, "Range bounds have incompatible types");
    if (!lo.type.isIntBasedType())
      throw new SemanticException(r.pos, "Range types must be based on integers");
    if (r.getNumber() < 1)
      throw new SemanticException(r.pos, "Range lower limit exceeds upper limit");

    r.base = lo.type.getBaseType();

    resultType = r;
  }
  */

  /**
   * Checks a TypeRecord: Checks each if its fields (DeclField) and that there
   * are no duplicates.
   *
   * @param r the TypeRecord we are checking
   */
  /*
  public void visitTypeRecord (TypeRecord r) {
    int offset = 0;
    for (DeclField f : r.fields) {
      f.accept(this);
      if (r.duplicateField(f.bind.id))
        throw new SemanticException(r.pos, "Duplicate field name " + f.bind.id);
      f.offset = offset;
      offset += f.type.size;
    }

    r.size = offset;
    // TODO
    //if (offset > MAX_FRAME_SIZE)
    //  mpc.errStream.println ("Warning: record type very large");
    resultType = r;
  }
  */

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

