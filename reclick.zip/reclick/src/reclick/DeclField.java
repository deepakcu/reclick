package reclick;
/**
 * Representation for a field declaration within a record declaration.
 *
 * @version 1.0
 */
public class DeclField extends Decl {

  /**
   * Type of the field declaration
   */
  public Type type;
  // Note: cannot be final because we allocate DeclField objects and set their
  // type later

  /**
   * indicates the offset of this field within a record
   */
  int offset = -1;  // -1 means "not yet assigned"

  public ExprInt upper;
  
  public ExprInt lower;
  
  public ExprInt word;
  /**
   * Creates a new DeclField instance, given its Binding (name)
   *
   * @param b the binding to this field declaration
   */
  public DeclField (Binding b, ExprInt up, ExprInt lo, ExprInt wrd) {
    super(b, b.pos, -1);
    type  = Type.theFieldType;
    upper = up;
    lower = lo;
    word  = wrd;
  }

  /**
   * Handles AST visiting for DeclField nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDeclField(this);
    super.acceptAfter(v);
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

