package reclick;

public class TupletOrdinaryVar {
	
	String condition;
	String variable;
	String exprString;
	int low;
	int high;
	
	TupletOrdinaryVar(String condition, String variable, String exprString) {
		this.condition = condition;
		this.variable  = variable;
		this.exprString = exprString;
	}
}
