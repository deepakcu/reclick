package reclick;
import java.util.*;

/**
 * The class Decls represents a list of declarations that can
 * occur in a <i>Pascal</i> program.
 *
 * Also deals with setting up the Decl's predefined for all programs.
 *
 * @version 1.0
 */
public final class Decls extends ASTNode implements Iterable<Decl> {

  /**
   * Decls for the predefines
   *
   */
  public static Decls predefines;
  
  /**
   * primitiveIntDecl gives the Decl for the Pascal INTEGER type
   */
  public static final Decl primitiveIntDecl;

  public static final Decl primitiveStrDecl;
  
  //public static final Decl primitiveBoolDecl;
  
  /**
   * The static initializer sets up the predefined Decl's
   */
  static {
    /* create built-in type definitions */
	  
    Binding primIntBind  = new Binding((TokenId)TokenId.get("integer"), -1, -1);
    primitiveIntDecl     = new DeclType(primIntBind, Type.theIntType, -1, -1);

    Binding primStrBind  = new Binding((TokenId)TokenId.get("string"), -1, -1);
    primitiveStrDecl     = new DeclType(primStrBind, Type.theStringType, -1, -1);

    //Binding primBoolBind = new Binding((TokenId)TokenId.get("boolean"), -1, -1);
    //primitiveBoolDecl    = new DeclType(primBoolBind, Type.theBoolType, -1, -1);
    
	  
    /* create build-in constant declarations */
    /*
	Binding primTrueBind  = new Binding((TokenId)TokenId.get("true"), -1, -1);
    primitiveTrueDecl     = new DeclConst(primTrueBind, Expr.theTrueExpr);

    Binding primFalseBind = new Binding((TokenId)TokenId.get("false"), -1, -1);
    primitiveFalseDecl    = new DeclConst(primFalseBind, Expr.theFalseExpr);
    */
    
    /* create built-in special declarations */
    /*
	Binding primNewSpecial     = new Binding((TokenId)TokenId.get("new"), -1, -1);
    primitiveNewDecl           = new DeclSpecial(primNewSpecial);

    Binding primReadlnSpecial  = new Binding((TokenId)TokenId.get("readln"), -1, -1);
    primitiveReadlnDecl        = new DeclSpecial(primReadlnSpecial);

    Binding primWriteSpecial   = new Binding((TokenId)TokenId.get("write"), -1, -1);
    primitiveWriteDecl         = new DeclSpecial(primWriteSpecial);

    Binding primWritelnSpecial = new Binding((TokenId)TokenId.get("writeln"), -1, -1);
    primitiveWritelnDecl       = new DeclSpecial(primWritelnSpecial);
    */
    
    ArrayList<Decl> predefs = new ArrayList<Decl>(10);
    predefs.add(primitiveIntDecl);
    predefs.add(primitiveStrDecl);
    //predefs.add(primitiveBoolDecl);
    //predefs.add(primitiveTrueDecl);
    //predefs.add(primitiveFalseDecl);
    //predefs.add(primitiveNewDecl);
    //predefs.add(primitiveReadlnDecl);
    //predefs.add(primitiveWriteDecl);
    //predefs.add(primitiveWritelnDecl);
    predefines = new Decls(predefs, -1, -1);
    
  }

  /**
   * decls holds the list of declarations of this Decls
   */
  public final ArrayList<Decl> decls;

  /**
   * Creates a new Decls instance given an ArrayList of its Decl
   * nodes and its source (start/end)position
   *
   * @param dd    an ArrayList of Decl nodes
   * @param left  starting position of declarations.
   * @param right ending position of declarations.
   */
  public Decls (ArrayList<Decl> dd, int left, int right) {
    super(left, right);
    decls  = dd;
  }

  /**
   * Creates a new Decls instance with no specific source code position.
   *
   * @param dd an ArrayList of Decl nodes
   */
  public Decls (ArrayList<Decl> dd) {
    this(dd, -1, -1);
  }

  /**
   * Creates a new Decls instance consisting of a single declaration
   *
   * @param d a Decl node
   */
  public Decls (Decl d) {
    this(new ArrayList<Decl>(1));
    decls.add(d);
    pos    = d.pos;
    endPos = d.endPos;
  }

  /**
   * Handles AST visiting for Decls nodes
   *
   * @param v an ASTVisitor
   */
  public void accept (ASTVisitor v) {
    super.acceptBefore(v);
    v.visitDecls(this);
    super.acceptAfter(v);
  }

  /**
   * Provides an iterator over the Decl nodes of the Decls
   *
   * @return an Iterator that produces each Decl node of the
   * Decls in turn
   */
  public Iterator<Decl> iterator () {
    return decls.iterator();
  }

}

// Local Variables:
// mode: jde
// c-basic-offset: 2
// indent-tabs-mode: nil
// End:

